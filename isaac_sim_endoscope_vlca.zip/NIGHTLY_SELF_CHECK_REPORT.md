# Isaac Sim Endoscope VLCA Nightly Self-Check Report

Date: 2026-07-19

## 1. Short Summary

Tonight's work focused on making the Isaac Sim package easier to verify and safer to continue from. I did not claim the physical route is fully solved locally, because this desktop environment cannot run the Isaac Sim Docker simulation. Instead, I checked and improved the parts that can be verified without the lab machine:

- The output format checks are stricter.
- The route smoke test no longer only checks "the endoscope moved"; it also checks whether the route goes through the intended L3.5 stages.
- The policy-data preparation script now fails loudly when images or numeric fields are missing.
- The baseline script now checks whether the labels are meaningful instead of silently training on bad data.
- A beginner-readable map of the code structure is included below.

## 2. Review Workflow Used

I followed the requested main-thread plus strict-reviewer workflow.

1. Main thread inspected the current Isaac Sim package and the user requirements.
2. A strict reviewer thread checked the package without editing code.
3. The reviewer assessed six areas:
   - requirement completeness
   - logic correctness
   - edge cases
   - code quality
   - test coverage
   - actual running / verification result
4. The reviewer returned a fix checklist.
5. The main thread fixed the issues that can be addressed locally.
6. The fixed package was checked with Python syntax compilation and a small policy-data smoke test.

## 3. Reviewer Findings

The reviewer found these main problems:

- The simulation smoke check was too weak. It only checked whether the endoscope moved, not whether it followed the intended route.
- The L3.5 route should be checked as a route: pass the insertable block, pass the lower side of the pink circle, visit the right guiding block, then approach the active target.
- Some exported route fields were too static and could look correct even when the physical route was wrong.
- The policy-data preparation script could accept missing images or bad numeric fields too silently.
- The baseline script could train on meaningless labels without warning.
- The output-format checker relied on weak assertions and did not check enough route information.

## 4. Fixes Made

### 4.1 `isaacsim_main.py`

Main role: builds the Isaac Sim scene, runs the endoscope simulation, renders frames, and writes output files.

Changes:

- Added route-stage helpers so each frame can be assigned to the current route stage.
- Added a route quality summary that checks:
  - whether the pink circle is passed from the lower side;
  - whether the right guiding block is reached;
  - whether the active target is approached;
  - whether sampled poses are finite;
  - whether segment gaps are too large.
- Strengthened the smoke test so it fails when the route is wrong, not only when the body does not move.
- Updated exported route-related fields so they are based on the recorded frame state instead of being hard-coded.

Important note:

This does not magically solve the remaining physical-route problem by itself. It makes wrong routes easier to catch and report.

### 4.2 `scripts/check_output_format.py`

Main role: checks whether the generated output folder matches the expected dataset structure.

Changes:

- Replaced raw `assert` checks with explicit readable errors.
- Added checks for:
  - `smoke_test_summary.json`;
  - route quality result;
  - trajectory/control row counts;
  - route stage information;
  - whether the route stage actually changes across the episode.

### 4.3 `scripts/prepare_policy_dataset.py`

Main role: converts a generated simulation episode into a policy-learning JSONL file.

Changes:

- Missing image files now cause a clear error.
- Missing, invalid, or non-finite numeric values now cause a clear error.
- Supports both `.jpg` and `.png` frame candidates.
- Reads CSV files with UTF-8 BOM tolerance.

This is important because policy learning should not start from silently broken data.

### 4.4 `scripts/train_policy_baseline.py`

Main role: runs a small baseline sanity check on the prepared policy data.

Changes:

- Numeric parsing is strict.
- The script checks whether labels actually vary.
- It reports a simple global-mean reference baseline.
- It warns when the dataset is too small for meaningful validation.

This is not the final policy-learning model. It is a quick check that the data is usable.

## 5. Verification Performed Locally

### 5.1 Python Syntax Check

Checked:

- `isaacsim_main.py`
- `layout_config.py`
- `scripts/prepare_policy_dataset.py`
- `scripts/train_policy_baseline.py`
- `scripts/check_output_format.py`

Result:

- Passed.

### 5.2 Policy Data Smoke Test

I created a tiny fake episode with:

- 3 trajectory frames
- 3 control rows
- dummy EBV and EV image files

Then I ran:

- policy dataset preparation
- baseline training

Result:

- Dataset preparation succeeded.
- Baseline script succeeded.

### 5.3 Isaac Sim Physical Run

Not run in this desktop environment.

Reason:

- The actual Isaac Sim Docker simulation runs on the lab Linux machine with GPU and the Isaac Sim Docker image.
- This local Windows workspace can inspect and package code, but cannot validate live PhysX behavior.

## 6. Beginner-Friendly Code Structure

Think of the project as a small factory.

### `layout_config.py`

This is the layout drawing.

It says where the board, blocks, targets, and guiding blocks are placed. For the current L3.5 case, the intended route should use:

1. the insertable block;
2. the pink circle lower edge;
3. the right solid guiding block;
4. the active star target.

The extra target-like object should be treated as a distractor/block unless it is the active target for that task.

### `isaacsim_main.py`

This is the main director.

It does most of the work:

1. starts Isaac Sim;
2. creates the board;
3. creates physical blocks and targets;
4. creates the endoscope body;
5. runs PhysX simulation;
6. records poses;
7. renders top-view and endoscope-view frames;
8. writes annotations, trajectory CSV, control CSV, and metadata.

The most important thing to remember:

The endoscope should not be treated as a loose chain of unrelated pieces. It should behave like one continuous tool:

- the rear/passive tube is relatively stiff but can be forced to bend by contact;
- the front metal/active part can steer;
- the starting clamp blocks are physical constraints;
- blocks must have collision volume;
- insertion blocks have an internal channel and a covered top.

### `scripts/check_isaacsim_capabilities.py`

This checks what Isaac Sim features are available on the machine:

- Isaac import
- PhysX stage
- rigid body
- joints
- camera
- USD export

Run this when the environment changes.

### `scripts/check_output_format.py`

This checks whether the output folder is usable.

It should catch missing images, missing JSON/CSV files, weak route output, or failed smoke tests.

### `scripts/prepare_policy_dataset.py`

This turns simulation output into a policy-learning dataset.

It reads:

- images
- trajectory
- control commands
- annotations

Then it writes JSONL samples for later training.

### `scripts/train_policy_baseline.py`

This is a small baseline check.

It is not the real final model. It answers a simpler question:

"Does the generated policy dataset contain usable numeric signals, or is it broken/constant/missing?"

## 7. Data Flow

```mermaid
flowchart LR
  A["layout_config.py<br/>layout positions"] --> B["isaacsim_main.py<br/>Isaac Sim + PhysX run"]
  B --> C["outputs/endoscope_single_latest<br/>images + CSV + JSON"]
  C --> D["check_output_format.py<br/>format + route checks"]
  C --> E["prepare_policy_dataset.py<br/>policy JSONL"]
  E --> F["train_policy_baseline.py<br/>baseline sanity check"]
```

## 8. What To Check After The Next Lab Run

After running on the lab computer, check these files first:

1. `outputs/endoscope_single_latest/run_progress.txt`
2. `outputs/endoscope_single_latest/fatal_error.txt`, if it exists
3. `outputs/endoscope_single_latest/smoke_test_summary.json`
4. `outputs/endoscope_single_latest/cam_ebv/`
5. `outputs/endoscope_single_latest/cam_ev/`
6. `outputs/endoscope_single_latest/episode_000000/trajectory.csv`
7. `outputs/endoscope_single_latest/episode_000000/control_commands.csv`

The most important visual checks:

- Does the endoscope start stably between the clamp blocks?
- Does it pass through the insertable block channel?
- Does it steer toward the lower side of the pink circle?
- Does the body shift enough to slide around the pink circle instead of hitting it directly?
- Does it recover to a straighter direction after passing the circle?
- Does it follow the right guiding block toward the active target?
- Does the endoscope look continuous instead of separated into pieces?

## 9. Remaining Risks

These still require live Isaac Sim verification:

- Whether the physical route actually follows the lower side of the pink circle.
- Whether the endoscope body remains visually continuous during replay/render.
- Whether the active bend timing and lateral body shift are physically convincing.
- Whether the camera frames are stable across the full episode.
- Whether the final target is reached.

The package is now easier to diagnose, but the physical behavior still needs visual inspection from the lab run.

