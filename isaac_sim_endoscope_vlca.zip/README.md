# Isaac Sim endoscope VLCA package

This package is the Isaac Sim side of the endoscope navigation project.

It is intentionally separated from the Genesis package. Genesis can still be
used for the old approximate data pipeline, while this package checks and uses
Isaac Sim / USD / PhysX features for scene construction, rigid colliders,
camera output, and later endoscope physics.

## Run order

1. Run the capability check first.
2. Only run the simulation entry after the check passes.

## Output layout

The output folder keeps the old Genesis-compatible episode folder, and also
writes the real VLCA dataset-style files at the output root:

```text
outputs/endoscope_single_latest/
  cam_ebv/0001.jpg
  cam_ev/0001.jpg
  json/vlca.json
  json/yolo_auto_gen.json
  data.csv
  episode_000000/
    frames/ebv/
    frames/ev/
    render_frames/
    tip_frames/
    debug_frames/
    trajectory.csv
    control_commands.csv
    annotations.json
    metadata.json
    scene.usd
```

`ebv` means the top-view camera. `ev` means the endoscope-view camera.

## Important note

The endoscope is modeled as a PhysX articulated rigid chain. The long rear tube
is hard and only passively bends by a very small amount. The steerable section is
limited to the short section between the two metal parts. The base is inserted
by a PhysX prismatic joint drive, while downstream motion is resolved by PhysX
joints and collisions.

Every run writes `smoke_test_summary.json`. Rendered episodes also keep
per-frame poses, insertion/bend commands, instruction text, and route stage
aligned across the trajectory, controls, and VLCA-compatible `data.csv`.
