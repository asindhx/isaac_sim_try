# Run commands

## Clone

```bash
cd /home/wu/Documents/isaac-sim_xizi
git clone https://github.com/asindhx/isaac_sim_try.git isaac_sim_try_new
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new/isaac_sim_endoscope_vlca
```

If using the zip package, unzip `isaac_sim_endoscope_vlca.zip` and enter the
extracted folder.

## Capability check

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new/isaac_sim_endoscope_vlca && docker run --rm --user 0:0 --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "/isaac-sim/python.sh /workspace/isaac_sim_endoscope_vlca/scripts/check_isaacsim_capabilities.py; chmod -R a+rwX /workspace/isaac_sim_endoscope_vlca/outputs || true"
```

Expected ending:

```text
ISAACSIM_CAPABILITY_CHECK_PASSED
```

## Run one Isaac Sim scene

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new/isaac_sim_endoscope_vlca && rm -rf outputs/endoscope_single_latest && docker run --rm --user 0:0 --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "/isaac-sim/python.sh /workspace/isaac_sim_endoscope_vlca/isaacsim_main.py --headless --capture-frames 24 --output-dir /workspace/isaac_sim_endoscope_vlca/outputs/endoscope_single_latest; chmod -R a+rwX /workspace/isaac_sim_endoscope_vlca/outputs"
```

## Fast no-render motion check

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new/isaac_sim_endoscope_vlca && rm -rf outputs/endoscope_single_latest && docker run --rm --user 0:0 --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "/isaac-sim/python.sh /workspace/isaac_sim_endoscope_vlca/isaacsim_main.py --headless --no-render --steps 60 --warmup-frames 10 --output-dir /workspace/isaac_sim_endoscope_vlca/outputs/endoscope_single_latest; chmod -R a+rwX /workspace/isaac_sim_endoscope_vlca/outputs"
```

This prints real tail/tip world coordinates and saves them to
`outputs/endoscope_single_latest/episode_000000/pose_debug.json`.

## Check output format

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new/isaac_sim_endoscope_vlca && python3 scripts/check_output_format.py
```

## Convert EBV frames to GIF

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new/isaac_sim_endoscope_vlca && python3 -c "from pathlib import Path; from PIL import Image; d=Path('outputs/endoscope_single_latest/cam_ebv'); frames=sorted(d.glob('*.jpg'))+sorted(d.glob('*.png')); print('frames',len(frames)); assert frames, 'no EBV frames found'; imgs=[Image.open(p).convert('RGB').resize((640,424)) for p in frames]; out=Path('outputs/endoscope_single_latest/preview_ebv.gif'); imgs[0].save(out,save_all=True,append_images=imgs[1:],duration=120,loop=0,optimize=True); print('saved',out)"
```

## Run L0/L1 training batch

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new/isaac_sim_endoscope_vlca && rm -rf outputs/batch_l0_l1_training && docker run --rm --user 0:0 --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "cd /workspace/isaac_sim_endoscope_vlca && python3 batch_run_layouts.py --setups layouts/l0_l1_training_batch.json --output-dir outputs/batch_l0_l1_training --steps 420 --capture-frames 120; chmod -R a+rwX /workspace/isaac_sim_endoscope_vlca/outputs"
```

## Convert L0/L1 batch EBV frames to GIF

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new/isaac_sim_endoscope_vlca && python3 scripts/make_batch_gifs.py --input-dir outputs/batch_l0_l1_training --output-dir outputs/batch_l0_l1_training_gifs --view ebv --max-frames 160
```
