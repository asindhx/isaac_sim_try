import argparse
import json
import subprocess
import sys
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--setups", default="layouts/l0_l1_training_batch.json")
    parser.add_argument("--output-dir", default="outputs/batch_l0_l1_training")
    parser.add_argument("--isaac-python", default="/isaac-sim/python.sh")
    parser.add_argument("--steps", type=int, default=360)
    parser.add_argument("--capture-frames", type=int, default=96)
    parser.add_argument("--warmup-frames", type=int, default=20)
    parser.add_argument("--target-radius", type=float, default=0.08)
    parser.add_argument("--stop-on-target", action="store_true", default=True)
    parser.add_argument("--fail-fast", action="store_true")
    parser.add_argument("--no-render", action="store_true")
    return parser.parse_args()


def write_single_layout(setup, layout_dir):
    layout_dir.mkdir(parents=True, exist_ok=True)
    path = layout_dir / f"{setup['name']}.json"
    path.write_text(json.dumps(setup, indent=2), encoding="utf-8")
    return path


def main():
    args = parse_args()
    root = Path(__file__).resolve().parent
    setups_path = (root / args.setups).resolve()
    output_root = (root / args.output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    layouts_dir = output_root / "_resolved_layouts"

    data = json.loads(setups_path.read_text(encoding="utf-8"))
    setups = data.get("setups", [])
    if not setups:
        raise RuntimeError(f"No setups found in {setups_path}")

    results = []
    for index, setup in enumerate(setups):
        name = setup["name"]
        print(f"[batch] {index + 1}/{len(setups)} running {name}", flush=True)
        layout_path = write_single_layout(setup, layouts_dir)
        episode_output = output_root / name
        if episode_output.exists():
            import shutil

            shutil.rmtree(episode_output)
        cmd = [
            args.isaac_python,
            str(root / "isaacsim_main.py"),
            "--headless",
            "--layout-json",
            str(layout_path),
            "--episode-index",
            "0",
            "--output-dir",
            str(episode_output),
            "--steps",
            str(args.steps),
            "--warmup-frames",
            str(args.warmup_frames),
            "--capture-frames",
            str(args.capture_frames),
            "--target-radius",
            str(setup.get("control", {}).get("target_radius", args.target_radius)),
            "--stop-on-target",
        ]
        if args.no_render:
            cmd.append("--no-render")
        completed = subprocess.run(cmd, cwd=root)
        fatal_path = episode_output / "fatal_error.txt"
        fatal_text = ""
        if fatal_path.exists():
            fatal_text = fatal_path.read_text(encoding="utf-8", errors="replace")[-4000:]
        result = {
            "name": name,
            "returncode": completed.returncode,
            "output": str(episode_output),
            "finished": (episode_output / "run_finished.txt").exists(),
            "fatal_error": fatal_text,
        }
        results.append(result)
        if completed.returncode != 0 and args.fail_fast:
            print(f"[batch] fail-fast stopped after {name}", flush=True)
            break

    summary = output_root / "batch_summary.json"
    summary.write_text(json.dumps(results, indent=2), encoding="utf-8")
    failed = [item for item in results if item["returncode"] != 0]
    if failed:
        print(f"[batch] failed setups: {[item['name'] for item in failed]}", flush=True)
        print(f"[batch] kept all generated outputs. summary={summary}", flush=True)
        return 0
    print(f"[batch] completed {len(results)} setups. summary={summary}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
