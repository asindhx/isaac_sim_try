from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

import config
from route_planner import RouteTarget, route_target_to_dict


def world_to_pixel(xy: tuple[float, float], image_size: tuple[int, int], margin: int = 48) -> tuple[int, int]:
    width, height = image_size
    plane_w, plane_h = config.PLANE_SIZE
    x, y = xy
    px = margin + (x + plane_w * 0.5) / plane_w * (width - 2 * margin)
    py = margin + (plane_h * 0.5 - y) / plane_h * (height - 2 * margin)
    return int(round(px)), int(round(py))


def world_radius_to_pixels(radius: float, image_size: tuple[int, int], margin: int = 48) -> int:
    width, height = image_size
    plane_w, plane_h = config.PLANE_SIZE
    return max(1, int(round(radius * min((width - 2 * margin) / plane_w, (height - 2 * margin) / plane_h))))


def color_to_u8(color: tuple[float, float, float, float]) -> tuple[int, int, int]:
    return tuple(int(max(0, min(255, c * 255))) for c in color[:3])


def polygon_pixels(center_xy: tuple[float, float], sides: int, radius: float, image_size: tuple[int, int]) -> list[tuple[int, int]]:
    cx, cy = world_to_pixel(center_xy, image_size)
    rr = world_radius_to_pixels(radius, image_size)
    points = []
    for i in range(sides):
        angle = -math.pi / 2 + i * 2 * math.pi / sides
        points.append((int(round(cx + math.cos(angle) * rr)), int(round(cy + math.sin(angle) * rr))))
    return points


def block_bbox(block: config.GuideBlock, image_size: tuple[int, int]) -> list[int]:
    cx, cy = world_to_pixel(block.position, image_size)
    if block.shape == "circle":
        r = world_radius_to_pixels(block.size, image_size)
        return [cx - r, cy - r, cx + r, cy + r]
    sx, sy = config.guide_block_size_xy(block)
    rx = world_radius_to_pixels(sx * 0.5, image_size)
    ry = world_radius_to_pixels(sy * 0.5, image_size)
    return [cx - rx, cy - ry, cx + rx, cy + ry]


def target_bbox(target: config.Target, image_size: tuple[int, int]) -> list[int]:
    cx, cy = world_to_pixel(target.position, image_size)
    r = world_radius_to_pixels(target.size, image_size)
    return [cx - r, cy - r, cx + r, cy + r]


def point_inside_insertable(point: tuple[float, float]) -> bool:
    p = np.array(point, dtype=np.float32)
    for block in config.GUIDE_BLOCKS:
        if block.kind != "insertable":
            continue
        center = np.array(block.position, dtype=np.float32)
        if block.shape == "circle":
            if float(np.linalg.norm(p - center)) <= block.size:
                return True
        else:
            sx, sy = config.guide_block_size_xy(block)
            rel = np.abs(p - center)
            if bool(rel[0] <= sx * 0.5 and rel[1] <= sy * 0.5):
                return True
    return False


def visible_centerline_runs(centerline: list[tuple[float, float]]) -> list[list[tuple[float, float]]]:
    runs: list[list[tuple[float, float]]] = []
    current: list[tuple[float, float]] = []
    for point in centerline:
        if point_inside_insertable(point):
            if len(current) >= 2:
                runs.append(current)
            current = []
            continue
        current.append(point)
    if len(current) >= 2:
        runs.append(current)
    return runs


def draw_debug_frame(path: Path, tip_xy: np.ndarray, heading: float, centerline: list[tuple[float, float]], frame_idx: int, image_size: tuple[int, int]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    image = Image.new("RGB", image_size, (232, 235, 232))
    draw = ImageDraw.Draw(image)

    for clamp in config.START_CLAMPS:
        cx, cy = world_to_pixel(clamp.position, image_size)
        rx = world_radius_to_pixels(clamp.size[0] * 0.5, image_size)
        ry = world_radius_to_pixels(clamp.size[1] * 0.5, image_size)
        draw.rectangle([cx - rx, cy - ry, cx + rx, cy + ry], fill=color_to_u8(clamp.color))

    for block in config.GUIDE_BLOCKS:
        bbox = block_bbox(block, image_size)
        color = color_to_u8(block.color)
        if block.shape == "circle":
            draw.ellipse(bbox, fill=color, outline=(25, 38, 55), width=2)
        else:
            draw.rectangle(bbox, fill=color, outline=(25, 38, 55), width=2)
        if block.kind == "insertable":
            draw.rectangle(bbox, outline=(245, 158, 11), width=4)

    for target in config.TARGETS:
        fill = color_to_u8(target.color)
        draw.polygon(polygon_pixels(target.position, 5, target.size, image_size), fill=fill, outline=(80, 20, 90))

    for visible_run in visible_centerline_runs(centerline):
        pixels = [world_to_pixel(point, image_size) for point in visible_run]
        draw.line(pixels, fill=(12, 15, 18), width=world_radius_to_pixels(max(section.radius for section in config.ENDOSCOPE.sections) * 2.0, image_size))
        draw.line(pixels[:6], fill=(94, 100, 106), width=world_radius_to_pixels(config.ENDOSCOPE.sections[0].radius * 2.0, image_size))

    tip_px = world_to_pixel((float(tip_xy[0]), float(tip_xy[1])), image_size)
    r = world_radius_to_pixels(0.045, image_size)
    draw.ellipse([tip_px[0] - r, tip_px[1] - r, tip_px[0] + r, tip_px[1] + r], fill=(245, 158, 11), outline=(78, 45, 8), width=2)
    nose = (int(tip_px[0] + math.cos(heading) * r * 1.9), int(tip_px[1] - math.sin(heading) * r * 1.9))
    draw.line([tip_px, nose], fill=(78, 45, 8), width=3)
    draw.text((16, 12), f"Isaac Sim endoscope frame {frame_idx:04d}", fill=(30, 35, 40))
    image.save(path)


def build_frame_annotation(frame_idx: int, tip_xy: np.ndarray, heading: float, centerline: list[tuple[float, float]], image_size: tuple[int, int]) -> dict:
    tip_pixel = list(world_to_pixel((float(tip_xy[0]), float(tip_xy[1])), image_size))
    active = config.active_target()
    return {
        "frame_idx": frame_idx,
        "image_size": [image_size[0], image_size[1]],
        "blocks": [
            {
                "id": block.name,
                "kind": block.kind,
                "shape": block.shape,
                "position_world": [float(block.position[0]), float(block.position[1])],
                "bbox_pixel": block_bbox(block, image_size),
                "used_for_path": block.name in config.USED_GUIDE_BLOCK_NAMES,
            }
            for block in config.GUIDE_BLOCKS
        ],
        "target": {
            "id": active.name,
            "shape": active.shape,
            "position_world": [float(active.position[0]), float(active.position[1])],
            "bbox_pixel": target_bbox(active, image_size),
        },
        "endoscope": {
            "tip_world": [float(tip_xy[0]), float(tip_xy[1])],
            "tip_pixel": tip_pixel,
            "heading": float(heading),
            "centerline_world": [[float(x), float(y)] for x, y in centerline],
            "centerline_pixel": [list(world_to_pixel(point, image_size)) for point in centerline],
        },
    }


def bbox_pixel_to_normalized(bbox: list[int], image_size: list[int]) -> tuple[float, float, float, float]:
    width, height = float(image_size[0]), float(image_size[1])
    x0, y0, x1, y1 = [float(v) for v in bbox]
    return x0 / width, y0 / height, (x1 - x0) / width, (y1 - y0) / height


def point_pixel_to_normalized(point: list[int], image_size: list[int]) -> tuple[float, float]:
    return float(point[0]) / float(image_size[0]), float(point[1]) / float(image_size[1])


def write_jpg_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    Image.open(src).convert("RGB").save(dst, quality=92)


def export_vlca_live_episode(
    episode_dir: Path,
    annotations: list[dict],
    samples: list[dict],
    frame_paths: list[Path],
    tip_frame_paths: list[Path],
    route_targets: list[RouteTarget],
    level_label: str,
) -> None:
    if not annotations or not frame_paths:
        return

    frame_count = min(len(annotations), len(frame_paths))
    ev_dir = episode_dir / "frames" / "ev"
    ebv_dir = episode_dir / "frames" / "ebv"
    json_dir = episode_dir / "json"
    json_dir.mkdir(parents=True, exist_ok=True)

    prompts = [
        {"color": "#335c94", "name": "block"},
        {"color": "#f59e0b", "name": "robot tip"},
        {"name": "target", "color": "#b819d1", "subprompts": []},
    ]
    labels = {}
    tip_points = {}
    frame_planning = {}
    aligned_rows = []
    global_plan = [target.name if target.kind != "target" else "Target" for target in route_targets]
    first = annotations[0]
    image_size = first.get("image_size", [1280, 848])
    reference_blocks = []
    for block in first.get("blocks", []):
        x, y, w, h = bbox_pixel_to_normalized(block["bbox_pixel"], image_size)
        reference_blocks.append({"x": round(x, 6), "y": round(y, 6), "w": round(w, 6), "h": round(h, 6), "blockId": block["id"]})

    for idx in range(frame_count):
        name = f"{idx + 1:04d}.jpg"
        ann = annotations[idx]
        image_size = ann.get("image_size", [1280, 848])
        write_jpg_copy(frame_paths[idx], ev_dir / name)
        write_jpg_copy(tip_frame_paths[idx] if idx < len(tip_frame_paths) else frame_paths[idx], ebv_dir / name)

        frame_labels = []
        for block in ann.get("blocks", []):
            x, y, w, h = bbox_pixel_to_normalized(block["bbox_pixel"], image_size)
            frame_labels.append({
                "auto_labeled": True,
                "confidence": 1.0,
                "displayName": "block",
                "prompt": "block",
                "promptIndex": 0,
                "x": round(x, 6),
                "y": round(y, 6),
                "w": round(w, 6),
                "h": round(h, 6),
                "blockId": block["id"],
                "kind": block.get("kind"),
                "used_for_path": block.get("used_for_path", False),
            })

        target = ann.get("target")
        if target and target.get("bbox_pixel"):
            x, y, w, h = bbox_pixel_to_normalized(target["bbox_pixel"], image_size)
            frame_labels.append({
                "auto_labeled": True,
                "confidence": 1.0,
                "displayName": "target",
                "prompt": "target",
                "promptIndex": 2,
                "x": round(x, 6),
                "y": round(y, 6),
                "w": round(w, 6),
                "h": round(h, 6),
                "targetId": target.get("id", "Target"),
            })

        tip_px = ann.get("endoscope", {}).get("tip_pixel")
        if tip_px:
            tx, ty = point_pixel_to_normalized(tip_px, image_size)
            tip_entry = {
                "auto_labeled": True,
                "confidence": 1.0,
                "displayName": "robot tip",
                "h": 0,
                "isPoint": True,
                "prompt": "robot tip",
                "promptIndex": 1,
                "w": 0,
                "x": round(tx, 6),
                "y": round(ty, 6),
            }
            frame_labels.insert(0, tip_entry)
            tip_points[name] = {"x": round(tx, 6), "y": round(ty, 6), "confidence": 1.0}

        labels[name] = frame_labels
        frame_planning[name] = list(global_plan)
        sample = samples[min(idx, len(samples) - 1)] if samples else {}
        aligned_rows.append({
            "episode_uid": f"{level_label}/episode_000000",
            "global_episode_id": f"{level_label}/episode_000000",
            "level_dir": level_label,
            "level_episode_id": "episode_000000",
            "episode_id": "episode_000000",
            "std_frame_idx": idx + 1,
            "raw_episode_relpath": f"{level_label}/episode_000000",
            "raw_row_idx": idx,
            "raw_frame_id": sample.get("step", idx),
            "raw_image_idx": idx + 1,
            "ev_image": f"frames/ev/{name}",
            "ebv_image": f"frames/ebv/{name}",
            "raw_ev_image": f"frames/ev/{name}",
            "raw_ebv_image": f"frames/ebv/{name}",
            "alignment_policy": "simulation_frame_stride",
            "alignment_quality": "sim_sync",
            "task_level": config.experiment_level_value(),
            "task_level_name": level_label,
            "insertion_needed": any(target.kind == "insertable" for target in route_targets),
            "frame_id": sample.get("step", idx),
            "t_mono": round(float(sample.get("step", idx)) * 0.01, 4),
            "joy_ud": "",
            "joy_lr": "",
            "m1_spd": "",
            "m2_spd": "",
            "m3_spd": "",
            "m4_spd": "",
            "m1_pos": "",
            "m2_pos": "",
            "m3_pos": "",
            "m4_pos": "",
            "pwm_duty": "",
            "em_valid": 1,
            "em_x": sample.get("tip_x", ""),
            "em_y": sample.get("tip_y", ""),
            "em_z": 0.0,
            "em_qw": "",
            "em_qx": "",
            "em_qy": "",
            "em_qz": "",
            "ebv_block_boxes_json": json.dumps([item for item in frame_labels if item.get("displayName") == "block"]),
            "ebv_tip_box_json": json.dumps(tip_points.get(name)) if name in tip_points else "null",
            "ev_block_boxes_json": json.dumps([item for item in frame_labels if item.get("displayName") == "block"]),
            "guiding_block_id": sample.get("active_route_target", ""),
            "waypoint_x": sample.get("drive_x", ""),
            "waypoint_y": sample.get("drive_y", ""),
        })

    vlca = {
        "version": "1.0",
        "format": "vlca",
        "exportDate": "simulation",
        "coordSystem": "normalized_xywh",
        "prompts": prompts,
        "labels": labels,
        "tipPoints": tip_points,
        "negatives": [],
        "referenceBlocks": reference_blocks,
        "globalPlanningList": global_plan,
        "framePlanningLists": frame_planning,
        "guidingConfig": {"distanceMetric": "edge", "switchThreshold": 0.03},
        "stats": {
            "totalImages": frame_count,
            "labeledImages": frame_count,
            "negativeImages": 0,
            "totalBoxes": sum(len(v) for v in labels.values()),
            "tipPointFrames": len(tip_points),
        },
    }
    (json_dir / "vlca.json").write_text(json.dumps(vlca, indent=2), encoding="utf-8")
    (json_dir / "yolo_auto_gen.json").write_text(json.dumps(vlca, indent=2), encoding="utf-8")

    if aligned_rows:
        with (episode_dir / "aligned.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(aligned_rows[0].keys()))
            writer.writeheader()
            writer.writerows(aligned_rows)


def write_csv(path: Path, samples: list[dict]) -> None:
    if not samples:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(samples[0].keys()))
        writer.writeheader()
        writer.writerows(samples)


def json_safe(value):
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return json_safe(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    return value
