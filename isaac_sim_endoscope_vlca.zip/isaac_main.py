from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

import config
import exporters
from endoscope_model import (
    append_path_history,
    centerline_from_history,
    clamped_tail_anchor,
    create_tube_mesh_visuals,
    heading_from_centerline,
    hidden_segments_inside_insertable,
    initial_tail_history,
    resolve_solid_overlap,
    update_tube_mesh_visuals,
)
from route_planner import make_route_nodes, polyline_length, position_at_distance, route_target_to_dict, rounded_path


def launch_simulation_app(args):
    if args.dry_run_no_isaac:
        return None
    try:
        from omni.isaac.kit import SimulationApp
    except Exception:
        try:
            from isaacsim import SimulationApp
        except Exception as exc:
            raise RuntimeError(
                "Cannot import Isaac Sim. Use Isaac Sim's python.sh/python.bat, or pass --dry-run-no-isaac."
            ) from exc
    return SimulationApp({
        "headless": not args.viewer,
        "width": args.frame_width,
        "height": args.frame_height,
        "enable_cameras": True,
    })


def update_reached_targets(tip_xy: np.ndarray, route_targets, reached: dict[str, int], step: int, radius: float) -> None:
    for target in route_targets:
        if target.name in reached:
            continue
        target_xy = np.array(target.target_position, dtype=np.float32)
        if float(np.linalg.norm(tip_xy - target_xy)) <= radius:
            reached[target.name] = step


def current_route_target(route_targets, reached: dict[str, int]):
    for target in route_targets:
        if target.name not in reached:
            return target
    return route_targets[-1]


def write_video(frame_paths: list[Path], video_path: Path, fps: int) -> None:
    if not frame_paths:
        return
    try:
        import imageio.v2 as imageio
    except Exception:
        print("imageio is not installed; skipping video export.")
        return
    with imageio.get_writer(video_path, fps=fps) as writer:
        for frame in frame_paths:
            writer.append_data(imageio.imread(frame))


def run(args) -> None:
    app = launch_simulation_app(args)

    world = stage = create_prim = None
    top_camera_path = "/World/top_down_camera"
    tip_camera_path = "/World/tip_camera"
    if not args.dry_run_no_isaac:
        import isaac_scene

        world, stage, _top_camera, _tip_camera, create_prim, sensor_cameras = isaac_scene.build_world(args)
        visual_segments = create_tube_mesh_visuals(stage)
        world.reset()
        isaac_scene.initialize_sensor_cameras(sensor_cameras)
        isaac_scene.warmup_sensor_cameras(world, sensor_cameras, args.sensor_warmup_steps)
    else:
        visual_segments = []
        sensor_cameras = None

    output_dir = Path(args.output_dir)
    episode_dir = output_dir / f"episode_{args.episode_index:06d}" if args.record else output_dir
    render_frames_dir = episode_dir / "render_frames"
    tip_frames_dir = episode_dir / "tip_frames"
    debug_frames_dir = episode_dir / "debug_frames"
    episode_dir.mkdir(parents=True, exist_ok=True)
    for directory in (render_frames_dir, tip_frames_dir, debug_frames_dir):
        directory.mkdir(parents=True, exist_ok=True)
    offscreen_capture = None
    if app is not None and args.record and args.record_3d and args.capture_mode == "replicator":
        import isaac_scene

        offscreen_capture = isaac_scene.ReplicatorCapture(
            {"top": top_camera_path, "tip": tip_camera_path},
            (args.frame_width, args.frame_height),
            episode_dir / "_replicator_capture",
        )

    level_label = config.experiment_level_label()
    selected_target = config.active_target()
    selected_target_xy = np.array(selected_target.position, dtype=np.float32)
    route_nodes, route_targets = make_route_nodes(args.solid_clearance)
    path_points = rounded_path(route_nodes, samples_per_corner=args.turn_samples, corner_cut=args.turn_corner_cut)
    required_steps = int(math.ceil(polyline_length(path_points) / max(args.drive_speed * args.dt, 1e-6))) + 30
    simulation_steps = max(args.max_steps, required_steps)
    endoscope_radius = max(section.radius for section in config.ENDOSCOPE.sections)
    tail_anchor_xy = clamped_tail_anchor()
    path_history = initial_tail_history(args.tail_length)
    previous_drive_xy = np.array(config.START_POSITION, dtype=np.float32)
    reached_targets: dict[str, int] = {}

    samples = []
    annotations = []
    render_frame_paths = []
    tip_frame_paths = []
    debug_frame_paths = []

    for step in range(simulation_steps):
        drive_xy, motion_target_name = position_at_distance(path_points, step * args.drive_speed * args.dt, route_targets)
        if args.contact_correction:
            drive_xy, head_contact = resolve_solid_overlap(drive_xy, endoscope_radius)
        else:
            _, head_contact = resolve_solid_overlap(drive_xy, endoscope_radius)
        append_path_history(path_history, drive_xy, args.history_spacing)

        delta = drive_xy - previous_drive_xy
        fallback_yaw = math.atan2(float(delta[1]), float(delta[0])) if float(np.linalg.norm(delta)) > 1e-6 else 0.0
        centerline, proxy_contact = centerline_from_history(path_history, args.visible_endoscope_length)
        tip_xy = np.array(centerline[0], dtype=np.float32)
        yaw = heading_from_centerline(centerline, fallback_yaw)
        distance_to_target = float(np.linalg.norm(tip_xy - selected_target_xy))
        hidden = hidden_segments_inside_insertable(centerline)
        contact_norm = max(proxy_contact, head_contact)

        if stage is not None:
            if args.record_3d:
                import isaac_scene

                isaac_scene.update_tip_camera_pose(stage, tip_camera_path, tip_xy, yaw, args.tip_camera_height)
            update_tube_mesh_visuals(stage, visual_segments, centerline)
            world.step(render=not args.no_render or args.record_3d)

        update_reached_targets(tip_xy, route_targets, reached_targets, step, args.route_reach_radius)
        active_route_target = current_route_target(route_targets, reached_targets)

        samples.append({
            "step": step,
            "level": level_label,
            "active_route_target": active_route_target.name,
            "motion_target": motion_target_name,
            "reached_route_targets": "|".join(reached_targets.keys()),
            "drive_x": float(drive_xy[0]),
            "drive_y": float(drive_xy[1]),
            "tip_x": float(tip_xy[0]),
            "tip_y": float(tip_xy[1]),
            "tail_anchor_x": float(tail_anchor_xy[0]),
            "tail_anchor_y": float(tail_anchor_xy[1]),
            "tail_anchor_inside_clamp_gap": 1,
            "yaw": float(yaw),
            "distance_to_target": distance_to_target,
            "contact_force_norm": float(contact_norm),
            "insertable_occluded": int(bool(hidden)),
            "hidden_insertable_segments": "|".join(str(idx) for idx in sorted(hidden)),
            "used_guide_blocks": "|".join(config.USED_GUIDE_BLOCK_NAMES),
        })

        if args.record and step % args.frame_stride == 0:
            frame_idx = len(debug_frame_paths)
            debug_path = debug_frames_dir / f"{frame_idx:06d}.png"
            exporters.draw_debug_frame(debug_path, tip_xy, yaw, centerline, frame_idx, (args.frame_width, args.frame_height))
            debug_frame_paths.append(debug_path)
            render_path = render_frames_dir / f"{frame_idx:06d}.png"
            tip_path = tip_frames_dir / f"{frame_idx:06d}.png"
            captured_top = False
            captured_tip = False
            if stage is not None and args.record_3d:
                import isaac_scene

                if sensor_cameras is not None and args.capture_mode == "sensor":
                    captured_top = isaac_scene.capture_sensor_frame(sensor_cameras["top"], render_path)
                    captured_tip = isaac_scene.capture_sensor_frame(sensor_cameras["tip"], tip_path)
                elif offscreen_capture is not None:
                    offscreen_capture.step()
                    captured_top = offscreen_capture.capture("top", render_path)
                    captured_tip = offscreen_capture.capture("tip", tip_path)
                else:
                    captured_top = isaac_scene.capture_viewport_frame(top_camera_path, render_path)
                    captured_tip = isaac_scene.capture_viewport_frame(tip_camera_path, tip_path)
                if not captured_top or not captured_tip:
                    raise RuntimeError(
                        f"3D capture failed in {args.capture_mode} mode: top={captured_top}, tip={captured_tip}; "
                        "refusing to write 2D debug frames as render_frames/tip_frames."
                    )
            if not captured_top:
                exporters.write_jpg_copy(debug_path, render_path.with_suffix(".jpg"))
                render_path = render_path.with_suffix(".jpg")
            if not captured_tip:
                exporters.write_jpg_copy(debug_path, tip_path.with_suffix(".jpg"))
                tip_path = tip_path.with_suffix(".jpg")
            render_frame_paths.append(render_path)
            tip_frame_paths.append(tip_path)

            annotation = exporters.build_frame_annotation(frame_idx, tip_xy, yaw, centerline, (args.frame_width, args.frame_height))
            annotation["route"] = {
                "targets": [route_target_to_dict(target) for target in route_targets],
                "active_target": route_target_to_dict(active_route_target),
                "reached_target_names": list(reached_targets.keys()),
            }
            annotation["physics"] = {"contact_force_norm": float(contact_norm)}
            annotation["visibility"] = {
                "insertable_occluded": bool(hidden),
                "hidden_insertable_segments": sorted(hidden),
            }
            annotation["tail_constraint"] = {
                "model": "long_tail_clamped_at_start",
                "tail_length": args.tail_length,
                "anchor_world": [float(tail_anchor_xy[0]), float(tail_anchor_xy[1])],
                "anchor_inside_clamp_gap": True,
            }
            annotations.append(annotation)

        previous_drive_xy = drive_xy
        if distance_to_target <= args.success_radius:
            break

    exporters.write_csv(episode_dir / "trajectory.csv", samples)
    if args.record:
        metadata = {
            "mode": "isaac_sim_visible_tip_guided_block_route_endoscope",
            "episode_index": args.episode_index,
            "level": level_label,
            "tail_model": "long_tail_clamped_at_start",
            "tail_length": args.tail_length,
            "visible_endoscope_length": args.visible_endoscope_length,
            "moving_end": "metal_lens_tip",
            "used_guide_blocks": list(config.USED_GUIDE_BLOCK_NAMES),
            "active_target_name": selected_target.name,
            "target_position": list(selected_target.position),
            "route_rule": "start clamp -> graze solid guide blocks / pass through insertable blocks -> active target",
            "route_targets": [route_target_to_dict(target) for target in route_targets],
            "path_points": [[float(x), float(y)] for x, y in path_points],
            "success": bool(samples and samples[-1]["distance_to_target"] <= args.success_radius),
            "render_frame_count": len(render_frame_paths),
            "tip_frame_count": len(tip_frame_paths),
            "debug_frame_count": len(debug_frame_paths),
            "frame_stride": args.frame_stride,
            "image_size": [args.frame_width, args.frame_height],
            "camera": {"view": "top_down_3d", "height": args.camera_height, "fov": args.camera_fov},
            "tip_camera": {"view": "endoscope_tip_forward", "height": args.tip_camera_height, "fov": args.tip_camera_fov},
            "control": {
                "drive_speed": args.drive_speed,
                "history_spacing": args.history_spacing,
                "contact_correction": args.contact_correction,
            },
            "backend": "isaac_sim" if not args.dry_run_no_isaac else "dry_run_no_isaac",
        }
        (episode_dir / "metadata.json").write_text(json.dumps(exporters.json_safe(metadata), indent=2), encoding="utf-8")
        (episode_dir / "annotations.json").write_text(json.dumps(exporters.json_safe(annotations), indent=2), encoding="utf-8")
        if args.export_vlca:
            exporters.export_vlca_live_episode(episode_dir, annotations, samples, render_frame_paths, tip_frame_paths, route_targets, level_label)
        if args.video:
            write_video(render_frame_paths, episode_dir / "video_3d.mp4", args.video_fps)
            write_video(tip_frame_paths, episode_dir / "video_tip.mp4", args.video_fps)
            write_video(debug_frame_paths, episode_dir / "debug_route.mp4", args.video_fps)
        if stage is not None:
            import isaac_scene

            isaac_scene.save_stage(stage, episode_dir)

    print(f"Isaac Sim endoscope level: {level_label}")
    print(f"Finished {len(samples)} steps.")
    print(f"Trajectory saved to: {episode_dir / 'trajectory.csv'}")
    if args.record:
        print(f"Annotations saved to: {episode_dir / 'annotations.json'}")
        print(f"VLCA JSON saved to: {episode_dir / 'json' / 'vlca.json'}")

    if offscreen_capture is not None:
        offscreen_capture.close()

    if app is not None:
        app.close()


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--viewer", action="store_true")
    parser.add_argument("--dry-run-no-isaac", action="store_true", help="Generate the same output structure without launching Isaac Sim.")
    parser.add_argument("--no-render", action="store_true", help="Step Isaac Sim without viewport rendering.")
    parser.add_argument("--output-dir", default="outputs/endoscope_isaac_vlca")
    parser.add_argument("--dt", type=float, default=0.01)
    parser.add_argument("--max-steps", type=int, default=2500)
    parser.add_argument("--success-radius", type=float, default=0.10)
    parser.add_argument("--drive-speed", type=float, default=0.12)
    parser.add_argument("--solid-clearance", type=float, default=0.10)
    parser.add_argument("--history-spacing", type=float, default=0.012)
    parser.add_argument("--visible-endoscope-length", type=float, default=4.5)
    parser.add_argument("--tail-length", type=float, default=5.5)
    parser.add_argument("--route-reach-radius", type=float, default=0.075)
    parser.add_argument("--turn-samples", type=int, default=8)
    parser.add_argument("--turn-corner-cut", type=float, default=0.22)
    parser.add_argument("--contact-correction", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--record-3d", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--capture-mode", choices=("sensor", "replicator", "viewport"), default="sensor")
    parser.add_argument("--sensor-warmup-steps", type=int, default=30)
    parser.add_argument("--export-vlca", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--video", action="store_true")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--frame-stride", type=int, default=10)
    parser.add_argument("--frame-width", type=int, default=1280)
    parser.add_argument("--frame-height", type=int, default=848)
    parser.add_argument("--camera-height", type=float, default=3.0)
    parser.add_argument("--camera-fov", type=float, default=46.0)
    parser.add_argument("--tip-camera-height", type=float, default=0.085)
    parser.add_argument("--tip-camera-fov", type=float, default=82.0)
    parser.add_argument("--video-fps", type=int, default=24)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
