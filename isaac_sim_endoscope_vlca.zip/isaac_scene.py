from __future__ import annotations

import math
from pathlib import Path
import shutil

import numpy as np

import config

_CAPTURE_VIEWPORT_WINDOW = None
_CAPTURE_VIEWPORT_API = None


def require_isaac():
    try:
        from omni.isaac.core import World
        from omni.isaac.core.objects import DynamicCuboid, FixedCuboid, VisualCuboid
        from omni.isaac.core.utils.prims import create_prim
        from pxr import Gf, UsdGeom, UsdPhysics
    except Exception as exc:
        raise RuntimeError(
            "Isaac Sim Python modules are not available. Run this with Isaac Sim's python.sh/python.bat."
        ) from exc
    return World, DynamicCuboid, FixedCuboid, VisualCuboid, create_prim, Gf, UsdGeom, UsdPhysics


def require_camera_class():
    try:
        from isaacsim.sensors.camera import Camera
        return Camera
    except Exception:
        from omni.isaac.sensor import Camera
        return Camera


def rgba_to_rgb(color: tuple[float, float, float, float]) -> np.ndarray:
    return np.array(color[:3], dtype=np.float32)


def prim_path(name: str) -> str:
    clean = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in name)
    return f"/World/{clean}"


def add_material(stage, path: str, color: tuple[float, float, float, float]):
    from pxr import Gf, Sdf, UsdShade

    material = UsdShade.Material.Define(stage, path)
    shader = UsdShade.Shader.Define(stage, f"{path}/Shader")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*color[:3]))
    shader.CreateInput("opacity", Sdf.ValueTypeNames.Float).Set(float(color[3]))
    shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(0.72)
    material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    return material


def bind_material(prim, material):
    from pxr import UsdShade

    UsdShade.MaterialBindingAPI(prim).Bind(material)


def add_collision(stage, prim):
    from pxr import UsdPhysics

    UsdPhysics.CollisionAPI.Apply(prim)


def make_pentagon_mesh(stage, path: str, radius: float, height: float, color):
    from pxr import Gf, UsdGeom

    mesh = UsdGeom.Mesh.Define(stage, path)
    top_z = height
    points = []
    for z in (0.0, top_z):
        for i in range(5):
            angle = math.pi / 2 + i * 2 * math.pi / 5
            points.append(Gf.Vec3f(math.cos(angle) * radius, math.sin(angle) * radius, z))
    faces = [[0, 1, 2, 3, 4], [9, 8, 7, 6, 5]]
    for i in range(5):
        faces.append([i, (i + 1) % 5, 5 + (i + 1) % 5, 5 + i])
    mesh.CreatePointsAttr(points)
    mesh.CreateFaceVertexCountsAttr([len(face) for face in faces])
    mesh.CreateFaceVertexIndicesAttr([idx for face in faces for idx in face])
    material = add_material(stage, f"{path}_mat", color)
    bind_material(mesh.GetPrim(), material)
    return mesh.GetPrim()


def add_cylinder(stage, create_prim, name: str, xy: tuple[float, float], radius: float, height: float, color, collision: bool):
    path = prim_path(name)
    prim = create_prim(
        prim_path=path,
        prim_type="Cylinder",
        position=(float(xy[0]), float(xy[1]), height * 0.5),
        scale=(radius, radius, height * 0.5),
    )
    material = add_material(stage, f"{path}_mat", color)
    bind_material(prim, material)
    if collision:
        add_collision(stage, prim)
    return prim


def add_box(stage, FixedCuboid, name: str, xy: tuple[float, float], size: tuple[float, float], height: float, color, collision: bool):
    path = prim_path(name)
    obj = FixedCuboid(
        prim_path=path,
        name=name,
        position=np.array([xy[0], xy[1], height * 0.5], dtype=np.float32),
        scale=np.array([size[0], size[1], height], dtype=np.float32),
        color=rgba_to_rgb(color),
    )
    prim = stage.GetPrimAtPath(path)
    if collision:
        add_collision(stage, prim)
    return obj


def insertable_occluder_height() -> float:
    tube_z = config.ENDOSCOPE.base_position[2]
    tube_radius = max(section.radius for section in config.ENDOSCOPE.sections)
    return tube_z + tube_radius * 2.5


def add_scene_camera(stage, create_prim, name: str, position, lookat, focal_length=24.0, horizontal_aperture=20.955):
    path = prim_path(name)
    prim = create_prim(path, "Camera", position=position)
    from pxr import Gf, UsdGeom

    camera = UsdGeom.Camera(prim)
    camera.CreateFocalLengthAttr(float(focal_length))
    camera.CreateHorizontalApertureAttr(float(horizontal_aperture))
    set_camera_lookat(prim, position, lookat)
    return prim


def set_camera_lookat(camera_prim, position, lookat):
    from pxr import Gf, UsdGeom

    pos = Gf.Vec3d(*position)
    target = Gf.Vec3d(*lookat)
    direction = target - pos
    up = Gf.Vec3d(0.0, 0.0, 1.0)
    if abs(direction.GetNormalized() * up) > 0.99:
        up = Gf.Vec3d(0.0, 1.0, 0.0)
    view = Gf.Matrix4d().SetLookAt(pos, target, up)
    xform = UsdGeom.Xformable(camera_prim)
    xform.ClearXformOpOrder()
    xform.AddTransformOp().Set(view.GetInverse())


def build_world(args):
    World, DynamicCuboid, FixedCuboid, VisualCuboid, create_prim, Gf, UsdGeom, UsdPhysics = require_isaac()

    world = World(stage_units_in_meters=1.0)
    stage = world.stage
    world.scene.add_default_ground_plane()

    plane_w, plane_h = config.PLANE_SIZE
    add_box(stage, FixedCuboid, "experiment_table", (0.0, 0.0), (plane_w, plane_h), 0.025, (0.82, 0.84, 0.82, 1.0), True)

    for clamp in config.START_CLAMPS:
        add_box(stage, FixedCuboid, clamp.name, clamp.position, clamp.size, clamp.height, clamp.color, True)

    for block in config.GUIDE_BLOCKS:
        collision = block.kind == "solid"
        if block.shape == "circle":
            add_cylinder(stage, create_prim, block.name, block.position, block.size, block.height, block.color, collision)
        else:
            height = insertable_occluder_height() if block.kind == "insertable" else block.height
            add_box(stage, FixedCuboid, block.name, block.position, config.guide_block_size_xy(block), height, block.color, collision)

    for target in config.TARGETS:
        path = prim_path(target.name)
        prim = make_pentagon_mesh(stage, path, target.size, target.height, target.color)
        from pxr import UsdGeom

        xform = UsdGeom.Xformable(prim)
        xform.AddTranslateOp().Set((target.position[0], target.position[1], 0.0))

    top_camera_prim = add_scene_camera(
        stage,
        create_prim,
        "top_down_camera",
        (0.0, 0.0, args.camera_height),
        (0.0, 0.0, 0.0),
        focal_length=max(8.0, 46.0 - args.camera_fov * 0.35),
    )
    tip_camera_prim = add_scene_camera(
        stage,
        create_prim,
        "tip_camera",
        (config.START_POSITION[0] - 0.05, config.START_POSITION[1], args.tip_camera_height),
        (config.START_POSITION[0] + 0.35, config.START_POSITION[1], args.tip_camera_height * 0.72),
        focal_length=max(8.0, 46.0 - args.tip_camera_fov * 0.35),
    )

    sensor_cameras = None
    if getattr(args, "capture_mode", "") == "sensor":
        Camera = require_camera_class()
        resolution = (int(args.frame_width), int(args.frame_height))
        sensor_cameras = {
            "top": Camera(prim_path=top_camera_prim.GetPath().pathString, name="top_camera_sensor", resolution=resolution),
            "tip": Camera(prim_path=tip_camera_prim.GetPath().pathString, name="tip_camera_sensor", resolution=resolution),
        }

    return world, stage, top_camera_prim, tip_camera_prim, create_prim, sensor_cameras


def save_stage(stage, output_dir: Path) -> None:
    usd_path = output_dir / "endoscope_isaac_scene.usd"
    stage.GetRootLayer().Export(str(usd_path))


def initialize_sensor_cameras(sensor_cameras: dict | None) -> None:
    if not sensor_cameras:
        return
    for camera in sensor_cameras.values():
        camera.initialize()
        if hasattr(camera, "add_rgb_to_frame"):
            camera.add_rgb_to_frame()


def warmup_sensor_cameras(world, sensor_cameras: dict | None, steps: int) -> None:
    if not sensor_cameras:
        return
    for _ in range(max(1, int(steps))):
        world.step(render=True)


def capture_sensor_frame(camera, image_path: Path) -> bool:
    try:
        from PIL import Image

        image = None
        for getter in ("get_rgb", "get_rgba"):
            if hasattr(camera, getter):
                value = getattr(camera, getter)()
                if value is not None:
                    image = value
                    break
        if image is None and hasattr(camera, "get_current_frame"):
            frame = camera.get_current_frame()
            for key in ("rgb", "rgba"):
                if isinstance(frame, dict) and frame.get(key) is not None:
                    image = frame[key]
                    break
        if image is None:
            return False
        image = np.asarray(image)
        if image.size == 0:
            return False
        if image.ndim == 4:
            image = image[0]
        if image.size == 0:
            return False
        if image.dtype != np.uint8:
            if float(np.nanmax(image)) <= 1.0:
                image = np.clip(image * 255.0, 0, 255)
            image = image.astype(np.uint8)
        image_path.parent.mkdir(parents=True, exist_ok=True)
        Image.fromarray(image[..., :3]).save(image_path)
        return image_path.exists() and image_path.stat().st_size > 0
    except Exception as exc:
        print(f"3D camera capture failed: {exc!r}")
        return False


def _save_rgb_array(image, image_path: Path) -> bool:
    from PIL import Image

    image = np.asarray(image)
    if image.size == 0:
        return False
    if isinstance(image, np.ndarray) and image.dtype.names:
        for key in ("rgb", "rgba", "data"):
            if key in image.dtype.names:
                image = image[key]
                break
    if image.ndim == 4:
        image = image[0]
    if image.ndim < 3 or image.size == 0:
        return False
    if image.dtype != np.uint8:
        finite = image[np.isfinite(image)]
        if finite.size == 0:
            return False
        if float(np.max(finite)) <= 1.0:
            image = np.clip(image * 255.0, 0, 255)
        image = image.astype(np.uint8)
    image_path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(image[..., :3]).save(image_path)
    return image_path.exists() and image_path.stat().st_size > 0


class ReplicatorCapture:
    def __init__(self, camera_paths: dict[str, str], resolution: tuple[int, int], output_dir: Path, warmup_updates: int = 12):
        import omni.kit.app
        import omni.replicator.core as rep

        self.rep = rep
        self.app = omni.kit.app.get_app()
        self.render_products = {}
        self.annotators = {}
        self.writer_dirs = {}
        self.writers = {}
        output_dir.mkdir(parents=True, exist_ok=True)
        for name, camera_path in camera_paths.items():
            writer_dir = output_dir / name
            writer_dir.mkdir(parents=True, exist_ok=True)
            render_product = rep.create.render_product(camera_path, resolution)
            annotator = rep.AnnotatorRegistry.get_annotator("rgb", device="cpu")
            annotator.attach([render_product])
            try:
                writer = rep.WriterRegistry.get("BasicWriter")
                writer.initialize(output_dir=str(writer_dir), rgb=True)
                writer.attach([render_product])
                self.writers[name] = writer
            except Exception as exc:
                print(f"3D writer setup skipped for {name}: {exc!r}")
            self.render_products[name] = render_product
            self.annotators[name] = annotator
            self.writer_dirs[name] = writer_dir
        for _ in range(max(1, warmup_updates)):
            self.app.update()

    def step(self, rt_subframes: int = 4):
        try:
            self.rep.orchestrator.step(rt_subframes=rt_subframes)
        except TypeError:
            self.rep.orchestrator.step()
        try:
            self.rep.orchestrator.wait_until_complete()
        except Exception:
            pass
        for _ in range(8):
            self.app.update()

    def capture(self, name: str, image_path: Path) -> bool:
        try:
            annotator = self.annotators[name]
            data = annotator.get_data()
            if isinstance(data, dict):
                for key in ("data", "rgb", "rgba"):
                    if data.get(key) is not None:
                        data = data[key]
                        break
                else:
                    data = None
            if data is None:
                return self._copy_latest_writer_frame(name, image_path)
            if _save_rgb_array(data, image_path):
                return True
            return self._copy_latest_writer_frame(name, image_path)
        except Exception as exc:
            print(f"3D offscreen camera capture failed: {exc!r}")
            return self._copy_latest_writer_frame(name, image_path)

    def _copy_latest_writer_frame(self, name: str, image_path: Path) -> bool:
        writer_dir = self.writer_dirs.get(name)
        if writer_dir is None:
            return False
        frames = []
        for pattern in ("*.png", "*.jpg", "*.jpeg"):
            frames.extend(writer_dir.rglob(pattern))
        if not frames:
            return False
        latest = max(frames, key=lambda path: path.stat().st_mtime)
        image_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(latest, image_path)
        return image_path.exists() and image_path.stat().st_size > 0

    def close(self):
        for name, annotator in self.annotators.items():
            try:
                annotator.detach([self.render_products[name]])
            except Exception:
                try:
                    annotator.detach()
                except Exception:
                    pass
        for name, writer in self.writers.items():
            try:
                writer.detach()
            except Exception:
                pass


def _active_or_new_viewport(width: int, height: int):
    global _CAPTURE_VIEWPORT_WINDOW, _CAPTURE_VIEWPORT_API

    if _CAPTURE_VIEWPORT_API is not None:
        return _CAPTURE_VIEWPORT_API

    try:
        from omni.kit.viewport.utility import create_viewport_window

        _CAPTURE_VIEWPORT_WINDOW = create_viewport_window("EndoscopeCaptureViewport", width=width, height=height)
        _CAPTURE_VIEWPORT_API = (
            getattr(_CAPTURE_VIEWPORT_WINDOW, "viewport_api", None)
            or getattr(_CAPTURE_VIEWPORT_WINDOW, "viewport", None)
            or _CAPTURE_VIEWPORT_WINDOW
        )
        return _CAPTURE_VIEWPORT_API
    except Exception as exc:
        print(f"3D viewport creation failed: {exc!r}")
        return None


def capture_viewport_frame(camera_path: str, image_path: Path, width: int, height: int, updates: int = 12, retries: int = 3) -> bool:
    try:
        import omni.kit.app
        from omni.kit.viewport.utility import capture_viewport_to_file

        viewport = _active_or_new_viewport(width, height)
        if viewport is None:
            print("3D viewport capture skipped: no active viewport and could not create one.")
            return False
        try:
            from pxr import Sdf

            viewport.camera_path = Sdf.Path(camera_path)
        except Exception:
            viewport.camera_path = camera_path
        if hasattr(viewport, "resolution"):
            viewport.resolution = (int(width), int(height))
        if hasattr(viewport, "set_texture_resolution"):
            viewport.set_texture_resolution((int(width), int(height)))
        image_path.parent.mkdir(parents=True, exist_ok=True)
        app = omni.kit.app.get_app()
        for attempt in range(max(1, retries)):
            if image_path.exists():
                image_path.unlink()
            for _ in range(max(1, updates)):
                app.update()
            capture = capture_viewport_to_file(viewport, str(image_path))
            if hasattr(capture, "wait_for_result"):
                try:
                    capture.wait_for_result()
                except TypeError:
                    capture.wait_for_result(timeout=10)
            for _ in range(max(1, updates * 3)):
                app.update()
                if image_path.exists() and image_path.stat().st_size > 0:
                    return True
            print(f"3D viewport capture retry {attempt + 1}/{retries} did not produce {image_path.name}.")
        return False
    except Exception as exc:
        print(f"3D viewport capture skipped: {exc!r}")
        return False


def update_tip_camera_pose(stage, camera_path: str, tip_xy, yaw: float, height: float) -> None:
    forward = np.array([math.cos(yaw), math.sin(yaw)], dtype=np.float32)
    pos_xy = np.array(tip_xy, dtype=np.float32) - forward * 0.045
    lookat_xy = np.array(tip_xy, dtype=np.float32) + forward * 0.34
    prim = stage.GetPrimAtPath(camera_path)
    set_camera_lookat(
        prim,
        (float(pos_xy[0]), float(pos_xy[1]), float(height)),
        (float(lookat_xy[0]), float(lookat_xy[1]), float(height * 0.72)),
    )
