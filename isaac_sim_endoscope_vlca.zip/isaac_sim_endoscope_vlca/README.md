# Isaac Sim endoscope VLCA package

This package is the Isaac Sim side of the endoscope navigation project.

It is intentionally separated from the Genesis package. Genesis can still be
used for the old approximate data pipeline, while this package checks and uses
Isaac Sim / USD / PhysX features for scene construction, rigid colliders,
camera output, and later endoscope physics.

## Run order

1. Run the capability check first.
2. Only run the simulation entry after the check passes.

## Output layout

The output folder follows the same structure used by the Genesis package:

```text
outputs/endoscope_single_latest/episode_000000/
  frames/ebv/
  frames/ev/
  render_frames/
  tip_frames/
  debug_frames/
  trajectory.csv
  control_commands.csv
  annotations.json
  metadata.json
  scene.usd
```

`ebv` means the top-view camera. `ev` means the endoscope-view camera.

## Important note

This package should not use a hand-written rod physics approximation. The
endoscope physics must be built from Isaac Sim / PhysX components or another
real simulator backend. If a feature is not available in Isaac Sim, the code
should fail clearly instead of pretending that the physics is correct.

