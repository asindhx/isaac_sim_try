# Run commands

Clone:

```bash
cd /home/wu/Documents/isaac-sim_xizi && rm -rf isaac_sim_try_new_20260728 && git clone https://github.com/asindhx/isaac_sim_try.git isaac_sim_try_new_20260728
```

Run L0/L1 batch:

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new_20260728/isaac_sim_endoscope_vlca && rm -rf outputs/batch_l0_l1_training && docker run --rm --user 0:0 --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "bash /workspace/isaac_sim_endoscope_vlca/run_l0_l1_batch.sh"
```

Check outputs:

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new_20260728/isaac_sim_endoscope_vlca && find outputs/batch_l0_l1_training -maxdepth 4 -type f | sort | head -120 && python3 scripts/check_output_format.py --root outputs/batch_l0_l1_training --min-episodes 5
```
