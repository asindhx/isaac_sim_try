# Run commands

## Clone

```bash
cd /home/wu/Documents/genesis_projectxizi
git clone https://github.com/asindhx/isaac_sim_try.git
cd /home/wu/Documents/genesis_projectxizi/isaac_sim_try
```

If using the zip package, unzip `isaac_sim_endoscope_vlca.zip` and enter the
extracted folder.

## Capability check

Replace the Isaac Sim path if your machine uses a different install location:

```bash
cd /home/wu/Documents/genesis_projectxizi/isaac_sim_try/isaac_sim_endoscope_vlca && /home/wu/Documents/isaac-sim_xizi/isaacsim/python.sh scripts/check_isaacsim_capabilities.py
```

Expected ending:

```text
ISAACSIM_CAPABILITY_CHECK_PASSED
```

## Run one Isaac Sim scene

```bash
cd /home/wu/Documents/genesis_projectxizi/isaac_sim_try/isaac_sim_endoscope_vlca && /home/wu/Documents/isaac-sim_xizi/isaacsim/python.sh isaacsim_main.py --headless --output-dir "$PWD/outputs/endoscope_single_latest"
```

## Convert EBV frames to GIF

```bash
cd /home/wu/Documents/genesis_projectxizi/isaac_sim_try/isaac_sim_endoscope_vlca && python -c "from pathlib import Path; from PIL import Image; d=Path('outputs/endoscope_single_latest/episode_000000/frames/ebv'); frames=sorted(d.glob('*.png'))+sorted(d.glob('*.jpg')); print('frames',len(frames)); assert frames, 'no EBV frames found'; step=max(1,len(frames)//160); imgs=[Image.open(p).convert('RGB').resize((640,424)) for p in frames[::step][:160]]; out=d.parent.parent/'preview_ebv.gif'; imgs[0].save(out,save_all=True,append_images=imgs[1:],duration=60,loop=0,optimize=True); print('saved',out)"
```

