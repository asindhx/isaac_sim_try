# Run commands

Clone:

```bash
cd /home/wu/Documents/isaac-sim_xizi && rm -rf isaac_sim_try_new_20260728 && git clone https://github.com/asindhx/isaac_sim_try.git isaac_sim_try_new_20260728
```

Run stable L0/L1 batch:

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new_20260728/isaac_sim_endoscope_vlca && rm -rf outputs/batch_l0_l1_training && docker run --rm --user 0:0 --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "bash /workspace/isaac_sim_endoscope_vlca/run_l0_l1_batch.sh"
```

Run real-reference L0/L1 batch:

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new_20260728/isaac_sim_endoscope_vlca && rm -rf outputs/batch_l0_l1_real_reference && docker run --rm --user 0:0 --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "SETUPS=layouts/l0_l1_real_reference_batch.json OUTPUT_DIR=outputs/batch_l0_l1_real_reference MIN_EPISODES=11 bash /workspace/isaac_sim_endoscope_vlca/run_l0_l1_batch.sh"
```

Check outputs:

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new_20260728/isaac_sim_endoscope_vlca && find outputs/batch_l0_l1_training -maxdepth 4 -type f | sort | head -120 && python3 scripts/check_output_format.py --root outputs/batch_l0_l1_training --min-episodes 5
```

Prepare policy dataset:

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new_20260728/isaac_sim_endoscope_vlca && python3 scripts/prepare_policy_dataset.py --inputs /path/to/episode_or_zip_1 /path/to/episode_or_zip_2 --output-dir outputs/policy_dataset
```

Train policy baseline:

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try_new_20260728/isaac_sim_endoscope_vlca && python3 scripts/train_policy_baseline.py --dataset outputs/policy_dataset/policy_dataset.npz --output-dir outputs/policy_baseline
```

Windows policy baseline:

```powershell
cd C:\path\to\isaac_sim_endoscope_vlca; powershell -ExecutionPolicy Bypass -File .\run_policy_baseline_windows.ps1
```

Windows policy baseline with custom inputs:

```powershell
cd C:\path\to\isaac_sim_endoscope_vlca; python scripts\prepare_policy_dataset.py --inputs "E:\xizi\data_0421_labeled\data_0421_L0\20260421-183638_data_collection.zip" "E:\xizi\data_0512_L3.5\20260512-144412_data_collection.zip" --output-dir outputs\policy_dataset; python scripts\train_policy_baseline.py --dataset outputs\policy_dataset\policy_dataset.npz --output-dir outputs\policy_baseline
```
