import argparse
import json
import subprocess
import sys
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--setups", default="layouts/l0_l1_training_batch.json")
    parser.add_argument("--output-dir", default="outputs/batch_l0_l1_training")
    parser.add_argument("--isaac-python", default="/isaac-sim/python.sh")
    parser.add_argument("--steps", type=int, default=360)
    parser.add_argument("--capture-frames", type=int, default=48)
    parser.add_argument("--warmup-frames", type=int, default=20)
    parser.add_argument("--target-radius", type=float, default=0.08)
    parser.add_argument("--stop-on-target", action="store_true", default=True)
    parser.add_argument("--no-render", action="store_true")
    parser.add_argument("--fail-fast", action="store_true")
    return parser.parse_args()


def write_single_layout(setup, layout_dir):
    layout_dir.mkdir(parents=True, exist_ok=True)
    path = layout_dir / f"{setup['name']}.json"
    path.write_text(json.dumps(setup, indent=2), encoding="utf-8")
    return path


def tree_lines(path, max_depth=4):
    if not path.exists():
        return []
    root_depth = len(path.parts)
    lines = []
    for item in sorted(path.rglob("*")):
        depth = len(item.parts) - root_depth
        if depth > max_depth:
            continue
        marker = "/" if item.is_dir() else ""
        lines.append(str(item.relative_to(path)).replace("\\", "/") + marker)
    return lines


def write_output_trees(output_root):
    output_lines = tree_lines(output_root, max_depth=4)
    image_lines = [
        line for line in output_lines
        if line.lower().endswith((".jpg", ".jpeg", ".png"))
    ]
    (output_root / "output_tree.txt").write_text("\n".join(output_lines) + "\n", encoding="utf-8")
    (output_root / "image_tree.txt").write_text("\n".join(image_lines) + "\n", encoding="utf-8")
    return {"files": len(output_lines), "images": len(image_lines)}


def episode_stats(episode_output):
    episode_dir = episode_output / "episode_000000"
    images = list(episode_dir.glob("frames/ebv/*.jpg")) + list(episode_dir.glob("frames/ev/*.jpg"))
    metadata = episode_dir / "metadata.json"
    target_reached = False
    if metadata.exists():
        try:
            target_reached = bool(json.loads(metadata.read_text(encoding="utf-8")).get("target_reached", False))
        except Exception:
            pass
    return {
        "episode_exists": episode_dir.exists(),
        "image_count": len(images),
        "target_reached_or_stopped": target_reached,
    }


def main():
    args = parse_args()
    root = Path(__file__).resolve().parent
    setups_path = (root / args.setups).resolve()
    output_root = (root / args.output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    layouts_dir = output_root / "_resolved_layouts"

    data = json.loads(setups_path.read_text(encoding="utf-8"))
    setups = data.get("setups", [])
    if not setups:
        raise RuntimeError(f"No setups found in {setups_path}")

    results = []
    for index, setup in enumerate(setups):
        name = setup["name"]
        print(f"[batch] {index + 1}/{len(setups)} running {name}", flush=True)
        layout_path = write_single_layout(setup, layouts_dir)
        episode_output = output_root / name
        if episode_output.exists():
            import shutil

            shutil.rmtree(episode_output)
        cmd = [
            args.isaac_python,
            str(root / "isaacsim_main.py"),
            "--headless",
            "--layout-json",
            str(layout_path),
            "--episode-index",
            "0",
            "--output-dir",
            str(episode_output),
            "--steps",
            str(args.steps),
            "--warmup-frames",
            str(args.warmup_frames),
            "--capture-frames",
            str(args.capture_frames),
            "--target-radius",
            str(setup.get("control", {}).get("target_radius", args.target_radius)),
            "--stop-on-target",
        ]
        if args.no_render:
            cmd.append("--no-render")
        completed = subprocess.run(cmd, cwd=root)
        stats = episode_stats(episode_output)
        try:
            output_value = str(episode_output.relative_to(root))
        except ValueError:
            output_value = str(episode_output)
        results.append({"name": name, "returncode": completed.returncode, "output": output_value, **stats})
        write_output_trees(output_root)
        if completed.returncode != 0 and args.fail_fast:
            print(f"[batch] fail-fast stopped after {name}", flush=True)
            break

    summary = output_root / "batch_summary.json"
    tree_stats = write_output_trees(output_root)
    summary.write_text(json.dumps(results, indent=2), encoding="utf-8")
    failed = [item for item in results if item["returncode"] != 0]
    if failed:
        print(f"[batch] failed setups: {[item['name'] for item in failed]}", flush=True)
        if any(item.get("episode_exists") or item.get("image_count", 0) > 0 for item in results):
            print(f"[batch] kept generated data. summary={summary} images={tree_stats['images']}", flush=True)
            return 0
        return 1
    print(f"[batch] completed {len(results)} setups. summary={summary} images={tree_stats['images']}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
