import argparse
import csv
import json
import math
from pathlib import Path

from layout_config import BLOCKS, BOARD_SIZE, LEVEL, ROUTE_ORDER, START_POSITION, TARGETS


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--output-dir", default="outputs/endoscope_single_latest")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--warmup-frames", type=int, default=30)
    parser.add_argument("--steps", type=int, default=180)
    return parser.parse_args()


def fail_if_not_isaac_python():
    try:
        import omni  # noqa: F401
        import pxr  # noqa: F401
    except Exception as exc:
        raise RuntimeError(
            "This script must be run with Isaac Sim python.sh, not normal Python."
        ) from exc


def rgba_to_rgb(color):
    return (float(color[0]), float(color[1]), float(color[2]))


def add_color(prim, color):
    from pxr import Gf, UsdGeom

    UsdGeom.Gprim(prim).CreateDisplayColorAttr([Gf.Vec3f(*rgba_to_rgb(color))])


def set_transform(prim, xyz, scale=None, rotate_z_deg=None):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    if rotate_z_deg is not None:
        xform.AddRotateZOp().Set(float(rotate_z_deg))
    if scale is not None:
        xform.AddScaleOp().Set(Gf.Vec3f(float(scale[0]), float(scale[1]), float(scale[2])))


def add_static_box(stage, path, position, size, height, color):
    from pxr import UsdGeom, UsdPhysics

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, (position[0], position[1], height / 2.0), (size[0], size[1], height))
    add_color(prim, color)
    UsdPhysics.CollisionAPI.Apply(prim)
    return prim


def add_static_cylinder(stage, path, position, radius, height, color):
    from pxr import UsdGeom, UsdPhysics

    cyl = UsdGeom.Cylinder.Define(stage, path)
    prim = cyl.GetPrim()
    cyl.CreateRadiusAttr(float(radius))
    cyl.CreateHeightAttr(float(height))
    cyl.CreateAxisAttr("Z")
    set_transform(prim, (position[0], position[1], height / 2.0))
    add_color(prim, color)
    UsdPhysics.CollisionAPI.Apply(prim)
    return prim


def add_insertable_block(stage, path, block):
    # Covered tunnel: top view sees a closed block. The pass-through channel runs
    # perpendicular to the board long side, matching the physical layout.
    x, y = block.position
    sx, sy = block.size
    wall = 0.024
    channel = 0.060
    color = (0.20, 0.36, 0.58, 1.0)
    add_static_box(stage, f"{path}/left_wall", (x - sx / 2 + wall / 2, y), (wall, sy), block.height, color)
    add_static_box(stage, f"{path}/right_wall", (x + sx / 2 - wall / 2, y), (wall, sy), block.height, color)
    add_static_box(stage, f"{path}/top_cover", (x, y), (sx, sy), 0.018, color)
    add_static_box(stage, f"{path}/front_lip", (x, y + sy / 2 - wall / 2), (sx, wall), block.height, color)
    add_static_box(stage, f"{path}/rear_lip", (x, y - sy / 2 + wall / 2), (sx, wall), block.height, color)
    return {"channel_width": channel, "covered": True}


def add_pentagon_target(stage, path, target, dot_side_angle=math.pi):
    from pxr import Gf, UsdGeom, UsdPhysics, Vt

    radius = target.size[0] / 2.0
    height = target.height
    verts = []
    for z in (0.0, height):
        for i in range(5):
            a = math.pi / 2.0 + i * 2.0 * math.pi / 5.0
            verts.append((target.position[0] + radius * math.cos(a), target.position[1] + radius * math.sin(a), z))
    faces = [
        (0, 1, 2, 3, 4),
        (9, 8, 7, 6, 5),
        (0, 5, 6, 1),
        (1, 6, 7, 2),
        (2, 7, 8, 3),
        (3, 8, 9, 4),
        (4, 9, 5, 0),
    ]
    mesh = UsdGeom.Mesh.Define(stage, path)
    prim = mesh.GetPrim()
    mesh.CreatePointsAttr(Vt.Vec3fArray([Gf.Vec3f(*p) for p in verts]))
    mesh.CreateFaceVertexCountsAttr([len(f) for f in faces])
    mesh.CreateFaceVertexIndicesAttr([idx for face in faces for idx in face])
    add_color(prim, (0.72, 0.10, 0.82, 1.0))
    UsdPhysics.CollisionAPI.Apply(prim)

    dot_pos = (
        target.position[0] + radius * 0.95 * math.cos(dot_side_angle),
        target.position[1] + radius * 0.95 * math.sin(dot_side_angle),
    )
    add_static_cylinder(stage, f"{path}_entry_port_marker", dot_pos, 0.018, height + 0.006, (0.02, 0.02, 0.02, 1.0))
    return prim


def add_endoscope_articulation_placeholder(stage):
    from pxr import Sdf, UsdGeom, UsdPhysics

    # Real PhysX bodies and joints are created here as an Isaac-side scaffold.
    # This file does not solve custom rod physics.
    segment_paths = []
    colors = [
        (0.03, 0.035, 0.035, 1.0),
        (0.58, 0.61, 0.64, 1.0),
        (0.03, 0.035, 0.035, 1.0),
        (0.72, 0.75, 0.78, 1.0),
    ]
    lengths = [0.46, 0.08, 0.12, 0.08]
    x = START_POSITION[0]
    for idx, length in enumerate(lengths):
        path = f"/World/endoscope/seg_{idx:02d}"
        cyl = UsdGeom.Capsule.Define(stage, path)
        prim = cyl.GetPrim()
        cyl.CreateRadiusAttr(0.018)
        cyl.CreateHeightAttr(float(length))
        cyl.CreateAxisAttr("X")
        set_transform(prim, (x + length / 2.0, START_POSITION[1], 0.065))
        add_color(prim, colors[idx])
        UsdPhysics.CollisionAPI.Apply(prim)
        UsdPhysics.RigidBodyAPI.Apply(prim)
        segment_paths.append(path)
        x += length
    for idx in range(len(segment_paths) - 1):
        joint = UsdPhysics.RevoluteJoint.Define(stage, f"/World/endoscope/joint_{idx:02d}")
        joint.CreateBody0Rel().SetTargets([Sdf.Path(segment_paths[idx])])
        joint.CreateBody1Rel().SetTargets([Sdf.Path(segment_paths[idx + 1])])
        joint.CreateAxisAttr("Z")
        joint.CreateLowerLimitAttr(-90.0 if idx == 1 else -8.0)
        joint.CreateUpperLimitAttr(90.0 if idx == 1 else 8.0)
    return segment_paths


def add_cameras(stage):
    from pxr import Gf, UsdGeom

    ebv = UsdGeom.Camera.Define(stage, "/World/Cameras/ebv")
    set_transform(ebv.GetPrim(), (0.0, 0.0, 1.8), rotate_z_deg=0.0)
    ebv.CreateFocalLengthAttr(18.0)
    ebv.CreateClippingRangeAttr(Gf.Vec2f(0.01, 10.0))

    ev = UsdGeom.Camera.Define(stage, "/World/Cameras/ev")
    set_transform(ev.GetPrim(), (START_POSITION[0] + 0.60, START_POSITION[1], 0.09))
    ev.CreateFocalLengthAttr(12.0)
    ev.CreateClippingRangeAttr(Gf.Vec2f(0.01, 5.0))


def make_output_files(episode_dir, scene_usd):
    for sub in ("frames/ebv", "frames/ev", "render_frames", "tip_frames", "debug_frames"):
        (episode_dir / sub).mkdir(parents=True, exist_ok=True)
    with (episode_dir / "trajectory.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["frame", "tip_x", "tip_y", "tip_z", "target", "phase"])
        writer.writeheader()
        writer.writerow({"frame": 0, "tip_x": START_POSITION[0], "tip_y": START_POSITION[1], "tip_z": 0.065, "target": "target_star", "phase": "scene_created"})
    with (episode_dir / "control_commands.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["frame", "command", "value"])
        writer.writeheader()
        writer.writerow({"frame": 0, "command": "isaac_scene_only", "value": 1})
    annotations = {
        "format": "vlca_sim_annotations_v1",
        "source": "isaac_sim",
        "frames": [
            {
                "frame": 0,
                "ebv": "frames/ebv/000000.png",
                "ev": "frames/ev/000000.png",
                "active_target": "target_star",
                "objects": [
                    {"name": block.name, "type": "block", "kind": block.kind, "shape": block.shape}
                    for block in BLOCKS
                ]
                + [
                    {
                        "name": target.name,
                        "type": "target" if target.active else "block",
                        "shape": target.shape,
                        "active": target.active,
                    }
                    for target in TARGETS
                ],
            }
        ],
    }
    metadata = {
        "simulator": "Isaac Sim",
        "level": LEVEL,
        "episode": episode_dir.name,
        "route_order": list(ROUTE_ORDER),
        "scene_usd": scene_usd.name,
        "output_format": "genesis_compatible_episode_v1",
        "note": "Scene uses USD/PhysX colliders. Dynamic endoscope behavior should be validated in Isaac Sim before dataset use.",
    }
    (episode_dir / "annotations.json").write_text(json.dumps(annotations, indent=2), encoding="utf-8")
    (episode_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")


def build_scene(args):
    fail_if_not_isaac_python()

    from isaacsim import SimulationApp

    app = SimulationApp({"headless": args.headless})
    try:
        import omni.usd
        from pxr import PhysxSchema, UsdGeom, UsdPhysics

        ctx = omni.usd.get_context()
        ctx.new_stage()
        stage = ctx.get_stage()
        UsdGeom.SetStageMetersPerUnit(stage, 1.0)
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)

        physics_scene = UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")
        physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scene.GetPrim())
        physx_scene.CreateEnableCCDAttr(True)

        add_static_box(stage, "/World/board", (0.0, 0.0), BOARD_SIZE, 0.035, (0.74, 0.76, 0.70, 1.0))
        add_static_box(stage, "/World/start_clamp_upper", (-0.76, 0.055), (0.12, 0.025), 0.055, (0.12, 0.12, 0.14, 1.0))
        add_static_box(stage, "/World/start_clamp_lower", (-0.76, -0.055), (0.12, 0.025), 0.055, (0.12, 0.12, 0.14, 1.0))

        for block in BLOCKS:
            path = f"/World/blocks/{block.name}"
            if block.kind == "insertable":
                add_insertable_block(stage, path, block)
            elif block.shape == "circle":
                add_static_cylinder(stage, path, block.position, block.radius, block.height, (0.88, 0.40, 0.50, 1.0))
            else:
                add_static_box(stage, path, block.position, block.size, block.height, (0.20, 0.36, 0.58, 1.0))

        for target in TARGETS:
            angle = math.pi if target.active else 0.0
            add_pentagon_target(stage, f"/World/targets/{target.name}", target, dot_side_angle=angle)

        add_endoscope_articulation_placeholder(stage)
        add_cameras(stage)

        episode_dir = Path(args.output_dir) / f"episode_{args.episode_index:06d}"
        episode_dir.mkdir(parents=True, exist_ok=True)
        scene_usd = episode_dir / "scene.usd"
        stage.GetRootLayer().Export(str(scene_usd))
        make_output_files(episode_dir, scene_usd)
        print(f"Isaac Sim scene saved to: {scene_usd}")
        print(f"Genesis-compatible output folder: {episode_dir}")
    finally:
        app.close()


def main():
    build_scene(parse_args())


if __name__ == "__main__":
    main()
