def render_recorded_frame_pairs(app, output_root, segment_prims, segment_specs, frame_states):
    import omni.replicator.core as rep
    from omni.replicator.core import AnnotatorRegistry
    from PIL import Image
    import omni.timeline
    import numpy as np

    if not frame_states:
        return {}

    # 预先创建 sleeves（与原代码一致）
    sleeves = ensure_visual_joint_sleeves(segment_prims[0].GetStage(), segment_specs) if segment_prims else []

    # 配置 replicator（只一次）
    configure_fast_replicator_capture()

    # 创建两个相机各自的 render_product 和 annotator（复用）
    render_product_ebv = rep.create.render_product("/World/Cameras/ebv", (1280, 840))
    render_product_ev = rep.create.render_product("/World/Cameras/ev", (1280, 840))

    annotator_ebv = AnnotatorRegistry.get_annotator("rgb")
    annotator_ebv.attach([render_product_ebv])

    annotator_ev = AnnotatorRegistry.get_annotator("rgb")
    annotator_ev.attach([render_product_ev])

    render_status = {}

    # 确保 timeline 播放（与原代码一致）
    timeline = omni.timeline.get_timeline_interface()
    was_playing = timeline.is_playing()
    if not was_playing:
        timeline.play()

    try:
        for idx, state in enumerate(frame_states, start=1):
            # 应用姿态（与原代码完全一致）
            matrices = state.get("segment_world_matrices")
            if matrices:
                apply_segment_world_matrices(segment_prims, matrices)
                update_visual_joint_sleeves(sleeves, matrices, segment_specs)
                for _ in range(4):
                    app.update()
            else:
                for _ in range(2):
                    app.update()

            frame_index = int(state.get("frame", idx))
            print(f"[isaac-vlca] render_pose {frame_index}", flush=True)

            # ---- 渲染 ebv ----
            ebv_ok = False
            try:
                rep.orchestrator.step()
                ebv_pixels = annotator_ebv.get_data()
                if (ebv_pixels is not None and ebv_pixels.ndim == 3 and
                    ebv_pixels.shape[0] > 0 and ebv_pixels.shape[1] > 0 and
                    not image_is_black(ebv_pixels)):
                    (output_root / "cam_ebv").mkdir(parents=True, exist_ok=True)
                    Image.fromarray(ebv_pixels[:, :, :3].astype(np.uint8)).save(
                        output_root / "cam_ebv" / f"{frame_index:04d}.jpg", quality=92
                    )
                    ebv_ok = True
            except Exception as e:
                print(f"[isaac-vlca] ebv render error: {e}", flush=True)

            if not ebv_ok:
                draw_fallback_camera_frame(output_root, frame_index, state, "cam_ebv")

            # ---- 渲染 ev ----
            ev_ok = False
            try:
                rep.orchestrator.step()
                ev_pixels = annotator_ev.get_data()
                if (ev_pixels is not None and ev_pixels.ndim == 3 and
                    ev_pixels.shape[0] > 0 and ev_pixels.shape[1] > 0 and
                    not image_is_black(ev_pixels)):
                    (output_root / "cam_ev").mkdir(parents=True, exist_ok=True)
                    Image.fromarray(ev_pixels[:, :, :3].astype(np.uint8)).save(
                        output_root / "cam_ev" / f"{frame_index:04d}.jpg", quality=92
                    )
                    ev_ok = True
            except Exception as e:
                print(f"[isaac-vlca] ev render error: {e}", flush=True)

            if not ev_ok:
                draw_fallback_camera_frame(output_root, frame_index, state, "cam_ev")

            render_status[frame_index] = {"cam_ebv": ebv_ok, "cam_ev": ev_ok}

            # 显存监控（可选）
            if idx % 10 == 0:
                try:
                    allocated = torch.cuda.memory_allocated() / 1024**3
                    reserved = torch.cuda.memory_reserved() / 1024**3
                    print(f"[vram] frame {idx}: allocated={allocated:.2f}GB, cached={reserved:.2f}GB", flush=True)
                except Exception:
                    pass

    finally:
        # 清理资源
        try:
            annotator_ebv.detach([render_product_ebv])
            annotator_ev.detach([render_product_ev])
        except Exception:
            pass
        try:
            rep.destroy.render_product(render_product_ebv)
            rep.destroy.render_product(render_product_ev)
        except Exception:
            pass
        if not was_playing:
            try:
                timeline.stop()
            except Exception:
                pass

    return render_status