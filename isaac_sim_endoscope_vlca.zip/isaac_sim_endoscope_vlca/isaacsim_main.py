import argparse
import csv
import json
import math
import re
import shutil
import traceback
from datetime import datetime, timezone
from pathlib import Path

from layout_config import (
    BLOCKS,
    BOARD_SIZE,
    BlockSpec,
    LEVEL,
    ROUTE_ORDER,
    ROUTE_WAYPOINT_OVERRIDES,
    START_POSITION,
    TARGETS,
)

DATASET_FRAME_NAME = "0001.jpg"
CODE_VERSION = "isaac_physx_lubricated_compliant_body"
VLCA_PROMPTS = (
    {"name": "block", "color": "#8b5cf6"},
    {"name": "robot tip", "color": "#f59e0b"},
    {"name": "target", "color": "#f59e0b", "subprompts": []},
)
YOLO_PROMPTS = (
    {"name": "block", "color": "#8b5cf6"},
)

BOARD_THICKNESS = 0.035
ENDOSCOPE_RADIUS = 0.018
ENDOSCOPE_Z = BOARD_THICKNESS + ENDOSCOPE_RADIUS + 0.007
MIN_OBSTACLE_HEIGHT = 0.120
CONTROL_PROFILE = {}
DRIVE_DISTANCE = 1.22
TARGET_REACHED_RADIUS = 0.055
FINAL_HOMING_DISTANCE = 0.18
RENDER_RESOLUTION = (640, 420)
RENDER_STREAMS = {}
LOW_FRICTION_STATIC = 0.035
LOW_FRICTION_DYNAMIC = 0.025


def tuple2(values, default=(0.0, 0.0)):
    if values is None:
        return tuple(default)
    return (float(values[0]), float(values[1]))


def block_from_dict(data):
    return BlockSpec(
        name=str(data["name"]),
        kind=str(data.get("kind", "distractor")),
        shape=str(data.get("shape", "rectangle")),
        position=tuple2(data.get("position")),
        size=tuple2(data.get("size", (0.10, 0.10))),
        height=float(data.get("height", 0.07)),
        radius=float(data.get("radius", 0.08)),
        active=bool(data.get("active", False)),
    )


def load_layout_json(path):
    global BLOCKS, BOARD_SIZE, CONTROL_PROFILE, DRIVE_DISTANCE, LEVEL
    global ROUTE_ORDER, ROUTE_WAYPOINT_OVERRIDES, START_POSITION, TARGETS
    global TARGET_REACHED_RADIUS

    data = json.loads(Path(path).read_text(encoding="utf-8"))
    LEVEL = str(data.get("level", LEVEL))
    BOARD_SIZE = tuple2(data.get("board_size", BOARD_SIZE))
    START_POSITION = tuple2(data.get("start_position", START_POSITION))
    BLOCKS = tuple(block_from_dict(item) for item in data.get("blocks", []))
    TARGETS = tuple(block_from_dict(item) for item in data.get("targets", []))
    ROUTE_ORDER = tuple(data.get("route_order", ()))
    ROUTE_WAYPOINT_OVERRIDES = {
        str(name): tuple2(value)
        for name, value in data.get("route_waypoint_overrides", {}).items()
    }
    CONTROL_PROFILE = dict(data.get("control", {}))
    DRIVE_DISTANCE = float(CONTROL_PROFILE.get("drive_distance", data.get("drive_distance", DRIVE_DISTANCE)))
    TARGET_REACHED_RADIUS = float(
        CONTROL_PROFILE.get("target_radius", data.get("target_radius", TARGET_REACHED_RADIUS))
    )


def block_by_name(name):
    for block in BLOCKS:
        if block.name == name:
            return block
    return None


def target_by_name(name):
    for target in TARGETS:
        if target.name == name:
            return target
    return None


def route_waypoint(name):
    if name in ROUTE_WAYPOINT_OVERRIDES:
        return tuple(ROUTE_WAYPOINT_OVERRIDES[name])
    block = block_by_name(name)
    if block is not None:
        return tuple(block.position)
    target = target_by_name(name)
    if target is not None:
        return target_entry_point(target)
    return tuple(START_POSITION)


def target_entry_point(target):
    radius = float(target.size[0]) / 2.0
    return (float(target.position[0]) - radius * 0.95, float(target.position[1]))


def active_target_waypoint():
    for target in TARGETS:
        if target.active:
            return route_waypoint(target.name)
    if ROUTE_ORDER:
        return route_waypoint(ROUTE_ORDER[-1])
    return tuple(START_POSITION)


def wrap_angle_radians(value):
    while value > math.pi:
        value -= 2.0 * math.pi
    while value < -math.pi:
        value += 2.0 * math.pi
    return value


def route_waypoints():
    return [
        {"name": name, "x": route_waypoint(name)[0], "y": route_waypoint(name)[1]}
        for name in ROUTE_ORDER
    ]


def insertion_exit_x():
    block = block_by_name("guide_left_insertable")
    if block is None:
        return START_POSITION[0] + 0.34
    return block.position[0] + block.size[0] / 2.0 + ENDOSCOPE_RADIUS * 2.0


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--output-dir", default="outputs/endoscope_single_latest")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--layout-json", default=None)
    parser.add_argument("--warmup-frames", type=int, default=30)
    parser.add_argument("--steps", type=int, default=240)
    parser.add_argument("--capture-frames", type=int, default=24)
    parser.add_argument("--stop-on-target", action="store_true")
    parser.add_argument("--target-radius", type=float, default=None)
    parser.add_argument("--no-render", action="store_true")
    return parser.parse_args()


def fail_if_not_isaac_python():
    try:
        import isaacsim  # noqa: F401
    except Exception as exc:
        raise RuntimeError(
            "This script must be run with Isaac Sim python.sh, not normal Python."
        ) from exc


def rgba_to_rgb(color):
    return (float(color[0]), float(color[1]), float(color[2]))


def add_color(prim, color):
    from pxr import Gf, UsdGeom

    UsdGeom.Gprim(prim).CreateDisplayColorAttr([Gf.Vec3f(*rgba_to_rgb(color))])


def apply_collision(prim, contact_offset=0.012, rest_offset=0.0):
    from pxr import UsdPhysics

    UsdPhysics.CollisionAPI.Apply(prim)
    try:
        from pxr import PhysxSchema

        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(prim)
        physx_collision.CreateContactOffsetAttr(float(contact_offset))
        physx_collision.CreateRestOffsetAttr(float(rest_offset))
    except Exception:
        pass


def bind_physics_material(prim, name, static_friction, dynamic_friction, restitution=0.0):
    try:
        from pxr import Sdf, UsdPhysics, UsdShade

        stage = prim.GetStage()
        material_path = Sdf.Path(f"/World/PhysicsMaterials/{name}")
        material = UsdShade.Material.Get(stage, material_path)
        if not material:
            material = UsdShade.Material.Define(stage, material_path)
            physics = UsdPhysics.MaterialAPI.Apply(material.GetPrim())
            physics.CreateStaticFrictionAttr(float(static_friction))
            physics.CreateDynamicFrictionAttr(float(dynamic_friction))
            physics.CreateRestitutionAttr(float(restitution))
        UsdShade.MaterialBindingAPI.Apply(prim).Bind(material)
    except Exception:
        pass


def set_api_attr(api, name, value):
    creator = getattr(api, f"Create{name}Attr", None)
    if creator is None:
        return False
    try:
        creator(value)
        return True
    except Exception:
        return False


def tune_physx_rigid_body(prim):
    try:
        from pxr import PhysxSchema

        api = PhysxSchema.PhysxRigidBodyAPI.Apply(prim)
        set_api_attr(api, "EnableCCD", True)
        set_api_attr(api, "DisableGravity", True)
        set_api_attr(api, "SleepThreshold", 0.0)
        set_api_attr(api, "StabilizationThreshold", 0.0)
        set_api_attr(api, "SolverPositionIterationCount", 64)
        set_api_attr(api, "SolverVelocityIterationCount", 16)
        set_api_attr(api, "MaxDepenetrationVelocity", 3.0)
        set_api_attr(api, "RetainAccelerations", True)
    except Exception:
        pass


def wake_rigid_body(prim):
    try:
        import omni.physx

        path = prim.GetPath().pathString if hasattr(prim, "GetPath") else str(prim)
        interface = omni.physx.get_physx_interface()
        for name in ("wake_up", "wakeUp", "wake_up_rigid_body", "wakeUpRigidBody"):
            func = getattr(interface, name, None)
            if func is None:
                continue
            try:
                func(path)
                return True
            except TypeError:
                try:
                    func(prim)
                    return True
                except Exception:
                    pass
            except Exception:
                pass
    except Exception:
        pass
    return False


def wake_endoscope_chain(segment_prims):
    woke_any = False
    for prim in segment_prims:
        woke_any = wake_rigid_body(prim) or woke_any
    return woke_any


def tune_joint_constraint(joint_prim):
    try:
        from pxr import UsdPhysics

        joint = UsdPhysics.Joint(joint_prim)
        joint.CreateCollisionEnabledAttr(False)
        joint.CreateBreakForceAttr(1.0e9)
        joint.CreateBreakTorqueAttr(1.0e9)
    except Exception:
        pass


def get_world_translation(prim):
    from pxr import Usd, UsdGeom

    matrix = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    t = matrix.ExtractTranslation()
    return (float(t[0]), float(t[1]), float(t[2]))


def get_world_point(prim, local_xyz):
    from pxr import Gf, Usd, UsdGeom

    matrix = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    point = matrix.Transform(Gf.Vec3d(float(local_xyz[0]), float(local_xyz[1]), float(local_xyz[2])))
    return (float(point[0]), float(point[1]), float(point[2]))


def true_front_tip_position(segment_prims, segment_specs):
    front_length = float(segment_specs[-1][1])
    return get_world_point(segment_prims[-1], (front_length / 2.0, 0.0, 0.0))


def true_front_tip_heading(segment_prims, segment_specs):
    front_length = float(segment_specs[-1][1])
    front = get_world_point(segment_prims[-1], (front_length / 2.0, 0.0, 0.0))
    rear = get_world_point(segment_prims[-1], (-front_length / 2.0, 0.0, 0.0))
    return math.atan2(front[1] - rear[1], front[0] - rear[0])


def max_segment_joint_gap(segment_prims, segment_specs):
    gaps = []
    for idx in range(len(segment_prims) - 1):
        left_length = float(segment_specs[idx][1])
        right_length = float(segment_specs[idx + 1][1])
        left_end = get_world_point(segment_prims[idx], (left_length / 2.0, 0.0, 0.0))
        right_start = get_world_point(segment_prims[idx + 1], (-right_length / 2.0, 0.0, 0.0))
        gaps.append(math.sqrt(sum((left_end[axis] - right_start[axis]) ** 2 for axis in range(3))))
    return max(gaps) if gaps else 0.0


def collect_segment_world_matrices(segment_prims):
    from pxr import Usd, UsdGeom

    time = Usd.TimeCode.Default()
    return [
        UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(time)
        for prim in segment_prims
    ]


def apply_segment_world_matrices(segment_prims, matrices):
    from pxr import UsdGeom

    for prim, matrix in zip(segment_prims, matrices):
        xform = UsdGeom.Xformable(prim)
        xform.ClearXformOpOrder()
        xform.AddTransformOp().Set(matrix)


def matrix_to_rows(matrix):
    return [[float(matrix[row][col]) for col in range(4)] for row in range(4)]


def bake_current_segment_poses(segment_prims):
    """Deprecated: do not call while PhysX is running.

    Rewriting xform ops on dynamic rigid bodies during simulation can make
    PhysX treat the body as teleported/reset, which can freeze the chain.
    Keep this helper only for old-package compatibility.
    """
    from pxr import Usd, UsdGeom

    time = Usd.TimeCode.Default()
    for prim in segment_prims:
        xform = UsdGeom.Xformable(prim)
        world_matrix = xform.ComputeLocalToWorldTransform(time)
        # Segment prims live under /World/endoscope, which is authored as an
        # identity Xform. Writing the world matrix as local transform prevents
        # Replicator/Fabric from snapping rendering back to the initial USD pose.
        xform.ClearXformOpOrder()
        xform.AddTransformOp().Set(world_matrix)


def set_transform(prim, xyz, scale=None, rotate_z_deg=None):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    if rotate_z_deg is not None:
        xform.AddRotateZOp().Set(float(rotate_z_deg))
    if scale is not None:
        xform.AddScaleOp().Set(Gf.Vec3f(float(scale[0]), float(scale[1]), float(scale[2])))


def set_camera_transform(prim, xyz, rotate_xyz_deg):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    xform.AddRotateXYZOp().Set(
        Gf.Vec3f(float(rotate_xyz_deg[0]), float(rotate_xyz_deg[1]), float(rotate_xyz_deg[2]))
    )


def add_lights(stage):
    from pxr import Gf, UsdLux

    dome = UsdLux.DomeLight.Define(stage, "/World/Lights/dome")
    dome.CreateIntensityAttr(180.0)
    dome.CreateColorAttr(Gf.Vec3f(1.0, 1.0, 1.0))

    key = UsdLux.DistantLight.Define(stage, "/World/Lights/key")
    key.CreateIntensityAttr(520.0)
    key.CreateAngleAttr(0.35)
    set_transform(key.GetPrim(), (0.0, 0.0, 1.0), rotate_z_deg=0.0)


def update_translate(prim, xyz):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    ops = xform.GetOrderedXformOps()
    translate = None
    for op in ops:
        if op.GetOpType() == UsdGeom.XformOp.TypeTranslate:
            translate = op
            break
    if translate is None:
        translate = xform.AddTranslateOp()
    translate.Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))


def update_pose_xy(prim, xyz, yaw_rad):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    xform.AddRotateZOp().Set(math.degrees(float(yaw_rad)))


def add_static_box(stage, path, position, size, height, color):
    from pxr import UsdGeom

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, (position[0], position[1], height / 2.0), (size[0], size[1], height))
    add_color(prim, color)
    apply_collision(prim, contact_offset=0.018)
    bind_physics_material(prim, "slick_static_surfaces", LOW_FRICTION_STATIC, LOW_FRICTION_DYNAMIC)
    return prim


def add_visual_box(stage, path, position, size, height, color):
    from pxr import UsdGeom

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, (position[0], position[1], height / 2.0), (size[0], size[1], height))
    add_color(prim, color)
    return prim


def add_static_sphere(stage, path, position, radius, color):
    from pxr import UsdGeom

    sphere = UsdGeom.Sphere.Define(stage, path)
    prim = sphere.GetPrim()
    sphere.CreateRadiusAttr(float(radius))
    set_transform(prim, position)
    add_color(prim, color)
    return prim


def add_static_cylinder(stage, path, position, radius, height, color):
    from pxr import UsdGeom

    cyl = UsdGeom.Cylinder.Define(stage, path)
    prim = cyl.GetPrim()
    cyl.CreateRadiusAttr(float(radius))
    cyl.CreateHeightAttr(float(height))
    cyl.CreateAxisAttr("Z")
    set_transform(prim, (position[0], position[1], height / 2.0))
    add_color(prim, color)
    apply_collision(prim, contact_offset=0.020)
    bind_physics_material(prim, "slick_static_surfaces", LOW_FRICTION_STATIC, LOW_FRICTION_DYNAMIC)
    return prim


def add_insertable_block(stage, path, block):
    # Covered tunnel. The endoscope enters from the left, so the pass-through
    # channel runs along X. The cover hides the slot in the top-view render.
    x, y = block.position
    sx, sy = block.size
    color = (0.05, 0.24, 0.52, 1.0)
    block_h = max(block.height, MIN_OBSTACLE_HEIGHT)
    channel = max(0.090, ENDOSCOPE_RADIUS * 2.8)
    channel_center_y = START_POSITION[1]
    y_min = y - sy / 2.0
    y_max = y + sy / 2.0
    channel_min = max(y_min, channel_center_y - channel / 2.0)
    channel_max = min(y_max, channel_center_y + channel / 2.0)
    cover_h = 0.026
    wall_z = max(block_h - cover_h, BOARD_THICKNESS)
    lower_h_y = max(channel_min - y_min, 0.0)
    upper_h_y = max(y_max - channel_max, 0.0)
    if upper_h_y > 0.005:
        add_static_box(stage, f"{path}/upper_wall", (x, channel_max + upper_h_y / 2.0), (sx, upper_h_y), wall_z, color)
    if lower_h_y > 0.005:
        add_static_box(stage, f"{path}/lower_wall", (x, y_min + lower_h_y / 2.0), (sx, lower_h_y), wall_z, color)
    cover = add_visual_box(stage, f"{path}/top_cover", (x, y), (sx, sy), cover_h, color)
    set_transform(cover, (x, y, wall_z + cover_h / 2.0), (sx, sy, cover_h))
    visual_lid = add_visual_box(stage, f"{path}/visual_lid", (x, y), (sx, sy), 0.006, (0.03, 0.18, 0.42, 1.0))
    set_transform(visual_lid, (x, y, block_h + 0.004), (sx, sy, 0.006))
    return {"channel_width": channel, "channel_axis": "x", "channel_center_y": channel_center_y, "covered": True}


def add_pentagon_target(stage, path, target, dot_side_angle=math.pi):
    from pxr import Gf, UsdGeom, UsdPhysics, Vt

    radius = target.size[0] / 2.0
    height = target.height
    verts = []
    for z in (0.0, height):
        for i in range(5):
            a = math.pi / 2.0 + i * 2.0 * math.pi / 5.0
            verts.append((target.position[0] + radius * math.cos(a), target.position[1] + radius * math.sin(a), z))
    faces = [
        (0, 1, 2, 3, 4),
        (9, 8, 7, 6, 5),
        (0, 5, 6, 1),
        (1, 6, 7, 2),
        (2, 7, 8, 3),
        (3, 8, 9, 4),
        (4, 9, 5, 0),
    ]
    mesh = UsdGeom.Mesh.Define(stage, path)
    prim = mesh.GetPrim()
    mesh.CreatePointsAttr(Vt.Vec3fArray([Gf.Vec3f(*p) for p in verts]))
    mesh.CreateFaceVertexCountsAttr([len(f) for f in faces])
    mesh.CreateFaceVertexIndicesAttr([idx for face in faces for idx in face])
    add_color(prim, (0.72, 0.10, 0.82, 1.0))
    apply_collision(prim)
    bind_physics_material(prim, "slick_static_surfaces", LOW_FRICTION_STATIC, LOW_FRICTION_DYNAMIC)

    dot_pos = (
        target.position[0] + radius * 0.95 * math.cos(dot_side_angle),
        target.position[1] + radius * 0.95 * math.sin(dot_side_angle),
    )
    add_static_cylinder(stage, f"{path}_entry_port_marker", dot_pos, 0.018, height + 0.006, (0.02, 0.02, 0.02, 1.0))
    return prim


def add_capsule_segment(stage, path, center, length, radius, color, kinematic=False, mass_value=0.02):
    from pxr import UsdGeom, UsdPhysics

    cyl = UsdGeom.Capsule.Define(stage, path)
    prim = cyl.GetPrim()
    cyl.CreateRadiusAttr(float(radius))
    cyl.CreateHeightAttr(float(length))
    cyl.CreateAxisAttr("X")
    set_transform(prim, center)
    add_color(prim, color)
    apply_collision(prim, contact_offset=0.006)
    bind_physics_material(prim, "lubricated_endoscope", LOW_FRICTION_STATIC, LOW_FRICTION_DYNAMIC)
    rigid = UsdPhysics.RigidBodyAPI.Apply(prim)
    if kinematic:
        rigid.CreateKinematicEnabledAttr(True)
    tune_physx_rigid_body(prim)
    mass = UsdPhysics.MassAPI.Apply(prim)
    mass.CreateMassAttr(float(mass_value))
    return prim


def add_kinematic_anchor(stage, path, position):
    from pxr import Gf, Sdf, UsdGeom, UsdPhysics

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, position, (0.01, 0.01, 0.01))
    UsdPhysics.CollisionAPI.Apply(prim)
    rigid = UsdPhysics.RigidBodyAPI.Apply(prim)
    rigid.CreateKinematicEnabledAttr(True)
    UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(1.0)
    prim.CreateAttribute("visibility", Sdf.ValueTypeNames.Token).Set("invisible")
    return prim


def add_revolute_joint(stage, path, body0, body1, local_x0, local_x1, lower, upper, drive_target=0.0, stiffness=0.0, max_force=80.0, damping=None):
    from pxr import Gf, Sdf, UsdPhysics

    joint = UsdPhysics.RevoluteJoint.Define(stage, path)
    prim = joint.GetPrim()
    joint.CreateBody0Rel().SetTargets([Sdf.Path(body0)])
    joint.CreateBody1Rel().SetTargets([Sdf.Path(body1)])
    joint.CreateAxisAttr("Z")
    joint.CreateLocalPos0Attr(Gf.Vec3f(float(local_x0), 0.0, 0.0))
    joint.CreateLocalPos1Attr(Gf.Vec3f(float(local_x1), 0.0, 0.0))
    joint.CreateLowerLimitAttr(float(lower))
    joint.CreateUpperLimitAttr(float(upper))
    if stiffness > 0.0:
        drive = UsdPhysics.DriveAPI.Apply(prim, "angular")
        drive.CreateTypeAttr("force")
        drive.CreateTargetPositionAttr(float(drive_target))
        drive.CreateTargetVelocityAttr(0.0)
        drive.CreateStiffnessAttr(float(stiffness))
        drive.CreateDampingAttr(float(damping if damping is not None else max(40.0, float(stiffness) * 0.020)))
        drive.CreateMaxForceAttr(float(max_force))
    tune_joint_constraint(prim)
    return prim


def set_joint_drive_target(joint_prim, target_degrees):
    from pxr import UsdPhysics

    drive = UsdPhysics.DriveAPI.Apply(joint_prim, "angular")
    attr = drive.GetTargetPositionAttr()
    if not attr:
        attr = drive.CreateTargetPositionAttr(float(target_degrees))
    attr.Set(float(target_degrees))


def add_fixed_joint(stage, path, body0, body1, local_x0, local_x1):
    from pxr import Gf, Sdf, UsdPhysics

    joint = UsdPhysics.FixedJoint.Define(stage, path)
    joint.CreateBody0Rel().SetTargets([Sdf.Path(body0)])
    joint.CreateBody1Rel().SetTargets([Sdf.Path(body1)])
    joint.CreateLocalPos0Attr(Gf.Vec3f(float(local_x0), 0.0, 0.0))
    joint.CreateLocalPos1Attr(Gf.Vec3f(float(local_x1), 0.0, 0.0))
    prim = joint.GetPrim()
    tune_joint_constraint(prim)
    return prim


def add_prismatic_drive_joint(stage, path, body0, body1, local_x0, local_x1, lower, upper, stiffness=8500.0, damping=1100.0, max_force=5200.0):
    from pxr import Gf, Sdf, UsdPhysics

    joint = UsdPhysics.PrismaticJoint.Define(stage, path)
    prim = joint.GetPrim()
    joint.CreateBody0Rel().SetTargets([Sdf.Path(body0)])
    joint.CreateBody1Rel().SetTargets([Sdf.Path(body1)])
    joint.CreateAxisAttr("X")
    joint.CreateLocalPos0Attr(Gf.Vec3f(float(local_x0), 0.0, 0.0))
    joint.CreateLocalPos1Attr(Gf.Vec3f(float(local_x1), 0.0, 0.0))
    joint.CreateLowerLimitAttr(float(lower))
    joint.CreateUpperLimitAttr(float(upper))
    drive = UsdPhysics.DriveAPI.Apply(prim, "linear")
    drive.CreateTypeAttr("force")
    drive.CreateTargetPositionAttr(0.0)
    drive.CreateTargetVelocityAttr(0.0)
    drive.CreateStiffnessAttr(float(stiffness))
    drive.CreateDampingAttr(float(damping))
    drive.CreateMaxForceAttr(float(max_force))
    tune_joint_constraint(prim)
    return prim


def set_linear_drive_target(joint_prim, target_meters):
    from pxr import UsdPhysics

    drive = UsdPhysics.DriveAPI.Apply(joint_prim, "linear")
    attr = drive.GetTargetPositionAttr()
    if not attr:
        attr = drive.CreateTargetPositionAttr(float(target_meters))
    attr.Set(float(target_meters))


def disable_chain_self_collision(stage, segment_paths):
    from pxr import Sdf, UsdPhysics

    paths = [Sdf.Path(path) for path in segment_paths]
    for i, path_a in enumerate(paths):
        prim_a = stage.GetPrimAtPath(path_a)
        if not prim_a:
            continue
        filtered = UsdPhysics.FilteredPairsAPI.Apply(prim_a)
        rel = filtered.CreateFilteredPairsRel()
        for path_b in paths[i + 1 :]:
            rel.AddTarget(path_b)


def add_endoscope_articulation(stage):
    from pxr import Sdf, UsdGeom, UsdPhysics

    root = UsdGeom.Xform.Define(stage, "/World/endoscope").GetPrim()
    # Use plain PhysX rigid bodies and joints, not an ArticulationRoot. This
    # chain is anchored to the world by a prismatic insertion joint, which is
    # more reliable as maximal-coordinate PhysX joints than as an articulation
    # rooted on a non-rigid parent Xform.
    segment_paths = []
    segment_prims = []
    segment_specs = [
        ("tail_pusher", 0.58, (0.025, 0.027, 0.025, 1.0), 0.20),
        ("passive_hard_tube", 0.30, (0.025, 0.027, 0.025, 1.0), 0.16),
        ("rear_metal", 0.070, (0.66, 0.69, 0.72, 1.0), 0.06),
        ("active_bend", 0.075, (0.025, 0.027, 0.025, 1.0), 0.035),
        ("front_metal", 0.080, (0.76, 0.79, 0.82, 1.0), 0.055),
    ]
    # Place the visible tip at the entrance initially, then push from the tail.
    # This must match drive_endoscope_base(); otherwise frame 1 teleports the
    # tube and PhysX has to recover from an impossible configuration.
    total_len = sum(spec[1] for spec in segment_specs)
    x = START_POSITION[0] - total_len
    z = ENDOSCOPE_Z
    for idx, (name, length, color, mass_value) in enumerate(segment_specs):
        path = f"/World/endoscope/seg_{idx:02d}"
        prim = add_capsule_segment(
            stage,
            path,
            (x + length / 2.0, START_POSITION[1], z),
            length,
            ENDOSCOPE_RADIUS,
            color,
            kinematic=False,
            mass_value=mass_value,
        )
        prim.CreateAttribute("vlca:segmentName", Sdf.ValueTypeNames.String).Set(name)
        segment_paths.append(path)
        segment_prims.append(prim)
        x += length

    disable_chain_self_collision(stage, segment_paths)

    fixed_joints = []
    passive_joints = []
    for idx, limit, stiffness, max_force in (
        (0, 5.0, 1800.0, 220.0),
        (1, 10.0, 2600.0, 320.0),
    ):
        l0 = segment_specs[idx][1]
        l1 = segment_specs[idx + 1][1]
        passive_joints.append(
            add_revolute_joint(
                stage,
                f"/World/endoscope/passive_joint_{idx:02d}",
                segment_paths[idx],
                segment_paths[idx + 1],
                l0 / 2.0,
                -l1 / 2.0,
                -limit,
                limit,
                drive_target=0.0,
                stiffness=stiffness,
                max_force=max_force,
                damping=95.0,
            )
        )
    idx = 3
    l0 = segment_specs[idx][1]
    l1 = segment_specs[idx + 1][1]
    fixed_joints.append(
        add_fixed_joint(
            stage,
            f"/World/endoscope/fixed_joint_{idx:02d}",
            segment_paths[idx],
            segment_paths[idx + 1],
            l0 / 2.0,
            -l1 / 2.0,
        )
    )

    active_joints = []
    idx = 2
    l0 = segment_specs[idx][1]
    l1 = segment_specs[idx + 1][1]
    active_joints.append(add_revolute_joint(
        stage,
        f"/World/endoscope/joint_{idx:02d}",
        segment_paths[idx],
        segment_paths[idx + 1],
        l0 / 2.0,
        -l1 / 2.0,
        -85.0,
        85.0,
        drive_target=0.0,
        stiffness=30000.0,
        max_force=3400.0,
        damping=650.0,
    ))

    anchor_position = (START_POSITION[0] - total_len + segment_specs[0][1] / 2.0, START_POSITION[1], z)
    anchor_prim = add_kinematic_anchor(stage, "/World/endoscope/insertion_anchor", anchor_position)
    insertion_joint = add_prismatic_drive_joint(
        stage,
        "/World/endoscope/insertion_drive",
        anchor_prim.GetPath().pathString,
        segment_paths[0],
        0.0,
        0.0,
        0.0,
        1.22,
    )

    joints = {"fixed": fixed_joints, "passive": passive_joints, "active": active_joints, "insertion": insertion_joint}
    return segment_prims, segment_paths, segment_specs, joints


def planned_route_target(tip_x, tip_y):
    if not ROUTE_ORDER:
        return None, active_target_waypoint()
    waypoint_radius = float(CONTROL_PROFILE.get("waypoint_radius", 0.085))
    pass_margin_x = float(CONTROL_PROFILE.get("waypoint_pass_margin_x", 0.035))
    for name in ROUTE_ORDER[:-1]:
        wx, wy = route_waypoint(name)
        distance = math.hypot(float(tip_x) - wx, float(tip_y) - wy)
        passed_x = float(tip_x) > wx + pass_margin_x
        if distance > waypoint_radius and not passed_x:
            return name, (wx, wy)
    target_name = ROUTE_ORDER[-1]
    return target_name, route_waypoint(target_name)


def steering_bend_to_waypoint(base_bend, tip_x, tip_y, tip_heading, waypoint, gain=42.0):
    if tip_x is None or tip_y is None or tip_heading is None or waypoint is None:
        return base_bend
    desired = math.atan2(float(waypoint[1]) - float(tip_y), float(waypoint[0]) - float(tip_x))
    heading_error = wrap_angle_radians(desired - float(tip_heading))
    return base_bend + gain * heading_error


def final_target_homing_bend(base_bend, tip_x=None, tip_y=None, tip_heading=None):
    target_xy = active_target_waypoint()
    if tip_x is None or tip_y is None or tip_heading is None:
        return base_bend
    if tip_x < float(CONTROL_PROFILE.get("steering_start_x", START_POSITION[0] + 0.10)):
        return base_bend
    distance = math.hypot(float(tip_x) - target_xy[0], float(tip_y) - target_xy[1])
    if distance > float(CONTROL_PROFILE.get("final_homing_distance", FINAL_HOMING_DISTANCE)):
        return base_bend
    desired = math.atan2(target_xy[1] - float(tip_y), target_xy[0] - float(tip_x))
    heading_error = wrap_angle_radians(desired - float(tip_heading))
    scale = 1.0 - distance / max(float(CONTROL_PROFILE.get("final_homing_distance", FINAL_HOMING_DISTANCE)), 1e-6)
    homing_gain = float(CONTROL_PROFILE.get("final_homing_gain", 58.0))
    bend = base_bend + homing_gain * scale * heading_error
    return max(-75.0, min(75.0, bend))


def active_bend_target_degrees(progress, tip_x=None, tip_y=None, tip_heading=None):
    if CONTROL_PROFILE.get("bend_keyframes"):
        base_bend = profile_bend_target_degrees(progress, tip_x, tip_y)
        if tip_x is not None and tip_y is not None and tip_heading is not None:
            if tip_x >= float(CONTROL_PROFILE.get("steering_start_x", START_POSITION[0] + 0.10)):
                _, waypoint = planned_route_target(tip_x, tip_y)
                base_bend = steering_bend_to_waypoint(
                    base_bend,
                    tip_x,
                    tip_y,
                    tip_heading,
                    waypoint,
                    gain=float(CONTROL_PROFILE.get("route_heading_gain", 18.0)),
                )
        return final_target_homing_bend(base_bend, tip_x, tip_y, tip_heading)

    # The bend command must follow the actual tip position, not a fixed time
    # percentage. Otherwise the tube exits the insertable block straight and
    # gets pushed upward by the pink circle before steering starts.
    if tip_x is None:
        if progress < 0.38:
            return 0.0
        if progress < 0.58:
            return -45.0 * ((progress - 0.38) / 0.20)
        if progress < 0.82:
            return -48.0
        return -38.0

    gate_x = insertion_exit_x()
    if tip_x < gate_x:
        return 0.0

    circle = block_by_name("guide_pink_circle")
    circle_x = circle.position[0] if circle is not None else gate_x + 0.18
    circle_lower_y = (
        ROUTE_WAYPOINT_OVERRIDES.get("guide_pink_circle", (circle_x, -0.10))[1]
        if circle is not None
        else -0.10
    )
    ramp_start = gate_x + 0.012
    ramp_end = circle_x - 0.035
    if ramp_end <= ramp_start:
        ramp_end = ramp_start + 0.12

    if tip_x < ramp_start:
        bend = 0.0
    elif tip_x < ramp_end:
        edge_error = 0.0 if tip_y is None else tip_y - circle_lower_y
        bend = -34.0 * ((tip_x - ramp_start) / (ramp_end - ramp_start)) - 90.0 * edge_error
    elif tip_x < circle_x + 0.18:
        edge_error = 0.0 if tip_y is None else tip_y - circle_lower_y
        bend = -36.0 - 90.0 * edge_error
    else:
        bend = -24.0

    if tip_y is not None and tip_y > 0.045 and tip_x > gate_x:
        bend = min(bend, -58.0)
    bend = max(-65.0, min(8.0, bend))
    return final_target_homing_bend(bend, tip_x, tip_y, tip_heading)


def profile_bend_target_degrees(progress, tip_x=None, tip_y=None):
    keyframes = list(CONTROL_PROFILE.get("bend_keyframes", []))
    if not keyframes:
        return 0.0

    axis = str(CONTROL_PROFILE.get("bend_axis", "progress"))
    if axis == "tip_x" and tip_x is not None:
        value = float(tip_x)
        key = "x"
    elif axis == "tip_y" and tip_y is not None:
        value = float(tip_y)
        key = "y"
    else:
        value = float(progress)
        key = "progress"

    points = sorted((float(item.get(key, item.get("progress", 0.0))), float(item["bend"])) for item in keyframes)
    if value <= points[0][0]:
        return points[0][1]
    if value >= points[-1][0]:
        return points[-1][1]
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if x0 <= value <= x1:
            t = (value - x0) / max(x1 - x0, 1e-6)
            return y0 + (y1 - y0) * t
    return points[-1][1]


def drive_endoscope_base(
    app,
    segment_prims,
    segment_specs,
    joint_prims,
    steps,
    warmup_frames,
    capture_callback=None,
    capture_frames=1,
    stop_on_target=False,
    target_radius=None,
):
    import omni.timeline

    gate_exit_x = insertion_exit_x()
    print(
        f"[isaac-vlca] code_version={CODE_VERSION} insertion_exit_x={gate_exit_x:.3f}",
        flush=True,
    )

    def sample_state(frame_index, progress, insertion_target, bend_target):
        tail = get_world_translation(segment_prims[0])
        tip_center = get_world_translation(segment_prims[-1])
        tip = true_front_tip_position(segment_prims, segment_specs)
        heading = true_front_tip_heading(segment_prims, segment_specs)
        waypoint_name, waypoint = planned_route_target(tip[0], tip[1])
        return {
            "frame": int(frame_index),
            "progress": float(progress),
            "tail_x": tail[0],
            "tail_y": tail[1],
            "tail_z": tail[2],
            "tip_x": tip[0],
            "tip_y": tip[1],
            "tip_z": tip[2],
            "tip_center_x": tip_center[0],
            "tip_center_y": tip_center[1],
            "tip_center_z": tip_center[2],
            "insertion_exit_x": gate_exit_x,
            "insertion_target": float(insertion_target),
            "bend_target_deg": float(bend_target),
            "tip_heading_rad": float(heading),
            "route_target": waypoint_name or "",
            "waypoint_x": float(waypoint[0]) if waypoint else "",
            "waypoint_y": float(waypoint[1]) if waypoint else "",
            "max_joint_gap": max_segment_joint_gap(segment_prims, segment_specs),
            "target_reached": False,
            "_segment_world_matrices": collect_segment_world_matrices(segment_prims),
        }

    def format_state(label, state):
        return (
            f"[isaac-vlca] {label} "
            f"{state['frame']}: tail=({state['tail_x']:.3f},{state['tail_y']:.3f},{state['tail_z']:.3f}) "
            f"tip=({state['tip_x']:.3f},{state['tip_y']:.3f},{state['tip_z']:.3f}) "
            f"tip_center=({state['tip_center_x']:.3f},{state['tip_center_y']:.3f},{state['tip_center_z']:.3f}) "
            f"insert={state['insertion_target']:.3f} bend={state['bend_target_deg']:.1f} "
            f"heading={math.degrees(state['tip_heading_rad']):.1f} route={state['route_target']} gate_x={gate_exit_x:.3f}"
        )

    timeline = omni.timeline.get_timeline_interface()
    timeline.play()
    for _ in range(max(0, warmup_frames)):
        app.update()

    steps = max(1, steps)
    wanted = max(1, int(capture_frames))
    if wanted == 1:
        capture_steps = {steps - 1: 1}
    else:
        capture_steps = {
            int(round(i * (steps - 1) / (wanted - 1))): i + 1
            for i in range(wanted)
        }
    render_status = {}
    frame_states = []
    tail_drive_distance = DRIVE_DISTANCE
    target_name = ROUTE_ORDER[-1] if ROUTE_ORDER else None
    target_xy = route_waypoint(target_name) if target_name is not None else None
    reach_radius = float(target_radius if target_radius is not None else TARGET_REACHED_RADIUS)
    active_joints = joint_prims.get("active", []) if isinstance(joint_prims, dict) else []
    insertion_joint = joint_prims.get("insertion") if isinstance(joint_prims, dict) else None
    active_joint = active_joints[0] if len(active_joints) > 0 else None
    for frame in range(steps):
        progress = frame / max(steps - 1, 1)
        insertion_target = progress * tail_drive_distance
        if insertion_joint is not None:
            set_linear_drive_target(insertion_joint, insertion_target)
        tip_pos = true_front_tip_position(segment_prims, segment_specs)
        tip_heading = true_front_tip_heading(segment_prims, segment_specs)
        bend = active_bend_target_degrees(progress, tip_pos[0], tip_pos[1], tip_heading)
        if active_joint is not None:
            set_joint_drive_target(active_joint, bend)
        if frame < 120 or frame % 5 == 0:
            wake_endoscope_chain(segment_prims)
        for _ in range(4):
            app.update()
        reached_target = False
        if stop_on_target and target_xy is not None:
            tip_now = true_front_tip_position(segment_prims, segment_specs)
            reached_target = math.hypot(tip_now[0] - target_xy[0], tip_now[1] - target_xy[1]) <= reach_radius
        if frame in capture_steps:
            capture_index = capture_steps[frame]
            state = sample_state(capture_index, progress, insertion_target, bend)
            frame_states.append(state)
            print(format_state("capture_pre", state), flush=True)
            if capture_callback is not None:
                render_status[capture_index] = capture_callback(capture_index)
                post_state = sample_state(capture_index, progress, insertion_target, bend)
                print(format_state("capture_post", post_state), flush=True)
            if len(frame_states) >= 2:
                prev = frame_states[-2]
                tip_step = math.hypot(state["tip_x"] - prev["tip_x"], state["tip_y"] - prev["tip_y"])
                tail_step = math.hypot(state["tail_x"] - prev["tail_x"], state["tail_y"] - prev["tail_y"])
                print(
                    f"[isaac-vlca] capture_delta {capture_index}: "
                    f"tip_step={tip_step:.4f} tail_step={tail_step:.4f}",
                    flush=True,
                )
            if capture_callback is not None:
                try:
                    timeline.play()
                except Exception:
                    pass
                wake_endoscope_chain(segment_prims)
        elif capture_callback is None and frame % max(1, steps // 6) == 0:
            state = sample_state(frame, progress, insertion_target, bend)
            print(
                "[isaac-vlca] sim "
                f"{frame}: tail=({state['tail_x']:.3f},{state['tail_y']:.3f},{state['tail_z']:.3f}) "
                f"tip=({state['tip_x']:.3f},{state['tip_y']:.3f},{state['tip_z']:.3f}) "
                f"tip_center=({state['tip_center_x']:.3f},{state['tip_center_y']:.3f},{state['tip_center_z']:.3f}) "
                f"insert={insertion_target:.3f} bend={bend:.1f} gate_x={gate_exit_x:.3f}",
                flush=True,
            )
        if reached_target:
            state = sample_state(frame, progress, insertion_target, bend)
            state["target_reached"] = True
            frame_states.append(state)
            print(format_state("target_reached", state), flush=True)
            break
    timeline.stop()
    if capture_callback is None and not frame_states:
        tip_pos = true_front_tip_position(segment_prims, segment_specs)
        tip_heading = true_front_tip_heading(segment_prims, segment_specs)
        frame_states.append(sample_state(0, 1.0, tail_drive_distance, active_bend_target_degrees(1.0, tip_pos[0], tip_pos[1], tip_heading)))
    return render_status, frame_states


def clamp01(value):
    return max(0.0, min(1.0, float(value)))


def now_iso_z():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def norm_point_from_world(position):
    board_w, board_h = BOARD_SIZE
    x = (float(position[0]) + board_w / 2.0) / board_w
    y = (board_h / 2.0 - float(position[1])) / board_h
    return round(clamp01(x), 6), round(clamp01(y), 6)


def norm_bbox_from_world(position, size):
    cx, cy = norm_point_from_world(position)
    w = float(size[0]) / BOARD_SIZE[0]
    h = float(size[1]) / BOARD_SIZE[1]
    x = clamp01(cx - w / 2.0)
    y = clamp01(cy - h / 2.0)
    w = min(w, 1.0 - x)
    h = min(h, 1.0 - y)
    return {
        "x": round(x, 6),
        "y": round(y, 6),
        "w": round(w, 6),
        "h": round(h, 6),
    }


def make_box_label(spec, block_id=None):
    bbox = norm_bbox_from_world(spec.position, spec.size)
    label = {
        **bbox,
        "promptIndex": 0,
        "prompt": "block",
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "block",
        "sourceName": spec.name,
        "kind": spec.kind,
        "shape": spec.shape,
    }
    if block_id is not None:
        label["blockId"] = block_id
    return label


def make_tip_label(position=None):
    x, y = norm_point_from_world(position or START_POSITION)
    return {
        "x": x,
        "y": y,
        "w": 0,
        "h": 0,
        "isPoint": True,
        "promptIndex": 1,
        "prompt": "robot tip",
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "robot tip",
    }


def make_target_label(target):
    bbox = norm_bbox_from_world(target.position, target.size)
    return {
        **bbox,
        "promptIndex": 2,
        "prompt": "target",
        "subprompt": None,
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "target",
        "sourceName": target.name,
        "shape": target.shape,
    }


def compact_box(label):
    return {key: label[key] for key in ("x", "y", "w", "h")}


def block_id_map():
    ids = {}
    used = set()
    next_id = 1
    for block in BLOCKS:
        match = re.search(r"(?:^|_)B(\d+)(?:_|$)", block.name)
        if match:
            block_id = f"B{int(match.group(1))}"
        else:
            while f"B{next_id}" in used:
                next_id += 1
            block_id = f"B{next_id}"
        ids[block.name] = block_id
        used.add(block_id)
    return ids


def planning_id_for_name(name, ids_by_name):
    if target_by_name(name) is not None:
        return "Target"
    if block_by_name(name) is not None:
        return ids_by_name.get(name, name)
    return None


def next_real_planning_id(route_target, ids_by_name):
    plan_id = planning_id_for_name(route_target, ids_by_name)
    if plan_id is not None:
        return plan_id
    if route_target not in ROUTE_ORDER:
        return None
    start_index = ROUTE_ORDER.index(route_target) + 1
    for name in ROUTE_ORDER[start_index:]:
        plan_id = planning_id_for_name(name, ids_by_name)
        if plan_id is not None:
            return plan_id
    return None


def frame_planning_list(state, global_plan, ids_by_name):
    route_target = state.get("route_target") if state else ""
    if not route_target or route_target == "Target":
        return list(global_plan)
    route_target = next_real_planning_id(route_target, ids_by_name)
    if route_target in global_plan:
        return list(global_plan[global_plan.index(route_target):])
    return list(global_plan)


def write_video_from_frames(frame_dir, output_file, fps=20):
    frames = sorted(frame_dir.glob("*.jpg"))
    if not frames:
        return False
    try:
        import cv2

        first = cv2.imread(str(frames[0]))
        if first is None:
            return False
        h, w = first.shape[:2]
        writer = cv2.VideoWriter(str(output_file), cv2.VideoWriter_fourcc(*"MJPG"), float(fps), (w, h))
        try:
            for frame in frames:
                image = cv2.imread(str(frame))
                if image is not None:
                    writer.write(image)
        finally:
            writer.release()
        return output_file.exists() and output_file.stat().st_size > 0
    except Exception:
        return False


def make_real_dataset_format(output_root, frame_states=None):
    # Match the lab dataset layout:
    # cam_ebv/*.jpg, cam_ev/*.jpg, json/vlca.json, json/yolo_auto_gen.json, data.csv.
    (output_root / "cam_ebv").mkdir(parents=True, exist_ok=True)
    (output_root / "cam_ev").mkdir(parents=True, exist_ok=True)
    json_dir = output_root / "json"
    json_dir.mkdir(parents=True, exist_ok=True)

    ids_by_name = block_id_map()
    block_labels = [make_box_label(block, ids_by_name[block.name]) for block in BLOCKS]
    inactive_target_as_blocks = [
        make_box_label(target, f"T{idx + 1}")
        for idx, target in enumerate(TARGETS)
        if not target.active
    ]
    active_targets = [target for target in TARGETS if target.active]
    target_labels = [make_target_label(target) for target in active_targets]

    frame_names = [path.name for path in sorted((output_root / "cam_ebv").glob("*.jpg"))] or [DATASET_FRAME_NAME]
    frame_states = list(frame_states or [])
    state_by_name = {
        frame_name: frame_states[min(idx, len(frame_states) - 1)]
        for idx, frame_name in enumerate(frame_names)
        if frame_states
    }
    vlca_labels = {
        frame_name: block_labels
        + inactive_target_as_blocks
        + [make_tip_label((state_by_name[frame_name]["tip_x"], state_by_name[frame_name]["tip_y"])) if frame_name in state_by_name else make_tip_label()]
        + target_labels
        for frame_name in frame_names
    }
    yolo_frame_labels = [
        compact_box(label) | {
            "promptIndex": 0,
            "prompt": "block",
            "confidence": 1.0,
            "auto_labeled": True,
            "displayName": "block",
            "sourceName": label["sourceName"],
        }
        for label in block_labels + inactive_target_as_blocks
    ]
    yolo_labels = {
        frame_name: yolo_frame_labels
        for frame_name in frame_names
    }
    tip_points = {}
    for frame_name in frame_names:
        if frame_name in state_by_name:
            tip_x, tip_y = norm_point_from_world((state_by_name[frame_name]["tip_x"], state_by_name[frame_name]["tip_y"]))
            tip_points[frame_name] = {"x": tip_x, "y": tip_y, "confidence": 1.0}
    reference_blocks = [
        {**compact_box(label), "blockId": label.get("blockId", f"B{idx + 1}")}
        for idx, label in enumerate(block_labels)
    ]
    global_planning_list = [
        plan_id
        for plan_id in (planning_id_for_name(name, ids_by_name) for name in ROUTE_ORDER)
        if plan_id is not None
    ] or ["Target"]
    frame_planning_lists = {
        frame_name: frame_planning_list(state_by_name.get(frame_name), global_planning_list, ids_by_name)
        for frame_name in frame_names
    }
    vlca = {
        "version": "2.0",
        "format": "normalised",
        "exportDate": now_iso_z(),
        "coordSystem": "normalised_0_1_topleft",
        "prompts": list(VLCA_PROMPTS),
        "labels": vlca_labels,
        "tipPoints": tip_points,
        "negatives": [],
        "referenceBlocks": reference_blocks,
        "globalPlanningList": global_planning_list,
        "framePlanningLists": frame_planning_lists,
        "guidingConfig": {
            "distanceMetric": "edge",
            "switchThreshold": 0.03125,
            "description": "Robot tip to block EDGE distance (normalised). Switches when within threshold of block boundary.",
        },
        "stats": {
            "totalImages": len(frame_names),
            "labeledImages": len(frame_names),
            "negativeImages": 0,
            "totalBoxes": sum(len(labels) for labels in vlca_labels.values()),
            "tipPointFrames": len(tip_points),
        },
    }
    yolo = {
        "version": "2.0",
        "format": "normalised",
        "exportDate": now_iso_z(),
        "coordSystem": "normalised_0_1_topleft",
        "prompts": list(YOLO_PROMPTS),
        "labels": yolo_labels,
    }
    (json_dir / "vlca.json").write_text(json.dumps(vlca, indent=2), encoding="utf-8")
    (json_dir / "yolo_auto_gen.json").write_text(json.dumps(yolo, indent=2), encoding="utf-8")

    waypoint = route_waypoint(ROUTE_ORDER[0]) if ROUTE_ORDER else START_POSITION
    csv_columns = [
        "frame_id",
        "t_mono",
        "joy_ud",
        "joy_lr",
        "m1_spd",
        "m2_spd",
        "m3_spd",
        "m4_spd",
        "m1_pos",
        "m2_pos",
        "m3_pos",
        "m4_pos",
        "pwm_duty",
        "em_valid",
        "em_x",
        "em_y",
        "em_z",
        "em_qw",
        "em_qx",
        "em_qy",
        "em_qz",
        "ebv_block_boxes_json",
        "ebv_tip_box_json",
        "ev_block_boxes_json",
        "guiding_block_id",
        "waypoint_x",
        "waypoint_y",
    ]
    base_row = {
        "joy_ud": 0,
        "joy_lr": 0,
        "m1_spd": 0,
        "m2_spd": 0,
        "m3_spd": 0,
        "m4_spd": 0,
        "m1_pos": 0,
        "m2_pos": 0,
        "m3_pos": 0,
        "m4_pos": 0,
        "pwm_duty": 0,
        "em_valid": 0,
        "em_x": "nan",
        "em_y": "nan",
        "em_z": "nan",
        "em_qw": "nan",
        "em_qx": "nan",
        "em_qy": "nan",
        "em_qz": "nan",
        "ebv_block_boxes_json": "[]",
        "ebv_tip_box_json": "null",
        "ev_block_boxes_json": "[]",
        "guiding_block_id": "",
        "waypoint_x": "",
        "waypoint_y": "",
    }
    with (output_root / "data.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=csv_columns)
        writer.writeheader()
        prev_insert = 0.0
        prev_bend = 0.0
        for idx, _frame_name in enumerate(frame_names, start=1):
            state = state_by_name.get(_frame_name, {})
            insert_mm = float(state.get("insertion_target", 0.0)) * 1000.0
            bend_deg = float(state.get("bend_target_deg", 0.0))
            heading = float(state.get("tip_heading_rad", 0.0))
            em_qw = math.cos(heading / 2.0)
            em_qz = math.sin(heading / 2.0)
            m_insert_spd = int(round(insert_mm - prev_insert))
            m_bend_spd = int(round(bend_deg - prev_bend))
            prev_insert = insert_mm
            prev_bend = bend_deg
            writer.writerow({
                "frame_id": idx,
                "t_mono": round((idx - 1) * 0.05, 4),
                **base_row,
                "joy_ud": round(bend_deg / 75.0, 6),
                "joy_lr": round(insert_mm / max(DRIVE_DISTANCE * 1000.0, 1.0), 6),
                "m1_spd": m_insert_spd,
                "m2_spd": -m_insert_spd,
                "m3_spd": m_bend_spd,
                "m4_spd": -m_bend_spd,
                "m1_pos": int(round(insert_mm)),
                "m2_pos": -int(round(insert_mm)),
                "m3_pos": int(round(bend_deg)),
                "m4_pos": -int(round(bend_deg)),
                "pwm_duty": min(100, abs(m_insert_spd) + abs(m_bend_spd)),
                "em_valid": 1 if state else 0,
                "em_x": state.get("tip_x", ""),
                "em_y": state.get("tip_y", ""),
                "em_z": state.get("tip_z", ""),
                "em_qw": round(em_qw, 8) if state else "nan",
                "em_qx": 0,
                "em_qy": 0,
                "em_qz": round(em_qz, 8) if state else "nan",
                "ebv_tip_box_json": "null",
            })
    write_video_from_frames(output_root / "cam_ebv", output_root / "video_ebv.avi")
    write_video_from_frames(output_root / "cam_ev", output_root / "video_ev.avi")


def convert_first_rgb_to_jpg(source_dir, target_file):
    candidates = sorted(source_dir.rglob("*.png")) + sorted(source_dir.rglob("*.jpg")) + sorted(source_dir.rglob("*.jpeg"))
    if not candidates:
        return False
    target_file.parent.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image

        Image.open(candidates[0]).convert("RGB").save(target_file, quality=92)
    except Exception:
        shutil.copyfile(candidates[0], target_file)
    return True


def image_is_black(pixels):
    import numpy as np

    rgb = pixels[:, :, :3].astype(np.float32)
    return float(np.mean(rgb)) < 2.0 or float(np.std(rgb)) < 0.25


def configure_fast_replicator_capture():
    try:
        import carb

        settings = carb.settings.get_settings()
        settings.set("/exts/omni.replicator.core/maxAssetLoadingTime", 1.0)
        settings.set("/omni/replicator/RTSubframes", 1)
    except Exception:
        pass


def get_or_create_render_stream(camera_path):
    stream = RENDER_STREAMS.get(camera_path)
    if stream is not None:
        return stream
    import omni.replicator.core as rep

    configure_fast_replicator_capture()
    render_product = rep.create.render_product(camera_path, RENDER_RESOLUTION)
    annotator = rep.AnnotatorRegistry.get_annotator("rgb")
    annotator.attach([render_product])
    stream = {"render_product": render_product, "annotator": annotator}
    RENDER_STREAMS[camera_path] = stream
    return stream


def close_all_render_streams():
    if not RENDER_STREAMS:
        return
    try:
        import omni.replicator.core as rep
    except Exception:
        rep = None
    for stream in list(RENDER_STREAMS.values()):
        annotator = stream.get("annotator")
        render_product = stream.get("render_product")
        if annotator is not None and render_product is not None:
            try:
                annotator.detach([render_product])
            except Exception:
                pass
        if rep is not None and render_product is not None:
            try:
                rep.destroy.render_product(render_product)
            except Exception:
                pass
    RENDER_STREAMS.clear()


def render_camera_frame(camera_path, output_dir, final_jpg, retries=3):
    timeline = None
    was_playing = None
    try:
        import omni.timeline
        import omni.replicator.core as rep
        import numpy as np
        from PIL import Image

        timeline = omni.timeline.get_timeline_interface()
        try:
            was_playing = bool(timeline.is_playing())
        except Exception:
            was_playing = None
        output_dir.mkdir(parents=True, exist_ok=True)
        stream = get_or_create_render_stream(camera_path)
        annotator = stream["annotator"]
        pixels = None
        last_shape = None
        for _ in range(max(1, retries)):
            rep.orchestrator.step()
            candidate = np.asarray(annotator.get_data())
            last_shape = candidate.shape
            if candidate.ndim == 3 and candidate.shape[0] > 0 and candidate.shape[1] > 0 and not image_is_black(candidate):
                pixels = candidate
                break
        if pixels is None:
            raise RuntimeError(f"RGB annotator returned no non-black image; last_shape={last_shape}")
        Image.fromarray(pixels[:, :, :3].astype(np.uint8), mode="RGB").save(final_jpg, quality=92)
        return final_jpg.exists() and final_jpg.stat().st_size > 0
    except Exception as exc:
        (output_dir / "render_error.txt").write_text(f"{type(exc).__name__}: {exc}\n", encoding="utf-8")
        return False
    finally:
        if timeline is not None and was_playing:
            try:
                timeline.play()
            except Exception:
                pass


def render_dataset_frame_pair(output_root, frame_index):
    frame_name = f"{frame_index:04d}.jpg"
    ebv_ok = render_camera_frame("/World/Cameras/ebv", output_root / "cam_ebv", output_root / "cam_ebv" / frame_name)
    ev_ok = render_camera_frame("/World/Cameras/ev", output_root / "cam_ev", output_root / "cam_ev" / frame_name)
    return {"cam_ebv": ebv_ok, "cam_ev": ev_ok}


def draw_fallback_camera_frame(final_jpg, state, camera_name="cam_ebv"):
    try:
        from PIL import Image, ImageDraw
    except Exception:
        return False

    width, height = RENDER_RESOLUTION
    image = Image.new("RGB", (width, height), (188, 194, 180))
    draw = ImageDraw.Draw(image)

    def xy(world_x, world_y):
        nx, ny = norm_point_from_world((world_x, world_y))
        return int(nx * width), int(ny * height)

    for block in BLOCKS:
        color = (220, 48, 88) if block.shape == "circle" else (12, 62, 132)
        if block.shape == "circle":
            cx, cy = xy(block.position[0], block.position[1])
            r = max(3, int(block.radius / BOARD_SIZE[0] * width))
            draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=color)
        else:
            x0, y0 = xy(block.position[0] - block.size[0] / 2.0, block.position[1] + block.size[1] / 2.0)
            x1, y1 = xy(block.position[0] + block.size[0] / 2.0, block.position[1] - block.size[1] / 2.0)
            draw.rectangle((x0, y0, x1, y1), fill=color)

    for target in TARGETS:
        cx, cy = xy(target.position[0], target.position[1])
        r = max(4, int(target.size[0] / BOARD_SIZE[0] * width / 2.0))
        draw.polygon(
            [
                (
                    cx + int(r * math.cos(math.pi / 2.0 + i * 2.0 * math.pi / 5.0)),
                    cy - int(r * math.sin(math.pi / 2.0 + i * 2.0 * math.pi / 5.0)),
                )
                for i in range(5)
            ],
            fill=(165, 34, 190),
        )
        ex, ey = xy(*target_entry_point(target))
        draw.ellipse((ex - 4, ey - 4, ex + 4, ey + 4), fill=(5, 5, 5))

    tail = xy(state.get("tail_x", START_POSITION[0]), state.get("tail_y", START_POSITION[1]))
    tip = xy(state.get("tip_x", START_POSITION[0]), state.get("tip_y", START_POSITION[1]))
    draw.line((tail, tip), fill=(18, 22, 18), width=8)
    draw.ellipse((tip[0] - 6, tip[1] - 6, tip[0] + 6, tip[1] + 6), fill=(245, 158, 11))
    final_jpg.parent.mkdir(parents=True, exist_ok=True)
    image.save(final_jpg, quality=88)
    return final_jpg.exists() and final_jpg.stat().st_size > 0


def ensure_camera_frame_files(output_root, frame_states, render_status):
    render_status = dict(render_status or {})
    for idx, state in enumerate(frame_states, start=1):
        frame_name = f"{idx:04d}.jpg"
        for cam in ("cam_ebv", "cam_ev"):
            final_jpg = output_root / cam / frame_name
            ok = final_jpg.exists() and final_jpg.stat().st_size > 0
            if not ok:
                ok = draw_fallback_camera_frame(final_jpg, state, cam)
                render_status.setdefault(idx, {})[cam] = "fallback" if ok else False
            else:
                render_status.setdefault(idx, {})[cam] = render_status.get(idx, {}).get(cam, True)
    return render_status


def render_recorded_frame_pairs(app, output_root, endoscope_prims, frame_states):
    render_status = {}
    try:
        for idx, state in enumerate(frame_states, start=1):
            matrices = state.get("_segment_world_matrices")
            if matrices:
                apply_segment_world_matrices(endoscope_prims, matrices)
                app.update()
            render_status[idx] = render_dataset_frame_pair(output_root, idx)
        return ensure_camera_frame_files(output_root, frame_states, render_status)
    finally:
        close_all_render_streams()


def add_cameras(stage):
    from pxr import Gf, UsdGeom

    ebv = UsdGeom.Camera.Define(stage, "/World/Cameras/ebv")
    set_camera_transform(ebv.GetPrim(), (0.0, 0.0, 1.8), (0.0, 0.0, 0.0))
    ebv.CreateFocalLengthAttr(18.0)
    ebv.CreateClippingRangeAttr(Gf.Vec2f(0.01, 10.0))

    ev = UsdGeom.Camera.Define(stage, "/World/Cameras/ev")
    set_camera_transform(ev.GetPrim(), (START_POSITION[0] + 0.30, START_POSITION[1], ENDOSCOPE_Z + 0.018), (0.0, -90.0, 0.0))
    ev.CreateFocalLengthAttr(10.0)
    ev.CreateClippingRangeAttr(Gf.Vec2f(0.01, 5.0))


def make_output_files(output_root, episode_dir, scene_usd, render_status=None, frame_states=None):
    for sub in ("frames/ebv", "frames/ev", "render_frames", "tip_frames", "debug_frames"):
        (episode_dir / sub).mkdir(parents=True, exist_ok=True)
    ebv_frames = sorted((output_root / "cam_ebv").glob("*.jpg"))
    ev_frames = sorted((output_root / "cam_ev").glob("*.jpg"))
    frame_states = list(frame_states or [])
    if frame_states and len(frame_states) < len(ebv_frames):
        frame_states.extend([frame_states[-1]] * (len(ebv_frames) - len(frame_states)))
    for idx, source in enumerate(ebv_frames):
        shutil.copyfile(source, episode_dir / f"frames/ebv/{idx:06d}.jpg")
        shutil.copyfile(source, episode_dir / f"render_frames/{idx:06d}.jpg")
    for idx, source in enumerate(ev_frames):
        shutil.copyfile(source, episode_dir / f"frames/ev/{idx:06d}.jpg")
        shutil.copyfile(source, episode_dir / f"tip_frames/{idx:06d}.jpg")
    if not ebv_frames or not ev_frames:
        raise RuntimeError("No camera frames were rendered into cam_ebv/cam_ev")
    with (episode_dir / "trajectory.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "frame",
                "tip_x",
                "tip_y",
                "tip_z",
                "tip_center_x",
                "tip_center_y",
                "tip_center_z",
                "tail_x",
                "tail_y",
                "tail_z",
                "insertion_target",
                "bend_target_deg",
                "target",
                "phase",
            ],
        )
        writer.writeheader()
        if frame_states:
            for idx, state in enumerate(frame_states[: len(ebv_frames)]):
                writer.writerow({
                    "frame": idx,
                    "tip_x": state["tip_x"],
                    "tip_y": state["tip_y"],
                    "tip_z": state["tip_z"],
                    "tip_center_x": state.get("tip_center_x", ""),
                    "tip_center_y": state.get("tip_center_y", ""),
                    "tip_center_z": state.get("tip_center_z", ""),
                    "tail_x": state["tail_x"],
                    "tail_y": state["tail_y"],
                    "tail_z": state["tail_z"],
                    "insertion_target": state["insertion_target"],
                    "bend_target_deg": state["bend_target_deg"],
                    "target": "target_star",
                    "phase": "physx_capture",
                })
        else:
            writer.writerow({
                "frame": 0,
                "tip_x": START_POSITION[0],
                "tip_y": START_POSITION[1],
                "tip_z": ENDOSCOPE_Z,
                "tip_center_x": "",
                "tip_center_y": "",
                "tip_center_z": "",
                "tail_x": "",
                "tail_y": "",
                "tail_z": "",
                "insertion_target": "",
                "bend_target_deg": "",
                "target": "target_star",
                "phase": "no_pose_capture",
            })
    with (episode_dir / "control_commands.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["frame", "command", "value", "route_target", "waypoint_x", "waypoint_y"])
        writer.writeheader()
        for idx, state in enumerate(frame_states[: len(ebv_frames)]):
            writer.writerow({
                "frame": idx,
                "command": "insertion_target_m",
                "value": state.get("insertion_target", ""),
                "route_target": state.get("route_target", ""),
                "waypoint_x": state.get("waypoint_x", ""),
                "waypoint_y": state.get("waypoint_y", ""),
            })
            writer.writerow({
                "frame": idx,
                "command": "bend_target_deg",
                "value": state.get("bend_target_deg", ""),
                "route_target": state.get("route_target", ""),
                "waypoint_x": state.get("waypoint_x", ""),
                "waypoint_y": state.get("waypoint_y", ""),
            })
    annotations = {
        "format": "vlca_sim_annotations_v1",
        "source": "isaac_sim",
        "frames": [
            {
                "frame": frame_idx,
                "ebv": f"frames/ebv/{frame_idx:06d}.jpg",
                "ev": f"frames/ev/{frame_idx:06d}.jpg",
                "active_target": "target_star",
                "tip_world": {
                    "x": frame_states[frame_idx]["tip_x"],
                    "y": frame_states[frame_idx]["tip_y"],
                    "z": frame_states[frame_idx]["tip_z"],
                } if frame_idx < len(frame_states) else None,
                "tip": make_tip_label(
                    (frame_states[frame_idx]["tip_x"], frame_states[frame_idx]["tip_y"])
                ) if frame_idx < len(frame_states) else make_tip_label(),
                "objects": [
                    {"name": block.name, "type": "block", "kind": block.kind, "shape": block.shape}
                    for block in BLOCKS
                ]
                + [
                    {
                        "name": target.name,
                        "type": "target" if target.active else "block",
                        "shape": target.shape,
                        "active": target.active,
                    }
                    for target in TARGETS
                ],
            }
            for frame_idx in range(min(len(ebv_frames), len(ev_frames)))
        ],
    }
    metadata = {
        "simulator": "Isaac Sim",
        "code_version": CODE_VERSION,
        "level": LEVEL,
        "episode": episode_dir.name,
        "route_order": list(ROUTE_ORDER),
        "route_waypoints": route_waypoints(),
        "scene_usd": scene_usd.name,
        "output_format": "genesis_compatible_episode_v1",
        "real_dataset_format_root": str(output_root),
        "render_status": render_status or {},
        "pose_capture_count": len(frame_states),
        "target_reached": any(bool(state.get("target_reached")) for state in frame_states),
        "max_joint_gap": max([float(state.get("max_joint_gap", 0.0)) for state in frame_states] or [0.0]),
        "continuous_endoscope": max([float(state.get("max_joint_gap", 0.0)) for state in frame_states] or [0.0]) < 0.018,
        "note": "Scene uses Isaac Sim PhysX rigid bodies, low-friction materials, passive compliant rear joints, an actively steerable front revolute joint, a prismatic insertion drive, and static colliders.",
    }
    (episode_dir / "annotations.json").write_text(json.dumps(annotations, indent=2), encoding="utf-8")
    (episode_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    make_real_dataset_format(output_root, frame_states=frame_states)


def pose_debug_state(state):
    clean = {key: value for key, value in state.items() if key != "_segment_world_matrices"}
    if "_segment_world_matrices" in state:
        clean["segment_world_matrices"] = [matrix_to_rows(matrix) for matrix in state["_segment_world_matrices"]]
    return clean


def prepare_output_root(output_dir):
    output_root = Path(output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    probe = output_root / "run_started.txt"
    probe.write_text("Isaac Sim run started.\n", encoding="utf-8")
    return output_root


def build_scene(args):
    if args.layout_json:
        load_layout_json(args.layout_json)
    fail_if_not_isaac_python()
    output_root = prepare_output_root(args.output_dir)
    print(f"[isaac-vlca] output root: {output_root}", flush=True)
    progress_file = output_root / "run_progress.txt"

    def checkpoint(message):
        print(f"[isaac-vlca] {message}", flush=True)
        with progress_file.open("a", encoding="utf-8") as stream:
            stream.write(f"{message}\n")

    from isaacsim import SimulationApp

    checkpoint("starting SimulationApp")
    app = None
    try:
        app = SimulationApp({"headless": args.headless})
        checkpoint("SimulationApp ready")
        import omni.usd
        from pxr import PhysxSchema, UsdGeom, UsdPhysics

        checkpoint("creating USD stage")
        ctx = omni.usd.get_context()
        ctx.new_stage()
        app.update()
        stage = ctx.get_stage()
        if stage is None:
            raise RuntimeError("Isaac Sim returned no USD stage after new_stage()")
        UsdGeom.SetStageMetersPerUnit(stage, 1.0)
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)

        checkpoint("creating PhysX scene")
        physics_scene = UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")
        physics_scene.CreateGravityMagnitudeAttr(0.0)
        physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scene.GetPrim())
        physx_scene.CreateEnableCCDAttr(True)
        set_api_attr(physx_scene, "EnableStabilization", True)
        set_api_attr(physx_scene, "SolverType", "TGS")
        set_api_attr(physx_scene, "TimeStepsPerSecond", 120)
        set_api_attr(physx_scene, "MinPositionIterationCount", 16)
        set_api_attr(physx_scene, "MaxPositionIterationCount", 64)
        set_api_attr(physx_scene, "MinVelocityIterationCount", 4)
        set_api_attr(physx_scene, "MaxVelocityIterationCount", 16)
        add_lights(stage)

        checkpoint("creating board, clamps, blocks and targets")
        add_static_box(stage, "/World/board", (0.0, 0.0), BOARD_SIZE, BOARD_THICKNESS, (0.74, 0.76, 0.70, 1.0))
        add_static_box(stage, "/World/start_clamp_upper", (-0.76, 0.055), (0.12, 0.025), 0.055, (0.12, 0.12, 0.14, 1.0))
        add_static_box(stage, "/World/start_clamp_lower", (-0.76, -0.055), (0.12, 0.025), 0.055, (0.12, 0.12, 0.14, 1.0))

        for block in BLOCKS:
            path = f"/World/blocks/{block.name}"
            height = max(block.height, MIN_OBSTACLE_HEIGHT)
            if block.kind == "insertable":
                add_insertable_block(stage, path, block)
            elif block.shape == "circle":
                add_static_cylinder(stage, path, block.position, block.radius, height, (0.90, 0.18, 0.34, 1.0))
            else:
                add_static_box(stage, path, block.position, block.size, height, (0.05, 0.24, 0.52, 1.0))

        for target in TARGETS:
            angle = math.pi if target.active else 0.0
            add_pentagon_target(stage, f"/World/targets/{target.name}", target, dot_side_angle=angle)

        checkpoint("creating PhysX endoscope rigid-joint chain")
        endoscope_prims, _, endoscope_specs, joint_prims = add_endoscope_articulation(stage)
        checkpoint("creating cameras")
        add_cameras(stage)
        checkpoint("starting headless PhysX stepping")
        render_status = {}
        frame_states = []
        render_status, frame_states = drive_endoscope_base(
            app,
            endoscope_prims,
            endoscope_specs,
            joint_prims,
            args.steps,
            args.warmup_frames,
            capture_frames=args.capture_frames,
            stop_on_target=args.stop_on_target,
            target_radius=args.target_radius,
        )
        if not args.no_render:
            checkpoint("rendering recorded poses")
            render_status = render_recorded_frame_pairs(app, output_root, endoscope_prims, frame_states)

        checkpoint("exporting USD and dataset outputs")
        episode_dir = output_root / f"episode_{args.episode_index:06d}"
        episode_dir.mkdir(parents=True, exist_ok=True)
        scene_usd = episode_dir / "scene.usd"
        ok = stage.GetRootLayer().Export(str(scene_usd))
        if not ok:
            raise RuntimeError(f"USD export failed: {scene_usd}")
        (episode_dir / "pose_debug.json").write_text(
            json.dumps([pose_debug_state(state) for state in frame_states], indent=2),
            encoding="utf-8",
        )
        if not args.no_render:
            make_output_files(output_root, episode_dir, scene_usd, render_status=render_status, frame_states=frame_states)
        (output_root / "run_finished.txt").write_text(f"Saved {scene_usd}\n", encoding="utf-8")
        print(f"[isaac-vlca] scene saved to: {scene_usd}", flush=True)
        print(f"[isaac-vlca] Genesis-compatible output folder: {episode_dir}", flush=True)
        checkpoint("run completed")
    except BaseException:
        (output_root / "fatal_error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        checkpoint("run failed; see fatal_error.txt")
        raise
    finally:
        if app is not None:
            app.close()


def main():
    build_scene(parse_args())


if __name__ == "__main__":
    main()
