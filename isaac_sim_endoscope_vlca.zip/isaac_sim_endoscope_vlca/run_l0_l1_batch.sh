#!/usr/bin/env bash
set -euo pipefail
cd /workspace/isaac_sim_endoscope_vlca
EXTRA_ARGS=()
if [[ "${NO_RENDER:-0}" == "1" ]]; then
  EXTRA_ARGS+=("--no-render")
fi
if [[ "${FAIL_FAST:-0}" == "1" ]]; then
  EXTRA_ARGS+=("--fail-fast")
fi
/isaac-sim/python.sh batch_run_layouts.py --setups "${SETUPS:-layouts/l0_l1_training_batch.json}" --output-dir "${OUTPUT_DIR:-outputs/batch_l0_l1_training}" --steps "${STEPS:-360}" --capture-frames "${CAPTURE_FRAMES:-48}" --warmup-frames "${WARMUP_FRAMES:-20}" --target-radius "${TARGET_RADIUS:-0.08}" "${EXTRA_ARGS[@]}"
python3 scripts/check_output_format.py --root "${OUTPUT_DIR:-outputs/batch_l0_l1_training}" --min-episodes "${MIN_EPISODES:-4}"
chmod -R a+rwX outputs
