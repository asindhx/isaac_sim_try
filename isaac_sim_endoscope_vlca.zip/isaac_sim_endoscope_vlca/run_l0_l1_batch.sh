#!/usr/bin/env bash
set -euo pipefail
cd /workspace/isaac_sim_endoscope_vlca
/isaac-sim/python.sh batch_run_layouts.py --setups "${SETUPS:-layouts/l0_l1_training_batch.json}" --output-dir "${OUTPUT_DIR:-outputs/batch_l0_l1_training}" --steps "${STEPS:-360}" --capture-frames "${CAPTURE_FRAMES:-48}" --warmup-frames "${WARMUP_FRAMES:-20}" --target-radius "${TARGET_RADIUS:-0.08}"
python3 scripts/check_output_format.py --root "${OUTPUT_DIR:-outputs/batch_l0_l1_training}" --min-episodes "${MIN_EPISODES:-4}"
chmod -R a+rwX outputs
