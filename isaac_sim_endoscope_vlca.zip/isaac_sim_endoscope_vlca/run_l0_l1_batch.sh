#!/usr/bin/env bash
set -u

cd /workspace/isaac_sim_endoscope_vlca || exit 1

rm -rf outputs/batch_l0_l1_training
mkdir -p outputs/batch_l0_l1_training

echo "[run_l0_l1_batch] running all L0/L1 setups from layouts/l0_l1_training_batch.json"
log_file="outputs/batch_l0_l1_training/batch_console.log"

/isaac-sim/python.sh batch_run_layouts.py \
  --setups layouts/l0_l1_training_batch.json \
  --output-dir outputs/batch_l0_l1_training \
  --steps "${STEPS:-420}" \
  --capture-frames "${CAPTURE_FRAMES:-120}" \
  > >(tee "$log_file") 2>&1
status=${PIPESTATUS[0]}

if [ "$status" -ne 0 ]; then
  {
    echo "batch runner failed before completing normally"
    echo "status=${status}"
    echo "see batch_console.log"
  } > outputs/batch_l0_l1_training/ROOT_FATAL.txt
fi

find outputs/batch_l0_l1_training -type f | sort > outputs/batch_l0_l1_training/output_tree.txt || true
find outputs/batch_l0_l1_training -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) | sort > outputs/batch_l0_l1_training/image_tree.txt || true
image_count="$(wc -l < outputs/batch_l0_l1_training/image_tree.txt 2>/dev/null || echo 0)"

chmod -R a+rwX outputs || true

echo "[run_l0_l1_batch] finished with status ${status}"
echo "[run_l0_l1_batch] image files: ${image_count}"
echo "[run_l0_l1_batch] summary: outputs/batch_l0_l1_training/batch_summary.json"
echo "[run_l0_l1_batch] image list: outputs/batch_l0_l1_training/image_tree.txt"
exit "$status"
