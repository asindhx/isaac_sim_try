param(
    [string[]]$Inputs = @(
        "E:\xizi\data_0421_labeled\data_0421_L0\20260421-183638_data_collection.zip",
        "E:\xizi\data_0512_L3.5\20260512-144412_data_collection.zip"
    ),
    [string]$DatasetDir = "outputs\policy_dataset",
    [string]$ModelDir = "outputs\policy_baseline"
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$prepareArgs = @("scripts\prepare_policy_dataset.py", "--inputs") + $Inputs + @("--output-dir", $DatasetDir)
python @prepareArgs
python scripts\train_policy_baseline.py --dataset (Join-Path $DatasetDir "policy_dataset.npz") --output-dir $ModelDir

Write-Host "POLICY_BASELINE_WINDOWS_DONE"
Write-Host "Dataset: $DatasetDir"
Write-Host "Model:   $ModelDir"
