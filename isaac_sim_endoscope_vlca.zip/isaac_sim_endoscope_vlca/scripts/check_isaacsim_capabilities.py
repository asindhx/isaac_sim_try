import json
import sys
from pathlib import Path


def check(name, fn):
    try:
        value = fn()
        print(f"[PASS] {name}: {value}")
        return True, value
    except Exception as exc:
        print(f"[FAIL] {name}: {type(exc).__name__}: {exc}")
        return False, str(exc)


def main():
    results = {}

    ok, value = check("python_version", lambda: sys.version.split()[0])
    results["python_version"] = {"ok": ok, "value": value}

    def import_isaac():
        import isaacsim  # noqa: F401
        return "isaacsim import ok"

    ok, value = check("import_isaacsim", import_isaac)
    results["import_isaacsim"] = {"ok": ok, "value": value}

    def start_app():
        from isaacsim import SimulationApp

        app = SimulationApp({"headless": True})
        return app

    app = None
    try:
        ok, app_or_error = check("start_headless_simulation_app", start_app)
        results["start_headless_simulation_app"] = {"ok": ok, "value": str(app_or_error)}
        if not ok:
            raise RuntimeError("SimulationApp failed")
        app = app_or_error

        def import_usd_physx():
            import omni.usd  # noqa: F401
            from pxr import Gf, PhysxSchema, Usd, UsdGeom, UsdPhysics  # noqa: F401

            return "omni.usd + pxr USD/PhysX modules import ok"

        ok, value = check("import_usd_physx_modules", import_usd_physx)
        results["import_usd_physx_modules"] = {"ok": ok, "value": value}

        def create_stage_and_physics():
            import omni.usd
            from pxr import PhysxSchema, UsdGeom, UsdPhysics

            ctx = omni.usd.get_context()
            ctx.new_stage()
            stage = ctx.get_stage()
            UsdGeom.SetStageMetersPerUnit(stage, 1.0)
            scene = UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")
            PhysxSchema.PhysxSceneAPI.Apply(scene.GetPrim())
            return "stage + physics scene ok"

        ok, value = check("create_stage_and_physics_scene", create_stage_and_physics)
        results["create_stage_and_physics_scene"] = {"ok": ok, "value": value}

        def create_static_collider():
            import omni.usd
            from pxr import Gf, UsdGeom, UsdPhysics

            stage = omni.usd.get_context().get_stage()
            cube = UsdGeom.Cube.Define(stage, "/World/test_static_block")
            cube.CreateSizeAttr(1.0)
            xform = UsdGeom.Xformable(cube.GetPrim())
            xform.AddTranslateOp().Set(Gf.Vec3d(0, 0, 0.05))
            xform.AddScaleOp().Set(Gf.Vec3f(0.1, 0.1, 0.1))
            UsdPhysics.CollisionAPI.Apply(cube.GetPrim())
            return "static collider ok"

        ok, value = check("create_static_collider", create_static_collider)
        results["create_static_collider"] = {"ok": ok, "value": value}

        def create_rigid_body_and_joint():
            import omni.usd
            from pxr import Gf, UsdGeom, UsdPhysics

            stage = omni.usd.get_context().get_stage()
            paths = []
            for i, x in enumerate((0.0, 0.12)):
                cap = UsdGeom.Capsule.Define(stage, f"/World/test_endoscope_seg_{i}")
                cap.CreateAxisAttr("X")
                cap.CreateHeightAttr(0.10)
                cap.CreateRadiusAttr(0.015)
                prim = cap.GetPrim()
                xform = UsdGeom.Xformable(prim)
                xform.AddTranslateOp().Set(Gf.Vec3d(x, 0, 0.1))
                UsdPhysics.CollisionAPI.Apply(prim)
                UsdPhysics.RigidBodyAPI.Apply(prim)
                paths.append(f"/World/test_endoscope_seg_{i}")
            joint = UsdPhysics.RevoluteJoint.Define(stage, "/World/test_revolute_joint")
            joint.CreateBody0Rel().SetTargets([paths[0]])
            joint.CreateBody1Rel().SetTargets([paths[1]])
            joint.CreateAxisAttr("Z")
            joint.CreateLowerLimitAttr(-90.0)
            joint.CreateUpperLimitAttr(90.0)
            return "rigid bodies + revolute joint ok"

        ok, value = check("create_rigid_body_and_joint", create_rigid_body_and_joint)
        results["create_rigid_body_and_joint"] = {"ok": ok, "value": value}

        def step_timeline():
            import omni.timeline

            timeline = omni.timeline.get_timeline_interface()
            timeline.play()
            for _ in range(5):
                app.update()
            timeline.stop()
            return "timeline stepped 5 frames"

        ok, value = check("step_timeline", step_timeline)
        results["step_timeline"] = {"ok": ok, "value": value}

        def create_camera():
            import omni.usd
            from pxr import Gf, UsdGeom

            stage = omni.usd.get_context().get_stage()
            cam = UsdGeom.Camera.Define(stage, "/World/test_camera")
            xform = UsdGeom.Xformable(cam.GetPrim())
            xform.AddTranslateOp().Set(Gf.Vec3d(0, 0, 1.0))
            cam.CreateFocalLengthAttr(18.0)
            return "camera prim ok"

        ok, value = check("create_camera_prim", create_camera)
        results["create_camera_prim"] = {"ok": ok, "value": value}

        def save_usd():
            import omni.usd

            out = Path("outputs/isaac_capability_check")
            out.mkdir(parents=True, exist_ok=True)
            usd_path = out / "capability_check.usd"
            stage = omni.usd.get_context().get_stage()
            stage.GetRootLayer().Export(str(usd_path))
            return str(usd_path)

        ok, value = check("save_usd", save_usd)
        results["save_usd"] = {"ok": ok, "value": value}

    finally:
        Path("outputs/isaac_capability_check").mkdir(parents=True, exist_ok=True)
        Path("outputs/isaac_capability_check/results.json").write_text(
            json.dumps(results, indent=2),
            encoding="utf-8",
        )
        if app is not None and hasattr(app, "close"):
            app.close()

    required = [
        "import_isaacsim",
        "start_headless_simulation_app",
        "import_usd_physx_modules",
        "create_stage_and_physics_scene",
        "create_static_collider",
        "create_rigid_body_and_joint",
        "step_timeline",
        "create_camera_prim",
        "save_usd",
    ]
    failed = [name for name in required if not results.get(name, {}).get("ok")]
    if failed:
        print("ISAACSIM_CAPABILITY_CHECK_FAILED")
        print("failed:", ", ".join(failed))
        raise SystemExit(1)
    print("ISAACSIM_CAPABILITY_CHECK_PASSED")


if __name__ == "__main__":
    main()

