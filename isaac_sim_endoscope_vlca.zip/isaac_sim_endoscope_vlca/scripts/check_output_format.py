import json
from pathlib import Path


def main():
    episode = Path("outputs/endoscope_single_latest/episode_000000")
    required = [
        "frames/ebv",
        "frames/ev",
        "render_frames",
        "tip_frames",
        "debug_frames",
        "trajectory.csv",
        "control_commands.csv",
        "annotations.json",
        "metadata.json",
        "scene.usd",
    ]
    missing = [item for item in required if not (episode / item).exists()]
    if missing:
        print("OUTPUT_FORMAT_CHECK_FAILED")
        print("missing:", ", ".join(missing))
        raise SystemExit(1)
    annotations = json.loads((episode / "annotations.json").read_text(encoding="utf-8"))
    metadata = json.loads((episode / "metadata.json").read_text(encoding="utf-8"))
    assert annotations.get("format") == "vlca_sim_annotations_v1"
    assert metadata.get("output_format") == "genesis_compatible_episode_v1"
    print("OUTPUT_FORMAT_CHECK_PASSED")


if __name__ == "__main__":
    main()

