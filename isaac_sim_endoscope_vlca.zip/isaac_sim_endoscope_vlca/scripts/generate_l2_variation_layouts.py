import json
import math
from pathlib import Path


BOARD_SIZE = [1.55, 1.10]
START = [-0.72, 0.0]


def block(name, x, y, sx, sy, kind="distractor", shape="rectangle"):
    return {
        "name": name,
        "kind": kind,
        "shape": shape,
        "position": [round(x, 4), round(y, 4)],
        "size": [round(sx, 4), round(sy, 4)],
        "radius": round(max(sx, sy) / 2.0, 4),
        "height": 0.07,
    }


def circle(name, x, y, radius, kind="solid"):
    return block(name, x, y, radius * 2.0, radius * 2.0, kind=kind, shape="circle")


def target(x, y):
    return [{
        "name": "target_star",
        "kind": "target",
        "shape": "pentagon",
        "position": [round(x, 4), round(y, 4)],
        "size": [0.105, 0.105],
        "height": 0.055,
        "active": True,
    }]


def target_entry(x, y):
    return [round(x - 0.105 * 0.5 * 0.95, 4), round(y, 4)]


def route_distance(points):
    route = [START] + points
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(route, route[1:]))


def control(points, slack, gain, target_radius=0.14):
    return {
        "bend_keyframes": [
            {"progress": 0.0, "bend": 0},
            {"progress": 0.2, "bend": 0},
            {"progress": 0.4, "bend": 0},
            {"progress": 0.7, "bend": 0},
            {"progress": 1.0, "bend": 0},
        ],
        "drive_distance": round(route_distance(points) + slack, 3),
        "target_radius": target_radius,
        "steering_start_x": -0.70,
        "waypoint_radius": 0.115,
        "waypoint_pass_margin_x": 0.018,
        "final_homing_distance": 0.28,
        "final_homing_gain": 92.0,
        "route_heading_gain": gain,
    }


def l2(name, b6, b3, tgt, route, distractors):
    route_order = ["pre_B6", "guide_B6", "exit_B6", "pre_B3", "guide_B3", "exit_B3", "target_star"]
    points = [route[key] for key in route_order[:-1]] + [target_entry(*tgt)]
    blocks = list(distractors)
    if not any(item["name"] == "guide_B6" for item in blocks):
        blocks.append(block("guide_B6", *b6, kind="solid"))
    if not any(item["name"] == "guide_B3" for item in blocks):
        blocks.append(block("guide_B3", *b3, kind="solid"))
    return {
        "name": name,
        "level": "L2",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": blocks,
        "targets": target(*tgt),
        "route_order": route_order,
        "route_sides": route.get("_sides", {}),
        "route_waypoint_overrides": {
            **{key: [round(value[0], 4), round(value[1], 4)] for key, value in route.items() if not key.startswith("_")},
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.22, 72.0, 0.16),
    }


def l1(name, b3, tgt, route, distractors):
    route_order = ["pre_B3", "guide_B3", "exit_B3", "target_star"]
    points = [route[key] for key in route_order[:-1]] + [target_entry(*tgt)]
    blocks = list(distractors)
    if not any(item["name"] == "guide_B3" for item in blocks):
        blocks.append(block("guide_B3", *b3, kind="solid"))
    return {
        "name": name,
        "level": "L1",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": blocks,
        "targets": target(*tgt),
        "route_order": route_order,
        "route_sides": route.get("_sides", {}),
        "route_waypoint_overrides": {
            **{key: [round(value[0], 4), round(value[1], 4)] for key, value in route.items() if not key.startswith("_")},
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.24, 72.0, 0.16),
    }


def l0(name, tgt, mid, distractors):
    route_order = ["mid_direct", "target_star"]
    points = [mid, target_entry(*tgt)]
    return {
        "name": name,
        "level": "L0",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": distractors,
        "targets": target(*tgt),
        "route_order": route_order,
        "route_waypoint_overrides": {
            "mid_direct": [round(mid[0], 4), round(mid[1], 4)],
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.18, 50.0, 0.15),
    }


setups = [
    l2("L2_rect_circle_down", (-0.46, 0.06, 0.085, 0.12), (-0.17, -0.04, 0.12, 0.12), (0.09, 0.05), {
        "pre_B6": (-0.60, -0.035), "guide_B6": (-0.46, -0.035), "exit_B6": (-0.34, -0.030),
        "pre_B3": (-0.29, 0.070), "guide_B3": (-0.17, 0.070), "exit_B3": (-0.045, 0.065),
        "_sides": {"guide_B6": "lower", "guide_B3": "upper"},
    }, [circle("guide_B3", -0.17, -0.04, 0.060), block("distractor_B1", 0.30, 0.38, 0.16, 0.08), block("distractor_B4", 0.58, 0.15, 0.08, 0.16)]),
    l2("L2_circle_rect_low", (-0.50, 0.02, 0.12, 0.12), (-0.22, 0.07, 0.095, 0.12), (0.06, -0.08), {
        "pre_B6": (-0.64, -0.080), "guide_B6": (-0.50, -0.080), "exit_B6": (-0.38, -0.075),
        "pre_B3": (-0.32, -0.030), "guide_B3": (-0.22, -0.030), "exit_B3": (-0.085, -0.045),
        "_sides": {"guide_B6": "lower", "guide_B3": "lower"},
    }, [circle("guide_B6", -0.50, 0.02, 0.060), block("distractor_B1", 0.36, 0.40, 0.16, 0.08), block("distractor_B4", 0.61, 0.10, 0.08, 0.16)]),
    l2("L2_upper_then_lower", (-0.42, -0.055, 0.085, 0.12), (-0.12, 0.060, 0.095, 0.115), (0.12, -0.015), {
        "pre_B6": (-0.56, 0.040), "guide_B6": (-0.42, 0.040), "exit_B6": (-0.30, 0.030),
        "pre_B3": (-0.23, -0.040), "guide_B3": (-0.12, -0.040), "exit_B3": (0.005, -0.035),
        "_sides": {"guide_B6": "upper", "guide_B3": "lower"},
    }, [block("distractor_B1", 0.28, 0.42, 0.16, 0.08), block("distractor_B4", 0.62, 0.16, 0.08, 0.16)]),
    l2("L2_lower_then_upper", (-0.49, 0.060, 0.085, 0.12), (-0.20, -0.055, 0.095, 0.115), (0.07, 0.075), {
        "pre_B6": (-0.63, -0.035), "guide_B6": (-0.49, -0.035), "exit_B6": (-0.36, -0.020),
        "pre_B3": (-0.30, 0.040), "guide_B3": (-0.20, 0.040), "exit_B3": (-0.070, 0.055),
        "_sides": {"guide_B6": "lower", "guide_B3": "upper"},
    }, [block("distractor_B1", 0.26, 0.38, 0.16, 0.08), block("distractor_B4", 0.56, 0.14, 0.08, 0.16)]),
    l2("L2_double_circle_shallow", (-0.39, 0.030, 0.11, 0.11), (-0.09, 0.030, 0.10, 0.10), (0.14, 0.030), {
        "pre_B6": (-0.54, -0.070), "guide_B6": (-0.39, -0.070), "exit_B6": (-0.27, -0.065),
        "pre_B3": (-0.21, -0.065), "guide_B3": (-0.09, -0.065), "exit_B3": (0.040, -0.065),
        "_sides": {"guide_B6": "lower", "guide_B3": "lower"},
    }, [circle("guide_B6", -0.39, 0.030, 0.055), circle("guide_B3", -0.09, 0.030, 0.050), block("distractor_B4", 0.60, 0.12, 0.08, 0.16)]),
    l2("L2_rect_rect_low_target", (-0.47, 0.070, 0.085, 0.12), (-0.17, 0.080, 0.095, 0.115), (0.08, -0.110), {
        "pre_B6": (-0.62, -0.025), "guide_B6": (-0.47, -0.025), "exit_B6": (-0.35, -0.035),
        "pre_B3": (-0.29, -0.020), "guide_B3": (-0.17, -0.020), "exit_B3": (-0.055, -0.060),
        "_sides": {"guide_B6": "lower", "guide_B3": "lower"},
    }, [block("distractor_B1", 0.42, 0.42, 0.16, 0.08), block("distractor_B4", 0.63, 0.14, 0.08, 0.16)]),
    l1("L1_circle_upper", (-0.25, -0.045, 0.12, 0.12), (0.095, 0.085), {
        "pre_B3": (-0.40, 0.055), "guide_B3": (-0.25, 0.055), "exit_B3": (-0.085, 0.070),
        "_sides": {"guide_B3": "upper"},
    }, [circle("guide_B3", -0.25, -0.045, 0.060), block("distractor_B1", 0.32, 0.40, 0.16, 0.08), block("distractor_B4", 0.62, 0.12, 0.08, 0.16)]),
    l1("L1_rect_lower", (-0.22, 0.055, 0.095, 0.12), (0.110, -0.085), {
        "pre_B3": (-0.38, -0.040), "guide_B3": (-0.22, -0.040), "exit_B3": (-0.055, -0.060),
        "_sides": {"guide_B3": "lower"},
    }, [block("distractor_B1", 0.27, 0.42, 0.16, 0.08), block("distractor_B4", 0.60, 0.14, 0.08, 0.16)]),
    l0("L0_target_upper", (0.000, 0.085), (-0.330, 0.060), [
        block("distractor_B1", 0.32, 0.41, 0.16, 0.08), block("distractor_B4", 0.60, 0.12, 0.08, 0.16),
    ]),
    l0("L0_target_lower", (0.000, -0.085), (-0.330, -0.060), [
        block("distractor_B1", 0.32, 0.41, 0.16, 0.08), block("distractor_B4", 0.60, 0.12, 0.08, 0.16),
    ]),
]


Path("layouts/l2_and_variation_batch.json").write_text(json.dumps({"setups": setups}, indent=2), encoding="utf-8")
print(f"WROTE layouts/l2_and_variation_batch.json setups={len(setups)}")
