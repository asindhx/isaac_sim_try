import json
import math
from pathlib import Path


BOARD_SIZE = [1.55, 1.10]
START = [-0.72, 0.0]


def block(name, x, y, sx, sy, kind="distractor"):
    return {
        "name": name,
        "kind": kind,
        "shape": "rectangle",
        "position": [round(x, 4), round(y, 4)],
        "size": [round(sx, 4), round(sy, 4)],
        "height": 0.07,
    }


def target(x, y):
    return [{
        "name": "target_star",
        "kind": "target",
        "shape": "pentagon",
        "position": [round(x, 4), round(y, 4)],
        "size": [0.105, 0.105],
        "height": 0.055,
        "active": True,
    }]


def target_entry(x, y):
    return [round(x - 0.105 * 0.5 * 0.95, 4), round(y, 4)]


def route_distance(points):
    route = [START] + points
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(route, route[1:]))


def control(points, slack, gain):
    return {
        "bend_keyframes": [
            {"progress": 0.0, "bend": 0},
            {"progress": 0.2, "bend": 0},
            {"progress": 0.4, "bend": 0},
            {"progress": 0.7, "bend": 0},
            {"progress": 1.0, "bend": 0},
        ],
        "drive_distance": round(route_distance(points) + slack, 3),
        "target_radius": 0.12,
        "steering_start_x": -0.70,
        "waypoint_radius": 0.115,
        "waypoint_pass_margin_x": 0.018,
        "final_homing_distance": 0.28,
        "final_homing_gain": 92.0,
        "route_heading_gain": gain,
    }


def l2(name, b6, b3, tgt, route, distractors):
    route_order = ["pre_B6", "guide_B6", "exit_B6", "pre_B3", "guide_B3", "target_star"]
    points = [route[key] for key in route_order[:-1]] + [target_entry(*tgt)]
    return {
        "name": name,
        "level": "L2",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": distractors + [
            block("guide_B6", *b6, kind="solid"),
            block("guide_B3", *b3, kind="solid"),
        ],
        "targets": target(*tgt),
        "route_order": route_order,
        "route_waypoint_overrides": {
            **{key: [round(value[0], 4), round(value[1], 4)] for key, value in route.items()},
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.18, 58.0),
    }


def l1(name, b3, tgt, route, distractors):
    route_order = ["pre_B3", "guide_B3", "target_star"]
    points = [route[key] for key in route_order[:-1]] + [target_entry(*tgt)]
    return {
        "name": name,
        "level": "L1",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": distractors + [block("guide_B3", *b3, kind="solid")],
        "targets": target(*tgt),
        "route_order": route_order,
        "route_waypoint_overrides": {
            **{key: [round(value[0], 4), round(value[1], 4)] for key, value in route.items()},
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.24, 64.0),
    }


def l0(name, tgt, mid, distractors):
    route_order = ["mid_direct", "target_star"]
    points = [mid, target_entry(*tgt)]
    return {
        "name": name,
        "level": "L0",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": distractors,
        "targets": target(*tgt),
        "route_order": route_order,
        "route_waypoint_overrides": {
            "mid_direct": [round(mid[0], 4), round(mid[1], 4)],
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.20, 42.0),
    }


setups = [
    l2("L2_turning_lower_then_center", (-0.43, -0.05, 0.108, 0.194), (-0.14, 0.09, 0.136, 0.135), (0.05, -0.01), {
        "pre_B6": (-0.58, -0.18), "guide_B6": (-0.44, -0.18), "exit_B6": (-0.34, -0.18),
        "pre_B3": (-0.27, 0.0), "guide_B3": (-0.15, -0.01),
    }, [block("distractor_B1", 0.36, 0.43, 0.21, 0.10), block("distractor_B4", 0.59, 0.04, 0.11, 0.19)]),
    l2("L2_turning_deep_lower_target_low", (-0.47, 0.02, 0.12, 0.20), (-0.16, 0.17, 0.13, 0.15), (0.08, -0.12), {
        "pre_B6": (-0.61, -0.13), "guide_B6": (-0.48, -0.13), "exit_B6": (-0.37, -0.13),
        "pre_B3": (-0.31, 0.06), "guide_B3": (-0.18, 0.07),
    }, [block("distractor_B1", 0.30, 0.36, 0.20, 0.10), block("distractor_B4", 0.53, -0.03, 0.10, 0.21)]),
    l2("L2_turning_upper_pass_target_high", (-0.40, -0.14, 0.11, 0.18), (-0.10, -0.02, 0.14, 0.13), (0.10, 0.12), {
        "pre_B6": (-0.56, -0.018), "guide_B6": (-0.41, -0.018), "exit_B6": (-0.29, -0.018),
        "pre_B3": (-0.23, 0.13), "guide_B3": (-0.11, 0.115),
    }, [block("distractor_B1", 0.34, 0.43, 0.18, 0.09), block("distractor_B4", 0.56, -0.14, 0.10, 0.18)]),
    l2("L2_turning_s_curve_to_upper_target", (-0.50, -0.03, 0.105, 0.19), (-0.20, -0.13, 0.13, 0.14), (0.02, 0.09), {
        "pre_B6": (-0.62, -0.18), "guide_B6": (-0.50, -0.18), "exit_B6": (-0.395, -0.18),
        "pre_B3": (-0.32, 0.03), "guide_B3": (-0.21, 0.0),
    }, [block("distractor_B1", 0.24, 0.38, 0.16, 0.12), block("distractor_B4", 0.48, 0.12, 0.12, 0.17)]),
    l2("L2_turning_shallow_middle", (-0.36, 0.02, 0.12, 0.18), (-0.06, 0.13, 0.12, 0.13), (0.16, 0.02), {
        "pre_B6": (-0.52, -0.115), "guide_B6": (-0.36, -0.115), "exit_B6": (-0.255, -0.115),
        "pre_B3": (-0.19, 0.03), "guide_B3": (-0.065, 0.03),
    }, [block("distractor_B1", 0.39, 0.34, 0.19, 0.10), block("distractor_B4", 0.62, -0.04, 0.09, 0.22)]),
    l2("L2_turning_wide_lower_right", (-0.52, -0.11, 0.11, 0.20), (-0.19, 0.16, 0.14, 0.14), (0.13, -0.06), {
        "pre_B6": (-0.64, -0.25), "guide_B6": (-0.52, -0.245), "exit_B6": (-0.44, -0.245),
        "pre_B3": (-0.33, 0.045), "guide_B3": (-0.20, 0.055),
    }, [block("distractor_B1", 0.43, 0.42, 0.21, 0.09), block("distractor_B4", 0.64, 0.08, 0.11, 0.18)]),
    l1("L1_turning_low_detour", (-0.25, -0.02, 0.12, 0.20), (0.05, -0.15), {
        "pre_B3": (-0.38, -0.18), "guide_B3": (-0.25, -0.18),
    }, [block("distractor_B1", 0.31, 0.36, 0.20, 0.10), block("distractor_B4", 0.55, 0.05, 0.10, 0.18)]),
    l1("L1_turning_high_detour", (-0.20, 0.13, 0.13, 0.18), (0.10, 0.12), {
        "pre_B3": (-0.36, 0.25), "guide_B3": (-0.10, 0.25),
    }, [block("distractor_B1", 0.26, 0.42, 0.18, 0.10), block("distractor_B4", 0.58, -0.10, 0.11, 0.19)]),
    l0("L0_turning_upper_target", (-0.12, 0.12), (-0.44, 0.09), [
        block("distractor_B1", 0.28, 0.38, 0.18, 0.10), block("distractor_B4", 0.56, -0.08, 0.10, 0.18),
    ]),
    l0("L0_turning_lower_target", (-0.12, -0.13), (-0.44, -0.095), [
        block("distractor_B1", 0.34, 0.42, 0.19, 0.10), block("distractor_B4", 0.52, 0.10, 0.11, 0.19),
    ]),
]


Path("layouts/l2_and_variation_batch.json").write_text(json.dumps({"setups": setups}, indent=2), encoding="utf-8")
print(f"WROTE layouts/l2_and_variation_batch.json setups={len(setups)}")
