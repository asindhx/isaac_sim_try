import json
import math
from pathlib import Path


BOARD_SIZE = [1.55, 1.10]
START = [-0.72, 0.0]


def block(name, x, y, sx, sy, kind="distractor"):
    return {
        "name": name,
        "kind": kind,
        "shape": "rectangle",
        "position": [round(x, 4), round(y, 4)],
        "size": [round(sx, 4), round(sy, 4)],
        "height": 0.07,
    }


def target(x, y):
    return [{
        "name": "target_star",
        "kind": "target",
        "shape": "pentagon",
        "position": [round(x, 4), round(y, 4)],
        "size": [0.105, 0.105],
        "height": 0.055,
        "active": True,
    }]


def target_entry(x, y):
    return [round(x - 0.105 * 0.5 * 0.95, 4), round(y, 4)]


def route_distance(points):
    route = [START] + points
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(route, route[1:]))


def control(points, slack, gain):
    return {
        "bend_keyframes": [
            {"progress": 0.0, "bend": 0},
            {"progress": 0.2, "bend": 0},
            {"progress": 0.4, "bend": 0},
            {"progress": 0.7, "bend": 0},
            {"progress": 1.0, "bend": 0},
        ],
        "drive_distance": round(route_distance(points) + slack, 3),
        "target_radius": 0.12,
        "steering_start_x": -0.70,
        "waypoint_radius": 0.115,
        "waypoint_pass_margin_x": 0.018,
        "final_homing_distance": 0.28,
        "final_homing_gain": 92.0,
        "route_heading_gain": gain,
    }


def l2(name, b6, b3, tgt, route, distractors):
    route_order = ["pre_B6", "guide_B6", "exit_B6", "pre_B3", "guide_B3", "exit_B3", "target_star"]
    points = [route[key] for key in route_order[:-1]] + [target_entry(*tgt)]
    return {
        "name": name,
        "level": "L2",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": distractors + [
            block("guide_B6", *b6, kind="solid"),
            block("guide_B3", *b3, kind="solid"),
        ],
        "targets": target(*tgt),
        "route_order": route_order,
        "route_waypoint_overrides": {
            **{key: [round(value[0], 4), round(value[1], 4)] for key, value in route.items()},
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.18, 58.0),
    }


def l1(name, b3, tgt, route, distractors):
    route_order = ["pre_B3", "guide_B3", "exit_B3", "target_star"]
    points = [route[key] for key in route_order[:-1]] + [target_entry(*tgt)]
    return {
        "name": name,
        "level": "L1",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": distractors + [block("guide_B3", *b3, kind="solid")],
        "targets": target(*tgt),
        "route_order": route_order,
        "route_waypoint_overrides": {
            **{key: [round(value[0], 4), round(value[1], 4)] for key, value in route.items()},
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.24, 64.0),
    }


def l0(name, tgt, mid, distractors):
    route_order = ["mid_direct", "target_star"]
    points = [mid, target_entry(*tgt)]
    return {
        "name": name,
        "level": "L0",
        "source_image": name,
        "board_size": BOARD_SIZE,
        "start_position": START,
        "blocks": distractors,
        "targets": target(*tgt),
        "route_order": route_order,
        "route_waypoint_overrides": {
            "mid_direct": [round(mid[0], 4), round(mid[1], 4)],
            "target_star": target_entry(*tgt),
        },
        "control": control(points, 0.20, 42.0),
    }


setups = [
    l2("L2_bend_lower_center", (-0.455, 0.015, 0.095, 0.170), (-0.155, 0.105, 0.115, 0.115), (0.105, 0.015), {
        "pre_B6": (-0.600, -0.142), "guide_B6": (-0.455, -0.142), "exit_B6": (-0.330, -0.142),
        "pre_B3": (-0.270, -0.025), "guide_B3": (-0.155, -0.025), "exit_B3": (-0.035, -0.020),
    }, [block("distractor_B1", 0.32, 0.42, 0.17, 0.08), block("distractor_B4", 0.62, 0.16, 0.08, 0.16)]),
    l2("L2_bend_lower_shifted_left", (-0.500, 0.000, 0.095, 0.165), (-0.205, 0.085, 0.110, 0.115), (0.075, -0.065), {
        "pre_B6": (-0.640, -0.155), "guide_B6": (-0.500, -0.155), "exit_B6": (-0.380, -0.155),
        "pre_B3": (-0.315, -0.045), "guide_B3": (-0.205, -0.045), "exit_B3": (-0.075, -0.050),
    }, [block("distractor_B1", 0.30, 0.39, 0.16, 0.08), block("distractor_B4", 0.58, 0.13, 0.08, 0.16)]),
    l2("L2_bend_lower_shifted_right", (-0.405, 0.010, 0.095, 0.165), (-0.105, 0.095, 0.110, 0.115), (0.155, 0.035), {
        "pre_B6": (-0.550, -0.145), "guide_B6": (-0.405, -0.145), "exit_B6": (-0.280, -0.145),
        "pre_B3": (-0.220, -0.035), "guide_B3": (-0.105, -0.035), "exit_B3": (0.020, -0.020),
    }, [block("distractor_B1", 0.35, 0.43, 0.16, 0.08), block("distractor_B4", 0.64, 0.10, 0.08, 0.16)]),
    l2("L2_bend_slight_s", (-0.485, -0.035, 0.095, 0.165), (-0.190, 0.040, 0.110, 0.115), (0.085, 0.055), {
        "pre_B6": (-0.630, -0.175), "guide_B6": (-0.485, -0.175), "exit_B6": (-0.360, -0.155),
        "pre_B3": (-0.305, -0.075), "guide_B3": (-0.190, -0.075), "exit_B3": (-0.060, -0.055),
    }, [block("distractor_B1", 0.25, 0.39, 0.16, 0.08), block("distractor_B4", 0.56, 0.14, 0.08, 0.16)]),
    l2("L2_bend_middle", (-0.430, -0.020, 0.095, 0.160), (-0.135, 0.055, 0.105, 0.110), (0.135, -0.030), {
        "pre_B6": (-0.575, -0.155), "guide_B6": (-0.430, -0.155), "exit_B6": (-0.305, -0.155),
        "pre_B3": (-0.250, -0.060), "guide_B3": (-0.135, -0.060), "exit_B3": (-0.010, -0.058),
    }, [block("distractor_B1", 0.38, 0.40, 0.16, 0.08), block("distractor_B4", 0.60, 0.12, 0.08, 0.16)]),
    l2("L2_bend_low_target", (-0.470, 0.030, 0.095, 0.165), (-0.170, 0.115, 0.110, 0.115), (0.100, -0.095), {
        "pre_B6": (-0.610, -0.125), "guide_B6": (-0.470, -0.125), "exit_B6": (-0.350, -0.125),
        "pre_B3": (-0.290, -0.017), "guide_B3": (-0.170, -0.017), "exit_B3": (-0.050, -0.030),
    }, [block("distractor_B1", 0.42, 0.42, 0.16, 0.08), block("distractor_B4", 0.63, 0.14, 0.08, 0.16)]),
    l1("L1_bend_low_detour", (-0.240, 0.045, 0.105, 0.165), (0.095, -0.075), {
        "pre_B3": (-0.400, -0.110), "guide_B3": (-0.240, -0.110), "exit_B3": (-0.090, -0.100),
    }, [block("distractor_B1", 0.32, 0.40, 0.16, 0.08), block("distractor_B4", 0.62, 0.12, 0.08, 0.16)]),
    l1("L1_bend_second_goes_down", (-0.210, 0.075, 0.105, 0.165), (0.120, -0.055), {
        "pre_B3": (-0.370, -0.080), "guide_B3": (-0.210, -0.080), "exit_B3": (-0.065, -0.078),
    }, [block("distractor_B1", 0.27, 0.42, 0.16, 0.08), block("distractor_B4", 0.60, 0.14, 0.08, 0.16)]),
    l0("L0_bend_upper_target", (-0.045, 0.070), (-0.380, 0.075), [
        block("distractor_B1", -0.260, -0.015, 0.095, 0.115), block("distractor_B4", 0.58, 0.17, 0.08, 0.16),
    ]),
    l0("L0_bend_lower_target", (-0.045, -0.070), (-0.380, -0.075), [
        block("distractor_B1", -0.260, 0.015, 0.095, 0.115), block("distractor_B4", 0.58, 0.17, 0.08, 0.16),
    ]),
]


Path("layouts/l2_and_variation_batch.json").write_text(json.dumps({"setups": setups}, indent=2), encoding="utf-8")
print(f"WROTE layouts/l2_and_variation_batch.json setups={len(setups)}")
