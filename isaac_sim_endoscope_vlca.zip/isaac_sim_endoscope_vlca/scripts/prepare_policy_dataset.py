import argparse
import csv
import io
import json
import zipfile
from pathlib import Path

import numpy as np


CSV_COLUMNS = [
    "frame_id",
    "t_mono",
    "joy_ud",
    "joy_lr",
    "m1_spd",
    "m2_spd",
    "m3_spd",
    "m4_spd",
    "m1_pos",
    "m2_pos",
    "m3_pos",
    "m4_pos",
    "pwm_duty",
    "em_valid",
    "em_x",
    "em_y",
    "em_z",
    "em_qw",
    "em_qx",
    "em_qy",
    "em_qz",
    "ebv_block_boxes_json",
    "ebv_tip_box_json",
    "ev_block_boxes_json",
    "guiding_block_id",
    "waypoint_x",
    "waypoint_y",
]
ACTION_COLUMNS = ["m1_spd", "m2_spd", "m3_spd", "m4_spd"]
FEATURE_COLUMNS = [
    "tip_x",
    "tip_y",
    "tip_conf",
    "target_x",
    "target_y",
    "target_w",
    "target_h",
    "route_remaining",
    "first_block_x",
    "first_block_y",
    "first_block_w",
    "first_block_h",
    "joy_ud",
    "joy_lr",
    "m1_pos",
    "m2_pos",
    "m3_pos",
    "m4_pos",
    "pwm_duty",
]


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", nargs="+", required=True, help="Episode folders or .zip data_collection files.")
    parser.add_argument("--output-dir", default="outputs/policy_dataset")
    parser.add_argument("--action-columns", default=",".join(ACTION_COLUMNS))
    return parser.parse_args()


def safe_float(value, default=0.0):
    try:
        if value in ("", None, "nan", "NaN", "null"):
            return default
        return float(value)
    except Exception:
        return default


def read_episode_from_dir(path):
    data_csv = path / "data.csv"
    vlca_json = path / "json" / "vlca.json"
    if not data_csv.exists() or not vlca_json.exists():
        raise FileNotFoundError(f"Missing data.csv or json/vlca.json in {path}")
    rows = list(csv.DictReader(data_csv.open(newline="", encoding="utf-8")))
    vlca = json.loads(vlca_json.read_text(encoding="utf-8"))
    return rows, vlca, str(path)


def read_episode_from_zip(path):
    with zipfile.ZipFile(path) as zf:
        data_name = next((name for name in zf.namelist() if name.endswith("/data.csv")), None)
        vlca_name = next((name for name in zf.namelist() if name.endswith("/json/vlca.json")), None)
        if data_name is None or vlca_name is None:
            raise FileNotFoundError(f"Missing data.csv or json/vlca.json in {path}")
        rows = list(csv.DictReader(io.TextIOWrapper(zf.open(data_name), encoding="utf-8", newline="")))
        vlca = json.loads(zf.read(vlca_name).decode("utf-8"))
    return rows, vlca, str(path)


def read_episode(path):
    path = Path(path)
    if path.suffix.lower() == ".zip":
        return read_episode_from_zip(path)
    return read_episode_from_dir(path)


def frame_name(index):
    return f"{index:04d}.jpg"


def target_label(vlca, name):
    labels = vlca.get("labels", {}).get(name, [])
    for label in labels:
        if label.get("prompt") == "target":
            return label
    return {"x": 0.0, "y": 0.0, "w": 0.0, "h": 0.0}


def block_by_id(vlca):
    return {
        block.get("blockId"): block
        for block in vlca.get("referenceBlocks", [])
        if block.get("blockId")
    }


def feature_row(row, vlca, index):
    name = frame_name(index)
    tip = vlca.get("tipPoints", {}).get(name, {})
    target = target_label(vlca, name)
    plan = vlca.get("framePlanningLists", {}).get(name, vlca.get("globalPlanningList", [])) or []
    blocks = block_by_id(vlca)
    first = blocks.get(plan[0], {}) if plan and plan[0] != "Target" else {}
    return [
        safe_float(tip.get("x")),
        safe_float(tip.get("y")),
        safe_float(tip.get("confidence")),
        safe_float(target.get("x")),
        safe_float(target.get("y")),
        safe_float(target.get("w")),
        safe_float(target.get("h")),
        float(len(plan)),
        safe_float(first.get("x")),
        safe_float(first.get("y")),
        safe_float(first.get("w")),
        safe_float(first.get("h")),
        safe_float(row.get("joy_ud")),
        safe_float(row.get("joy_lr")),
        safe_float(row.get("m1_pos")),
        safe_float(row.get("m2_pos")),
        safe_float(row.get("m3_pos")),
        safe_float(row.get("m4_pos")),
        safe_float(row.get("pwm_duty")),
    ]


def build_dataset(inputs, action_columns):
    features = []
    actions = []
    sample_rows = []
    manifest = []
    for source_index, source in enumerate(inputs):
        rows, vlca, source_name = read_episode(source)
        used = 0
        for idx, row in enumerate(rows, start=1):
            action = [safe_float(row.get(col)) for col in action_columns]
            if not any(abs(value) > 1e-9 for value in action):
                continue
            feat = feature_row(row, vlca, idx)
            features.append(feat)
            actions.append(action)
            sample_rows.append({
                "source_index": source_index,
                "source": source_name,
                "frame_name": frame_name(idx),
                **{col: feat[i] for i, col in enumerate(FEATURE_COLUMNS)},
                **{col: action[i] for i, col in enumerate(action_columns)},
            })
            used += 1
        manifest.append({"source": source_name, "rows": len(rows), "samples_used": used})
    if not features:
        raise RuntimeError("No nonzero action samples found.")
    return np.asarray(features, dtype=np.float32), np.asarray(actions, dtype=np.float32), sample_rows, manifest


def main():
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    action_columns = [item.strip() for item in args.action_columns.split(",") if item.strip()]
    x, y, sample_rows, manifest = build_dataset(args.inputs, action_columns)
    np.savez(
        output_dir / "policy_dataset.npz",
        x=x,
        y=y,
        feature_columns=np.asarray(FEATURE_COLUMNS),
        action_columns=np.asarray(action_columns),
    )
    with (output_dir / "samples.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(sample_rows[0].keys()))
        writer.writeheader()
        writer.writerows(sample_rows)
    (output_dir / "manifest.json").write_text(
        json.dumps({
            "inputs": manifest,
            "num_samples": int(x.shape[0]),
            "num_features": int(x.shape[1]),
            "num_actions": int(y.shape[1]),
            "feature_columns": FEATURE_COLUMNS,
            "action_columns": action_columns,
        }, indent=2),
        encoding="utf-8",
    )
    print(f"POLICY_DATASET_READY samples={x.shape[0]} features={x.shape[1]} actions={y.shape[1]} output={output_dir}")


if __name__ == "__main__":
    main()
