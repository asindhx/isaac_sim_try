import argparse
import csv
import json
from pathlib import Path

import numpy as np


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="outputs/policy_dataset/policy_dataset.npz")
    parser.add_argument("--output-dir", default="outputs/policy_baseline")
    parser.add_argument("--ridge", type=float, default=1.0)
    parser.add_argument("--val-ratio", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=7)
    return parser.parse_args()


def standardize(train_x, x):
    mean = train_x.mean(axis=0, keepdims=True)
    std = train_x.std(axis=0, keepdims=True)
    std[std < 1e-6] = 1.0
    return (x - mean) / std, mean, std


def fit_ridge(x, y, ridge):
    x_aug = np.concatenate([x, np.ones((x.shape[0], 1), dtype=x.dtype)], axis=1)
    eye = np.eye(x_aug.shape[1], dtype=np.float32)
    eye[-1, -1] = 0.0
    return np.linalg.solve(x_aug.T @ x_aug + ridge * eye, x_aug.T @ y)


def predict(x, weights):
    x_aug = np.concatenate([x, np.ones((x.shape[0], 1), dtype=x.dtype)], axis=1)
    return x_aug @ weights


def metrics(pred, y):
    err = pred - y
    return {
        "mae": float(np.mean(np.abs(err))),
        "rmse": float(np.sqrt(np.mean(err ** 2))),
        "max_abs_error": float(np.max(np.abs(err))),
    }


def main():
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    data = np.load(args.dataset, allow_pickle=True)
    x = data["x"].astype(np.float32)
    y = data["y"].astype(np.float32)
    feature_columns = [str(item) for item in data["feature_columns"]]
    action_columns = [str(item) for item in data["action_columns"]]
    order = rng.permutation(x.shape[0])
    val_count = max(1, int(round(x.shape[0] * args.val_ratio))) if x.shape[0] > 4 else 1
    val_idx = order[:val_count]
    train_idx = order[val_count:] if val_count < x.shape[0] else order
    train_x, val_x = x[train_idx], x[val_idx]
    train_y, val_y = y[train_idx], y[val_idx]
    train_xn, mean, std = standardize(train_x, train_x)
    val_xn = (val_x - mean) / std
    weights = fit_ridge(train_xn, train_y, args.ridge)
    train_pred = predict(train_xn, weights)
    val_pred = predict(val_xn, weights)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    np.savez(
        output_dir / "policy_ridge_model.npz",
        weights=weights,
        feature_mean=mean,
        feature_std=std,
        feature_columns=np.asarray(feature_columns),
        action_columns=np.asarray(action_columns),
    )
    report = {
        "model": "ridge_behavior_cloning",
        "dataset": str(args.dataset),
        "num_samples": int(x.shape[0]),
        "num_train": int(train_x.shape[0]),
        "num_val": int(val_x.shape[0]),
        "ridge": float(args.ridge),
        "train": metrics(train_pred, train_y),
        "val": metrics(val_pred, val_y),
        "feature_columns": feature_columns,
        "action_columns": action_columns,
    }
    (output_dir / "metrics.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    with (output_dir / "val_predictions.csv").open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["sample_index"]
        for col in action_columns:
            fieldnames += [f"true_{col}", f"pred_{col}"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row_i, sample_i in enumerate(val_idx):
            row = {"sample_index": int(sample_i)}
            for action_i, col in enumerate(action_columns):
                row[f"true_{col}"] = float(val_y[row_i, action_i])
                row[f"pred_{col}"] = float(val_pred[row_i, action_i])
            writer.writerow(row)
    print(
        "POLICY_BASELINE_READY "
        f"samples={x.shape[0]} val_mae={report['val']['mae']:.4f} "
        f"model={output_dir / 'policy_ridge_model.npz'}"
    )


if __name__ == "__main__":
    main()
