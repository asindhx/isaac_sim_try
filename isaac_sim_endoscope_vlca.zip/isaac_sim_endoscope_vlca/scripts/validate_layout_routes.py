import argparse
import json
import math
from pathlib import Path


TUBE_RADIUS = 0.024
CONTACT_MIN = 0.020
CONTACT_MAX = 0.075
ENTRY_SAFE_X = -0.58


def rect_bounds(block, expand=0.0):
    x, y = block["position"]
    sx, sy = block["size"]
    return (
        float(x) - float(sx) / 2.0 - expand,
        float(y) - float(sy) / 2.0 - expand,
        float(x) + float(sx) / 2.0 + expand,
        float(y) + float(sy) / 2.0 + expand,
    )


def point_for_name(setup, name):
    overrides = setup.get("route_waypoint_overrides", {})
    if name in overrides:
        return tuple(float(v) for v in overrides[name])
    for block in setup.get("blocks", []):
        if block.get("name") == name:
            return tuple(float(v) for v in block["position"])
    for target in setup.get("targets", []):
        if target.get("name") == name:
            x, y = target["position"]
            sx, sy = target.get("size", [0.1, 0.1])
            radius = max(float(sx), float(sy)) * 0.5
            return (float(x) - radius * 0.95, float(y))
    raise KeyError(f"unknown route waypoint {name}")


def segment_hits_rect(p0, p1, bounds):
    x0, y0 = p0
    x1, y1 = p1
    left, bottom, right, top = bounds
    dx = x1 - x0
    dy = y1 - y0
    t0 = 0.0
    t1 = 1.0
    for p, q in ((-dx, x0 - left), (dx, right - x0), (-dy, y0 - bottom), (dy, top - y0)):
        if abs(p) < 1e-12:
            if q < 0:
                return False
            continue
        r = q / p
        if p < 0:
            if r > t1:
                return False
            if r > t0:
                t0 = r
        else:
            if r < t0:
                return False
            if r < t1:
                t1 = r
    return True


def point_rect_distance(point, bounds):
    x, y = point
    left, bottom, right, top = bounds
    dx = max(left - x, 0.0, x - right)
    dy = max(bottom - y, 0.0, y - top)
    return math.hypot(dx, dy)


def turn_angle(prev_point, point, next_point):
    a0 = math.atan2(point[1] - prev_point[1], point[0] - prev_point[0])
    a1 = math.atan2(next_point[1] - point[1], next_point[0] - point[0])
    value = a1 - a0
    while value > math.pi:
        value -= math.pi * 2.0
    while value < -math.pi:
        value += math.pi * 2.0
    return abs(value)


def validate_setup(setup):
    route_names = list(setup.get("route_order", []))
    route = [tuple(setup.get("start_position", [-0.72, 0.0]))]
    route.extend(point_for_name(setup, name) for name in route_names)
    drive_distance = float(setup.get("control", {}).get("drive_distance", setup.get("drive_distance", 0.0)))
    path_length = sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(route, route[1:]))
    risks = []

    for block in setup.get("blocks", []):
        left, bottom, right, top = rect_bounds(block)
        if left < ENTRY_SAFE_X:
            risks.append(f"entry obstruction: {block.get('name')} extends to x={left:.3f}")

    for segment_index, (p0, p1) in enumerate(zip(route, route[1:]), start=1):
        for block in setup.get("blocks", []):
            name = block.get("name", "")
            if segment_hits_rect(p0, p1, rect_bounds(block, TUBE_RADIUS)):
                risks.append(f"segment {segment_index} enters tube-expanded block {name}")

    for name in route_names:
        if not name.startswith("guide_"):
            continue
        block = next((item for item in setup.get("blocks", []) if item.get("name") == name), None)
        if block is None:
            continue
        point = point_for_name(setup, name)
        distance = point_rect_distance(point, rect_bounds(block))
        if distance < CONTACT_MIN:
            risks.append(f"{name} waypoint penetrates/overloads contact: distance={distance:.3f}")
        if distance > CONTACT_MAX:
            risks.append(f"{name} waypoint too far for useful guiding contact: distance={distance:.3f}")

    for index in range(1, len(route) - 1):
        angle = turn_angle(route[index - 1], route[index], route[index + 1])
        if angle > math.radians(95.0):
            risks.append(f"route turn {index} is too sharp for the front bending section: {math.degrees(angle):.1f}deg")

    if drive_distance + 0.06 < path_length:
        risks.append(f"drive distance {drive_distance:.3f} is shorter than route length {path_length:.3f}")

    return {
        "name": setup.get("name"),
        "level": setup.get("level"),
        "route_order": route_names,
        "route_points": [{"x": round(x, 4), "y": round(y, 4)} for x, y in route],
        "route_length": round(path_length, 4),
        "drive_distance": round(drive_distance, 4),
        "risk_count": len(risks),
        "risks": risks,
    }


def route_signature(report):
    points = report["route_points"][1:]
    return tuple((round(point["x"], 2), round(point["y"], 2)) for point in points)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--setups", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    data = json.loads(Path(args.setups).read_text(encoding="utf-8"))
    setups = data.get("setups", [data])
    reports = [validate_setup(setup) for setup in setups]

    seen = {}
    for report in reports:
        signature = route_signature(report)
        if signature in seen:
            report["risks"].append(f"route duplicates {seen[signature]}")
            report["risk_count"] += 1
        else:
            seen[signature] = report["name"]

    summary = {
        "setups": len(reports),
        "failed": sum(1 for report in reports if report["risk_count"]),
        "reports": reports,
    }
    Path(args.report).write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"ROUTE_VALIDATION setups={summary['setups']} failed={summary['failed']} report={args.report}")
    if summary["failed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
