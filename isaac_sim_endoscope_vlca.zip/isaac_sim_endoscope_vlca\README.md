# Isaac Sim Endoscope VLCA

Isaac Sim version of the Genesis endoscope guide-block simulation. It keeps the same experiment idea and the same VLCA-style output contract:

- `trajectory.csv`
- `annotations.json`
- `metadata.json`
- `frames/ev/*.jpg`
- `frames/ebv/*.jpg`
- `json/vlca.json`
- `json/yolo_auto_gen.json`
- `aligned.csv`
- optional videos
- optional exported USD stage

## What This Recreates

The scene matches the Genesis zip:

- flat experiment table
- start clamp
- solid guide blocks as obstacles
- insertable guide blocks as pass-through/occlusion regions
- pentagon active target
- long visible endoscope body
- tip point, centerline, contact proxy, route targets
- level scoring: `solid = +1`, `insertable = +1.5`

The high-level VLCA data format is intentionally kept compatible with the Genesis exporter.

## Files

```text
config.py              Shared experiment config and layout loader
layout.json            Editable guide-block/target layout
route_planner.py       Route nodes, rounded path, level targets
endoscope_model.py     Visual endoscope chain and centerline model
isaac_scene.py         Isaac Sim/USD/PhysX scene builder
exporters.py           Trajectory, annotations, VLCA JSON, aligned CSV
isaac_main.py          Main entry point
requirements.txt       Non-Isaac helper dependencies
```

## Quick Dry Run Without Isaac Sim

This checks the output format on normal Python:

```bash
python isaac_main.py --dry-run-no-isaac --record --video --max-steps 300 --output-dir outputs/endoscope_isaac_vlca
```

If `imageio` is not installed, video export is skipped, but the VLCA files are still written.

## Recommended: Run Headless In Docker

Your old workflow starts the WebRTC visual interface with `isaac-sim.streaming.sh`. That is useful for manual inspection, but it is not needed for VLCA dataset generation.

For batch data generation, run Isaac Sim headless and mount this repo plus an output folder:

```bash
git clone <your-repo-url> isaac_sim_endoscope_vlca
cd isaac_sim_endoscope_vlca
mkdir -p /tmp/endoscope_isaac_outputs

docker run --rm -it \
  --gpus all \
  --network host \
  -e ACCEPT_EULA=Y \
  -v "$PWD":/workspace/isaac_sim_endoscope_vlca \
  -v /tmp/endoscope_isaac_outputs:/outputs \
  nvcr.io/nvidia/isaac-sim:5.1.0 \
  bash -lc "cd /isaac-sim && ./python.sh /workspace/isaac_sim_endoscope_vlca/isaac_main.py --record --no-render --output-dir /outputs/endoscope_isaac_vlca"
```

Outputs will be here on the host:

```text
/tmp/endoscope_isaac_outputs/endoscope_isaac_vlca/episode_000000/
```

This headless command does not need:

- `xauth list`
- switching X11 cookies
- `isaac-sim.streaming.sh`
- Streaming Client

Use the visual workflow only when you want to inspect the scene interactively.

## Run In Isaac Sim Without Docker

Use Isaac Sim's bundled Python, not system Python.

Linux:

```bash
/path/to/isaac-sim/python.sh isaac_main.py --record --video --output-dir /tmp/endoscope_isaac_vlca
```

Windows:

```powershell
& "C:\path\to\isaac-sim\python.bat" isaac_main.py --record --video --output-dir C:\tmp\endoscope_isaac_vlca
```

Headless is the default. Add `--viewer` if you want the GUI:

```bash
/path/to/isaac-sim/python.sh isaac_main.py --viewer --record --output-dir /tmp/endoscope_isaac_vlca
```

## Main Options

```text
--record                  Write frames, annotations, metadata, VLCA JSON
--video                   Export mp4 videos if imageio is available
--dry-run-no-isaac        Generate the same file structure without Isaac Sim
--max-steps               Minimum simulation steps
--frame-stride            Save one frame every N steps
--drive-speed             Tip drive speed
--solid-clearance         Clearance around solid guide blocks
--contact-correction      Push drive point away from solid guide blocks
--export-vlca / --no-export-vlca
```

## Output Example

```text
outputs/endoscope_isaac_vlca/episode_000000/
  render_frames/
  tip_frames/
  debug_frames/
  frames/
    ev/
    ebv/
  json/
    vlca.json
    yolo_auto_gen.json
  aligned.csv
  annotations.json
  metadata.json
  trajectory.csv
  endoscope_isaac_scene.usd
```

## Current Implementation Notes

The Isaac Sim stage is built with USD primitives and PhysX collision on solid blocks. The exported frame files currently use the deterministic top-down annotation renderer so the VLCA output is stable across machines. The USD stage and moving endoscope visuals are still updated in Isaac Sim during the run.

If you want photorealistic Isaac camera images in `frames/ev` and `frames/ebv`, the next step is to replace the deterministic frame writer in `isaac_main.py` with Isaac Replicator camera capture.
