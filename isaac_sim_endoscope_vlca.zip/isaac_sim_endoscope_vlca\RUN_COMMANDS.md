# Run commands

## Clone

```bash
cd /home/wu/Documents/genesis_projectxizi
git clone https://github.com/asindhx/isaac_sim_try.git
cd /home/wu/Documents/genesis_projectxizi/isaac_sim_try
```

If using the zip package, unzip `isaac_sim_endoscope_vlca.zip` and enter the
extracted folder.

## Capability check

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try/isaac_sim_endoscope_vlca && docker run --rm --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "/isaac-sim/python.sh /workspace/isaac_sim_endoscope_vlca/scripts/check_isaacsim_capabilities.py"
```

Expected ending:

```text
ISAACSIM_CAPABILITY_CHECK_PASSED
```

## Run one Isaac Sim scene

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try/isaac_sim_endoscope_vlca && docker run --rm --gpus all --network=host --entrypoint bash -e ACCEPT_EULA=Y -e PRIVACY_CONSENT=Y -e OMNI_ENV_PRIVACY_CONSENT=Y -v "$PWD:/workspace/isaac_sim_endoscope_vlca" nvcr.io/nvidia/isaac-sim:5.1.0 -lc "/isaac-sim/python.sh /workspace/isaac_sim_endoscope_vlca/isaacsim_main.py --headless --output-dir /workspace/isaac_sim_endoscope_vlca/outputs/endoscope_single_latest"
```

## Check output format

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try/isaac_sim_endoscope_vlca && python scripts/check_output_format.py
```

## Convert EBV frames to GIF

```bash
cd /home/wu/Documents/isaac-sim_xizi/isaac_sim_try/isaac_sim_endoscope_vlca && python -c "from pathlib import Path; from PIL import Image; d=Path('outputs/endoscope_single_latest/cam_ebv'); frames=sorted(d.glob('*.jpg'))+sorted(d.glob('*.png')); print('frames',len(frames)); assert frames, 'no EBV frames found'; imgs=[Image.open(p).convert('RGB').resize((640,424)) for p in frames]; out=Path('outputs/endoscope_single_latest/preview_ebv.gif'); imgs[0].save(out,save_all=True,append_images=imgs[1:],duration=300,loop=0,optimize=True); print('saved',out)"
```
