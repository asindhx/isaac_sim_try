import json
from dataclasses import dataclass
from pathlib import Path
from typing import Literal


ShapeName = Literal["circle", "square", "rectangle", "pentagon"]
GuideKind = Literal["solid", "insertable"]
EndoscopeMaterial = Literal["metal", "rubber"]
GUIDE_BLOCK_COLOR = (0.20, 0.36, 0.58, 1.0)


@dataclass(frozen=True)
class GuideBlock:
    name: str
    kind: GuideKind
    shape: ShapeName
    position: tuple[float, float]
    size: float
    height: float
    color: tuple[float, float, float, float]
    size_x: float | None = None
    size_y: float | None = None


@dataclass(frozen=True)
class ClampBlock:
    name: str
    position: tuple[float, float]
    size: tuple[float, float]
    height: float
    color: tuple[float, float, float, float]


@dataclass(frozen=True)
class Target:
    name: str
    shape: ShapeName
    position: tuple[float, float]
    size: float
    height: float
    color: tuple[float, float, float, float]
    active: bool = False


@dataclass(frozen=True)
class EndoscopeSection:
    name: str
    material: EndoscopeMaterial
    length: float
    radius: float
    segment_count: int
    color: tuple[float, float, float, float]
    bend_compliance: float


@dataclass(frozen=True)
class EndoscopeConfig:
    base_position: tuple[float, float, float] = (-1.54, 0.0, 0.08)
    sections: tuple[EndoscopeSection, ...] = (
        EndoscopeSection("lens_metal_tip", "metal", 0.09, 0.036, 1, (0.72, 0.75, 0.78, 1.0), 0.05),
        EndoscopeSection("front_rubber_bend", "rubber", 0.16, 0.034, 4, (0.04, 0.05, 0.055, 1.0), 1.0),
        EndoscopeSection("middle_metal_sleeve", "metal", 0.10, 0.035, 1, (0.58, 0.61, 0.64, 1.0), 0.08),
        EndoscopeSection("rear_rubber_tube", "rubber", 6.0, 0.033, 60, (0.02, 0.025, 0.03, 1.0), 0.06),
    )


PLANE_SIZE = (3.2, 2.1)
START_POSITION = (-1.36, 0.0)
ENDOSCOPE = EndoscopeConfig()

TARGET_SIZE = 0.18
TARGET_HEIGHT = 0.055
ACTIVE_TARGET_NAME = "target_main"
TARGETS: tuple[Target, ...] = (
    Target("target_main", "pentagon", (0.78, 0.24), TARGET_SIZE, TARGET_HEIGHT, (0.72, 0.10, 0.82, 1.0), True),
    Target("target_alt", "pentagon", (0.82, -0.24), 0.16, TARGET_HEIGHT, (0.55, 0.20, 0.78, 1.0), False),
)

GUIDE_BLOCKS: tuple[GuideBlock, ...] = (
    GuideBlock("guide_blue_circle_1", "solid", "circle", (-0.82, 0.18), 0.13, 0.075, GUIDE_BLOCK_COLOR),
    GuideBlock("guide_green_square_1", "solid", "square", (-0.48, -0.16), 0.18, 0.09, GUIDE_BLOCK_COLOR),
    GuideBlock("guide_yellow_circle_insertable", "insertable", "rectangle", (-0.12, -0.02), 0.14, 0.07, GUIDE_BLOCK_COLOR, 0.34, 0.16),
    GuideBlock("guide_red_square_2", "solid", "square", (0.24, 0.18), 0.15, 0.085, GUIDE_BLOCK_COLOR),
    GuideBlock("guide_cyan_circle_3", "solid", "circle", (0.46, -0.20), 0.10, 0.065, GUIDE_BLOCK_COLOR),
)

START_CLAMPS: tuple[ClampBlock, ...] = (
    ClampBlock("start_clamp_upper", (-1.48, 0.085), (0.18, 0.055), 0.075, (0.18, 0.18, 0.20, 1.0)),
    ClampBlock("start_clamp_lower", (-1.48, -0.085), (0.18, 0.055), 0.075, (0.18, 0.18, 0.20, 1.0)),
)

USED_GUIDE_BLOCK_NAMES: tuple[str, ...] = (
    "guide_blue_circle_1",
    "guide_yellow_circle_insertable",
)


def guide_block_by_name(name: str) -> GuideBlock:
    for block in GUIDE_BLOCKS:
        if block.name == name:
            return block
    raise ValueError(f"Unknown guide block name: {name}")


def used_guide_blocks() -> tuple[GuideBlock, ...]:
    return tuple(guide_block_by_name(name) for name in USED_GUIDE_BLOCK_NAMES)


def target_by_name(name: str) -> Target:
    for target in TARGETS:
        if target.name == name:
            return target
    raise ValueError(f"Unknown target name: {name}")


def active_target() -> Target:
    return target_by_name(ACTIVE_TARGET_NAME)


def experiment_level_value() -> float:
    value = 0.0
    for block in used_guide_blocks():
        value += 1.0 if block.kind == "solid" else 1.5
    return value


def experiment_level_label() -> str:
    value = experiment_level_value()
    return f"L{int(value)}" if value.is_integer() else f"L{value:g}"


def guide_block_size_xy(block: GuideBlock) -> tuple[float, float]:
    if block.shape == "rectangle":
        return block.size_x or block.size, block.size_y or block.size
    if block.shape == "square":
        return block.size, block.size
    return block.size * 2.0, block.size * 2.0


def _rgba_from_layout(value, default):
    if not value:
        return default
    if isinstance(value, str) and value.startswith("#") and len(value) in (7, 9):
        r = int(value[1:3], 16) / 255.0
        g = int(value[3:5], 16) / 255.0
        b = int(value[5:7], 16) / 255.0
        a = int(value[7:9], 16) / 255.0 if len(value) == 9 else 1.0
        return (r, g, b, a)
    if isinstance(value, (list, tuple)) and len(value) in (3, 4):
        rgba = tuple(float(x) for x in value)
        return rgba if len(rgba) == 4 else (*rgba, 1.0)
    return default


def load_layout(path: str | Path | None = None) -> None:
    global GUIDE_BLOCKS, TARGETS, ACTIVE_TARGET_NAME, USED_GUIDE_BLOCK_NAMES
    layout_path = Path(path) if path else Path(__file__).with_name("layout.json")
    if not layout_path.exists():
        return

    data = json.loads(layout_path.read_text(encoding="utf-8"))
    block_color = _rgba_from_layout(data.get("guide_block_color"), GUIDE_BLOCK_COLOR)

    blocks = []
    for idx, item in enumerate(data.get("guide_blocks", []), start=1):
        shape = item.get("shape", "circle")
        kind = item.get("kind", "solid")
        default_name = f"guide_{idx:02d}_{shape}_{kind}"
        blocks.append(
            GuideBlock(
                name=item.get("name") or default_name,
                kind=kind,
                shape=shape,
                position=(float(item["x"]), float(item["y"])),
                size=float(item.get("size", 0.13)),
                height=float(item.get("height", 0.075)),
                color=_rgba_from_layout(item.get("color"), block_color),
                size_x=float(item["size_x"]) if item.get("size_x") is not None else None,
                size_y=float(item["size_y"]) if item.get("size_y") is not None else None,
            )
        )
    if blocks:
        GUIDE_BLOCKS = tuple(blocks)

    targets = []
    for idx, item in enumerate(data.get("targets", []), start=1):
        default_name = "target_main" if idx == 1 else f"target_{idx}"
        targets.append(
            Target(
                name=item.get("name") or default_name,
                shape="pentagon",
                position=(float(item["x"]), float(item["y"])),
                size=float(item.get("size", TARGET_SIZE)),
                height=float(item.get("height", TARGET_HEIGHT)),
                color=_rgba_from_layout(item.get("color"), (0.72, 0.10, 0.82, 1.0)),
                active=bool(item.get("active", idx == 1)),
            )
        )
    if targets:
        TARGETS = tuple(targets)

    ACTIVE_TARGET_NAME = data.get("active_target_name") or next((t.name for t in TARGETS if t.active), TARGETS[0].name)
    if data.get("used_guide_block_names"):
        USED_GUIDE_BLOCK_NAMES = tuple(str(name) for name in data["used_guide_block_names"])


load_layout()
