from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

import config
from isaac_scene import add_collision, add_material, bind_material, prim_path
from route_planner import solid_block_radius


@dataclass
class SegmentVisual:
    name: str
    prim_path: str
    length: float
    radius: float
    role: str


def horizontal_cylinder_matrix(midpoint: tuple[float, float, float], heading: float):
    from pxr import Gf

    translate = Gf.Matrix4d().SetTranslate(Gf.Vec3d(*midpoint))
    rotate_y = Gf.Matrix4d().SetRotate(Gf.Rotation(Gf.Vec3d(0, 1, 0), 90.0))
    rotate_z = Gf.Matrix4d().SetRotate(Gf.Rotation(Gf.Vec3d(0, 0, 1), math.degrees(heading)))
    return translate * rotate_z * rotate_y


def expand_sections() -> list[tuple[str, float, float, tuple[float, float, float, float], str]]:
    specs = []
    for section in config.ENDOSCOPE.sections:
        length = section.length / max(section.segment_count, 1)
        for idx in range(section.segment_count):
            if section.name == "front_rubber_bend":
                role = "active_bend"
            elif section.material == "metal":
                role = "rigid_front"
            else:
                role = "passive_body"
            specs.append((f"{section.name}_{idx:02d}", length, section.radius, section.color, role))
    return specs


def create_endoscope_visuals(stage, create_prim) -> list[SegmentVisual]:
    visuals = []
    for idx, (name, length, radius, color, role) in enumerate(expand_sections()):
        path = prim_path(f"endoscope_{idx:03d}_{name}")
        prim = create_prim(path, "Cylinder", position=(0.0, 0.0, -5.0), scale=(radius, radius, length * 0.5))
        material = add_material(stage, f"{path}_mat", color)
        bind_material(prim, material)
        add_collision(stage, prim)
        visuals.append(SegmentVisual(name=name, prim_path=path, length=length, radius=radius, role=role))
    return visuals


def resolve_solid_overlap(point: np.ndarray, endoscope_radius: float) -> tuple[np.ndarray, float]:
    corrected = point.astype(np.float32).copy()
    contact = 0.0
    for block in config.GUIDE_BLOCKS:
        if block.kind != "solid":
            continue
        center = np.array(block.position, dtype=np.float32)
        delta = corrected - center
        dist = float(np.linalg.norm(delta))
        min_dist = solid_block_radius(block) + endoscope_radius
        if dist >= min_dist:
            continue
        if dist < 1e-6:
            delta = np.array([1.0, 0.0], dtype=np.float32)
            dist = 1.0
        penetration = min_dist - dist
        corrected = corrected + delta / dist * penetration
        contact += penetration * 12000.0
    return corrected, contact


def append_path_history(history: list[np.ndarray], point: np.ndarray, min_spacing: float) -> None:
    if not history or float(np.linalg.norm(point - history[-1])) >= min_spacing:
        history.append(point.astype(np.float32).copy())


def clamped_tail_anchor() -> np.ndarray:
    return np.array([config.START_CLAMPS[0].position[0], 0.0], dtype=np.float32)


def initial_tail_history(tail_length: float) -> list[np.ndarray]:
    anchor = clamped_tail_anchor()
    return [
        np.array([anchor[0] - max(0.5, tail_length), 0.0], dtype=np.float32),
        np.array([anchor[0] - 0.35, 0.0], dtype=np.float32),
        anchor.copy(),
        np.array(config.START_POSITION, dtype=np.float32),
    ]


def point_back_from_tip(points_tail_to_tip: list[np.ndarray], distance_from_tip: float) -> np.ndarray:
    remaining = float(distance_from_tip)
    cursor = points_tail_to_tip[-1].copy()
    for idx in range(len(points_tail_to_tip) - 1, 0, -1):
        tip_side = points_tail_to_tip[idx]
        tail_side = points_tail_to_tip[idx - 1]
        delta = tail_side - tip_side
        dist = float(np.linalg.norm(delta))
        if dist < 1e-6:
            continue
        if remaining <= dist:
            return (tip_side + delta / dist * remaining).astype(np.float32)
        remaining -= dist
        cursor = tail_side.copy()
    return cursor.astype(np.float32)


def centerline_from_history(history: list[np.ndarray], visible_length: float) -> tuple[list[tuple[float, float]], float]:
    endoscope_radius = max(section.radius for section in config.ENDOSCOPE.sections)
    distances = [0.0]
    total = 0.0
    for _, length, _, _, _ in expand_sections():
        total += length
        if total > visible_length:
            break
        distances.append(total)
    centerline = []
    contact_total = 0.0
    for distance in distances:
        sample = point_back_from_tip(history, distance)
        corrected, contact = resolve_solid_overlap(sample, endoscope_radius)
        centerline.append((float(corrected[0]), float(corrected[1])))
        contact_total += contact
    return centerline, contact_total


def hidden_segments_inside_insertable(centerline: list[tuple[float, float]]) -> set[int]:
    hidden = set()
    if len(centerline) < 2:
        return hidden
    for idx, (a, b) in enumerate(zip(centerline[:-1], centerline[1:])):
        midpoint = (np.array(a) + np.array(b)) * 0.5
        for block in config.GUIDE_BLOCKS:
            if block.kind != "insertable":
                continue
            center = np.array(block.position, dtype=np.float32)
            if block.shape == "circle":
                inside = float(np.linalg.norm(midpoint - center)) <= block.size
            else:
                sx, sy = config.guide_block_size_xy(block)
                rel = np.abs(midpoint - center)
                inside = bool(rel[0] <= sx * 0.5 and rel[1] <= sy * 0.5)
            if inside:
                hidden.add(idx)
                break
    return hidden


def heading_from_centerline(centerline: list[tuple[float, float]], fallback: float = 0.0) -> float:
    if len(centerline) < 2:
        return fallback
    tip = np.array(centerline[0], dtype=np.float32)
    neck = np.array(centerline[1], dtype=np.float32)
    delta = tip - neck
    if float(np.linalg.norm(delta)) < 1e-6:
        return fallback
    return math.atan2(float(delta[1]), float(delta[0]))


def update_visuals(stage, visuals: list[SegmentVisual], centerline: list[tuple[float, float]], hidden: set[int]) -> None:
    from pxr import UsdGeom

    z = config.ENDOSCOPE.base_position[2]
    tip_to_tail = [np.array(point, dtype=np.float32) for point in centerline]
    segment_count = min(len(visuals), len(tip_to_tail) - 1)
    for idx in range(segment_count):
        visual = visuals[idx]
        prim = stage.GetPrimAtPath(visual.prim_path)
        xform = UsdGeom.Xformable(prim)
        xform.ClearXformOpOrder()
        if idx in hidden:
            xform.AddTranslateOp().Set((0.0, 0.0, -5.0))
            continue
        a = tip_to_tail[idx + 1]
        b = tip_to_tail[idx]
        delta = b - a
        length = float(np.linalg.norm(delta))
        if length < 1e-6:
            continue
        midpoint = (a + b) * 0.5
        heading = math.atan2(float(delta[1]), float(delta[0]))
        xform.AddTransformOp().Set(horizontal_cylinder_matrix((float(midpoint[0]), float(midpoint[1]), z), heading))
        xform.AddScaleOp(UsdGeom.XformOp.PrecisionDouble).Set((visual.radius, visual.radius, length * 0.5))

    for visual in visuals[segment_count:]:
        prim = stage.GetPrimAtPath(visual.prim_path)
        xform = UsdGeom.Xformable(prim)
        xform.ClearXformOpOrder()
        xform.AddTranslateOp().Set((0.0, 0.0, -5.0))
