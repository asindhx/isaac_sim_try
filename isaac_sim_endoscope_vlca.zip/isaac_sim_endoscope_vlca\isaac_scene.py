from __future__ import annotations

import math
from pathlib import Path

import numpy as np

import config


def require_isaac():
    try:
        from omni.isaac.core import World
        from omni.isaac.core.objects import DynamicCuboid, FixedCuboid, VisualCuboid
        from omni.isaac.core.utils.prims import create_prim
        from pxr import Gf, UsdGeom, UsdPhysics
    except Exception as exc:
        raise RuntimeError(
            "Isaac Sim Python modules are not available. Run this with Isaac Sim's python.sh/python.bat."
        ) from exc
    return World, DynamicCuboid, FixedCuboid, VisualCuboid, create_prim, Gf, UsdGeom, UsdPhysics


def rgba_to_rgb(color: tuple[float, float, float, float]) -> np.ndarray:
    return np.array(color[:3], dtype=np.float32)


def prim_path(name: str) -> str:
    clean = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in name)
    return f"/World/{clean}"


def add_material(stage, path: str, color: tuple[float, float, float, float]):
    from pxr import Gf, UsdShade

    material = UsdShade.Material.Define(stage, path)
    shader = UsdShade.Shader.Define(stage, f"{path}/Shader")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Gf.Vec3f(*color[:3]))
    shader.CreateInput("opacity", float(color[3]))
    shader.CreateInput("roughness", 0.72)
    material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    return material


def bind_material(prim, material):
    from pxr import UsdShade

    UsdShade.MaterialBindingAPI(prim).Bind(material)


def add_collision(stage, prim):
    from pxr import UsdPhysics

    UsdPhysics.CollisionAPI.Apply(prim)


def make_pentagon_mesh(stage, path: str, radius: float, height: float, color):
    from pxr import Gf, UsdGeom

    mesh = UsdGeom.Mesh.Define(stage, path)
    top_z = height
    points = []
    for z in (0.0, top_z):
        for i in range(5):
            angle = math.pi / 2 + i * 2 * math.pi / 5
            points.append(Gf.Vec3f(math.cos(angle) * radius, math.sin(angle) * radius, z))
    faces = [[0, 1, 2, 3, 4], [9, 8, 7, 6, 5]]
    for i in range(5):
        faces.append([i, (i + 1) % 5, 5 + (i + 1) % 5, 5 + i])
    mesh.CreatePointsAttr(points)
    mesh.CreateFaceVertexCountsAttr([len(face) for face in faces])
    mesh.CreateFaceVertexIndicesAttr([idx for face in faces for idx in face])
    material = add_material(stage, f"{path}_mat", color)
    bind_material(mesh.GetPrim(), material)
    return mesh.GetPrim()


def add_cylinder(stage, create_prim, name: str, xy: tuple[float, float], radius: float, height: float, color, collision: bool):
    path = prim_path(name)
    prim = create_prim(
        prim_path=path,
        prim_type="Cylinder",
        position=(float(xy[0]), float(xy[1]), height * 0.5),
        scale=(radius, radius, height * 0.5),
    )
    material = add_material(stage, f"{path}_mat", color)
    bind_material(prim, material)
    if collision:
        add_collision(stage, prim)
    return prim


def add_box(stage, FixedCuboid, name: str, xy: tuple[float, float], size: tuple[float, float], height: float, color, collision: bool):
    path = prim_path(name)
    obj = FixedCuboid(
        prim_path=path,
        name=name,
        position=np.array([xy[0], xy[1], height * 0.5], dtype=np.float32),
        scale=np.array([size[0], size[1], height], dtype=np.float32),
        color=rgba_to_rgb(color),
    )
    prim = stage.GetPrimAtPath(path)
    if collision:
        add_collision(stage, prim)
    return obj


def add_scene_camera(stage, create_prim, name: str, position, lookat, focal_length=24.0, horizontal_aperture=20.955):
    path = prim_path(name)
    prim = create_prim(path, "Camera", position=position)
    from pxr import Gf, UsdGeom

    camera = UsdGeom.Camera(prim)
    camera.CreateFocalLengthAttr(float(focal_length))
    camera.CreateHorizontalApertureAttr(float(horizontal_aperture))
    set_camera_lookat(prim, position, lookat)
    return prim


def set_camera_lookat(camera_prim, position, lookat):
    from pxr import Gf, UsdGeom

    pos = Gf.Vec3d(*position)
    target = Gf.Vec3d(*lookat)
    direction = target - pos
    up = Gf.Vec3d(0.0, 0.0, 1.0)
    if abs(direction.GetNormalized() * up) > 0.99:
        up = Gf.Vec3d(0.0, 1.0, 0.0)
    view = Gf.Matrix4d().SetLookAt(pos, target, up)
    xform = UsdGeom.Xformable(camera_prim)
    xform.ClearXformOpOrder()
    xform.AddTransformOp().Set(view.GetInverse())


def build_world(args):
    World, DynamicCuboid, FixedCuboid, VisualCuboid, create_prim, Gf, UsdGeom, UsdPhysics = require_isaac()

    world = World(stage_units_in_meters=1.0)
    stage = world.stage
    world.scene.add_default_ground_plane()

    plane_w, plane_h = config.PLANE_SIZE
    add_box(stage, FixedCuboid, "experiment_table", (0.0, 0.0), (plane_w, plane_h), 0.025, (0.82, 0.84, 0.82, 1.0), True)

    for clamp in config.START_CLAMPS:
        add_box(stage, FixedCuboid, clamp.name, clamp.position, clamp.size, clamp.height, clamp.color, True)

    for block in config.GUIDE_BLOCKS:
        collision = block.kind == "solid"
        if block.shape == "circle":
            add_cylinder(stage, create_prim, block.name, block.position, block.size, block.height, block.color, collision)
        else:
            add_box(stage, FixedCuboid, block.name, block.position, config.guide_block_size_xy(block), block.height, block.color, collision)

    for target in config.TARGETS:
        path = prim_path(target.name)
        prim = make_pentagon_mesh(stage, path, target.size, target.height, target.color)
        from pxr import UsdGeom

        xform = UsdGeom.Xformable(prim)
        xform.AddTranslateOp().Set((target.position[0], target.position[1], 0.0))

    top_camera = add_scene_camera(
        stage,
        create_prim,
        "top_down_camera",
        (0.0, 0.0, args.camera_height),
        (0.0, 0.0, 0.0),
        focal_length=max(8.0, 46.0 - args.camera_fov * 0.35),
    )
    tip_camera = add_scene_camera(
        stage,
        create_prim,
        "tip_camera",
        (config.START_POSITION[0] - 0.05, config.START_POSITION[1], args.tip_camera_height),
        (config.START_POSITION[0] + 0.35, config.START_POSITION[1], args.tip_camera_height * 0.72),
        focal_length=max(8.0, 46.0 - args.tip_camera_fov * 0.35),
    )

    return world, stage, top_camera, tip_camera, create_prim


def save_stage(stage, output_dir: Path) -> None:
    usd_path = output_dir / "endoscope_isaac_scene.usd"
    stage.GetRootLayer().Export(str(usd_path))


def capture_viewport_frame(camera_path: str, image_path: Path, updates: int = 4) -> bool:
    try:
        import omni.kit.app
        from omni.kit.viewport.utility import capture_viewport_to_file, get_active_viewport

        viewport = get_active_viewport()
        if viewport is None:
            return False
        viewport.camera_path = camera_path
        image_path.parent.mkdir(parents=True, exist_ok=True)
        capture = capture_viewport_to_file(viewport, str(image_path))
        for _ in range(max(1, updates)):
            omni.kit.app.get_app().update()
        if hasattr(capture, "wait_for_result"):
            capture.wait_for_result()
        for _ in range(max(1, updates)):
            omni.kit.app.get_app().update()
        return image_path.exists() and image_path.stat().st_size > 0
    except Exception as exc:
        print(f"3D viewport capture skipped: {exc!r}")
        return False


def update_tip_camera_pose(stage, camera_path: str, tip_xy, yaw: float, height: float) -> None:
    forward = np.array([math.cos(yaw), math.sin(yaw)], dtype=np.float32)
    pos_xy = np.array(tip_xy, dtype=np.float32) - forward * 0.045
    lookat_xy = np.array(tip_xy, dtype=np.float32) + forward * 0.34
    prim = stage.GetPrimAtPath(camera_path)
    set_camera_lookat(
        prim,
        (float(pos_xy[0]), float(pos_xy[1]), float(height)),
        (float(lookat_xy[0]), float(lookat_xy[1]), float(height * 0.72)),
    )
