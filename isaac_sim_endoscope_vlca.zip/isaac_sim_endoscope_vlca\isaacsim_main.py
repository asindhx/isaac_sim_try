import argparse
import csv
import json
import math
import shutil
import traceback
from datetime import datetime, timezone
from pathlib import Path

from layout_config import BLOCKS, BOARD_SIZE, LEVEL, ROUTE_ORDER, START_POSITION, TARGETS

DATASET_FRAME_NAME = "0001.jpg"
VLCA_PROMPTS = (
    {"name": "block", "color": "#8b5cf6"},
    {"name": "robot tip", "color": "#f59e0b"},
    {"name": "target", "color": "#f59e0b", "subprompts": []},
)
YOLO_PROMPTS = (
    {"name": "block", "color": "#8b5cf6"},
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--output-dir", default="outputs/endoscope_single_latest")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--warmup-frames", type=int, default=30)
    parser.add_argument("--steps", type=int, default=240)
    parser.add_argument("--capture-frames", type=int, default=24)
    parser.add_argument("--no-render", action="store_true")
    return parser.parse_args()


def fail_if_not_isaac_python():
    try:
        import isaacsim  # noqa: F401
    except Exception as exc:
        raise RuntimeError(
            "This script must be run with Isaac Sim python.sh, not normal Python."
        ) from exc


def rgba_to_rgb(color):
    return (float(color[0]), float(color[1]), float(color[2]))


def add_color(prim, color):
    from pxr import Gf, UsdGeom

    UsdGeom.Gprim(prim).CreateDisplayColorAttr([Gf.Vec3f(*rgba_to_rgb(color))])


def set_transform(prim, xyz, scale=None, rotate_z_deg=None):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    if rotate_z_deg is not None:
        xform.AddRotateZOp().Set(float(rotate_z_deg))
    if scale is not None:
        xform.AddScaleOp().Set(Gf.Vec3f(float(scale[0]), float(scale[1]), float(scale[2])))


def add_lights(stage):
    from pxr import Gf, UsdLux

    dome = UsdLux.DomeLight.Define(stage, "/World/Lights/dome")
    dome.CreateIntensityAttr(180.0)
    dome.CreateColorAttr(Gf.Vec3f(1.0, 1.0, 1.0))

    key = UsdLux.DistantLight.Define(stage, "/World/Lights/key")
    key.CreateIntensityAttr(520.0)
    key.CreateAngleAttr(0.35)
    set_transform(key.GetPrim(), (0.0, 0.0, 1.0), rotate_z_deg=0.0)


def update_translate(prim, xyz):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    ops = xform.GetOrderedXformOps()
    translate = None
    for op in ops:
        if op.GetOpType() == UsdGeom.XformOp.TypeTranslate:
            translate = op
            break
    if translate is None:
        translate = xform.AddTranslateOp()
    translate.Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))


def update_pose_xy(prim, xyz, yaw_rad):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    xform.AddRotateZOp().Set(math.degrees(float(yaw_rad)))


def add_static_box(stage, path, position, size, height, color):
    from pxr import UsdGeom, UsdPhysics

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, (position[0], position[1], height / 2.0), (size[0], size[1], height))
    add_color(prim, color)
    UsdPhysics.CollisionAPI.Apply(prim)
    return prim


def add_static_sphere(stage, path, position, radius, color):
    from pxr import UsdGeom

    sphere = UsdGeom.Sphere.Define(stage, path)
    prim = sphere.GetPrim()
    sphere.CreateRadiusAttr(float(radius))
    set_transform(prim, position)
    add_color(prim, color)
    return prim


def add_static_cylinder(stage, path, position, radius, height, color):
    from pxr import UsdGeom, UsdPhysics

    cyl = UsdGeom.Cylinder.Define(stage, path)
    prim = cyl.GetPrim()
    cyl.CreateRadiusAttr(float(radius))
    cyl.CreateHeightAttr(float(height))
    cyl.CreateAxisAttr("Z")
    set_transform(prim, (position[0], position[1], height / 2.0))
    add_color(prim, color)
    UsdPhysics.CollisionAPI.Apply(prim)
    return prim


def add_insertable_block(stage, path, block):
    # Covered tunnel. The endoscope enters from the left, so the pass-through
    # channel runs along X. The cover hides the slot in the top-view render.
    x, y = block.position
    sx, sy = block.size
    color = (0.05, 0.24, 0.52, 1.0)
    channel = 0.060
    wall_h_y = max((sy - channel) / 2.0, 0.012)
    cover_h = 0.026
    wall_z = max(block.height - cover_h, 0.035)
    add_static_box(stage, f"{path}/upper_wall", (x, y + sy / 2 - wall_h_y / 2), (sx, wall_h_y), wall_z, color)
    add_static_box(stage, f"{path}/lower_wall", (x, y - sy / 2 + wall_h_y / 2), (sx, wall_h_y), wall_z, color)
    cover = add_static_box(stage, f"{path}/top_cover", (x, y), (sx, sy), cover_h, color)
    set_transform(cover, (x, y, wall_z + cover_h / 2.0), (sx, sy, cover_h))
    return {"channel_width": channel, "channel_axis": "x", "covered": True}


def add_pentagon_target(stage, path, target, dot_side_angle=math.pi):
    from pxr import Gf, UsdGeom, UsdPhysics, Vt

    radius = target.size[0] / 2.0
    height = target.height
    verts = []
    for z in (0.0, height):
        for i in range(5):
            a = math.pi / 2.0 + i * 2.0 * math.pi / 5.0
            verts.append((target.position[0] + radius * math.cos(a), target.position[1] + radius * math.sin(a), z))
    faces = [
        (0, 1, 2, 3, 4),
        (9, 8, 7, 6, 5),
        (0, 5, 6, 1),
        (1, 6, 7, 2),
        (2, 7, 8, 3),
        (3, 8, 9, 4),
        (4, 9, 5, 0),
    ]
    mesh = UsdGeom.Mesh.Define(stage, path)
    prim = mesh.GetPrim()
    mesh.CreatePointsAttr(Vt.Vec3fArray([Gf.Vec3f(*p) for p in verts]))
    mesh.CreateFaceVertexCountsAttr([len(f) for f in faces])
    mesh.CreateFaceVertexIndicesAttr([idx for face in faces for idx in face])
    add_color(prim, (0.72, 0.10, 0.82, 1.0))
    UsdPhysics.CollisionAPI.Apply(prim)

    dot_pos = (
        target.position[0] + radius * 0.95 * math.cos(dot_side_angle),
        target.position[1] + radius * 0.95 * math.sin(dot_side_angle),
    )
    add_static_cylinder(stage, f"{path}_entry_port_marker", dot_pos, 0.018, height + 0.006, (0.02, 0.02, 0.02, 1.0))
    return prim


def add_capsule_segment(stage, path, center, length, radius, color, kinematic=False, mass_value=0.02):
    from pxr import UsdGeom, UsdPhysics

    cyl = UsdGeom.Capsule.Define(stage, path)
    prim = cyl.GetPrim()
    cyl.CreateRadiusAttr(float(radius))
    cyl.CreateHeightAttr(float(length))
    cyl.CreateAxisAttr("X")
    set_transform(prim, center)
    add_color(prim, color)
    UsdPhysics.CollisionAPI.Apply(prim)
    rigid = UsdPhysics.RigidBodyAPI.Apply(prim)
    if kinematic:
        rigid.CreateKinematicEnabledAttr(True)
    mass = UsdPhysics.MassAPI.Apply(prim)
    mass.CreateMassAttr(float(mass_value))
    return prim


def add_revolute_joint(stage, path, body0, body1, local_x0, local_x1, lower, upper, drive_target=0.0, stiffness=0.0):
    from pxr import Gf, Sdf, UsdPhysics

    joint = UsdPhysics.RevoluteJoint.Define(stage, path)
    prim = joint.GetPrim()
    joint.CreateBody0Rel().SetTargets([Sdf.Path(body0)])
    joint.CreateBody1Rel().SetTargets([Sdf.Path(body1)])
    joint.CreateAxisAttr("Z")
    joint.CreateLocalPos0Attr(Gf.Vec3f(float(local_x0), 0.0, 0.0))
    joint.CreateLocalPos1Attr(Gf.Vec3f(float(local_x1), 0.0, 0.0))
    joint.CreateLowerLimitAttr(float(lower))
    joint.CreateUpperLimitAttr(float(upper))
    if stiffness > 0.0:
        drive = UsdPhysics.DriveAPI.Apply(prim, "angular")
        drive.CreateTypeAttr("force")
        drive.CreateTargetPositionAttr(float(drive_target))
        drive.CreateTargetVelocityAttr(0.0)
        drive.CreateStiffnessAttr(float(stiffness))
        drive.CreateDampingAttr(float(stiffness) * 0.08)
        drive.CreateMaxForceAttr(50.0)
    return prim


def set_joint_drive_target(joint_prim, target_degrees):
    from pxr import UsdPhysics

    drive = UsdPhysics.DriveAPI.Apply(joint_prim, "angular")
    attr = drive.GetTargetPositionAttr()
    if not attr:
        attr = drive.CreateTargetPositionAttr(float(target_degrees))
    attr.Set(float(target_degrees))


def add_endoscope_articulation(stage):
    from pxr import Sdf, UsdGeom, UsdPhysics

    root = UsdGeom.Xform.Define(stage, "/World/endoscope").GetPrim()
    UsdPhysics.ArticulationRootAPI.Apply(root)
    # PhysX model: only the tail pusher is kinematic. The remaining bodies are
    # dynamic rigid capsules constrained by joints, so blocks and clamps can
    # actually contact and deflect the chain.
    segment_paths = []
    segment_prims = []
    segment_specs = [
        ("tail_pusher", 0.58, (0.025, 0.027, 0.025, 1.0), True, 0.16),
        ("passive_hard_tube", 0.24, (0.025, 0.027, 0.025, 1.0), False, 0.08),
        ("rear_metal", 0.070, (0.66, 0.69, 0.72, 1.0), False, 0.035),
        ("active_bend", 0.080, (0.025, 0.027, 0.025, 1.0), False, 0.025),
        ("front_metal", 0.080, (0.76, 0.79, 0.82, 1.0), False, 0.035),
    ]
    x = START_POSITION[0] - 0.52
    z = 0.070
    for idx, (name, length, color, kinematic, mass_value) in enumerate(segment_specs):
        path = f"/World/endoscope/seg_{idx:02d}"
        prim = add_capsule_segment(
            stage,
            path,
            (x + length / 2.0, START_POSITION[1], z),
            length,
            0.018,
            color,
            kinematic,
            mass_value=mass_value,
        )
        prim.CreateAttribute("vlca:segmentName", Sdf.ValueTypeNames.String).Set(name)
        segment_paths.append(path)
        segment_prims.append(prim)
        x += length

    joints = []
    for idx in range(len(segment_paths) - 1):
        l0 = segment_specs[idx][1]
        l1 = segment_specs[idx + 1][1]
        if idx == 0:
            lower, upper, target, stiffness = -2.0, 2.0, 0.0, 1200.0
        elif idx == 1:
            lower, upper, target, stiffness = -4.0, 4.0, 0.0, 1200.0
        elif idx == 2:
            lower, upper, target, stiffness = -90.0, 90.0, -30.0, 160.0
        else:
            lower, upper, target, stiffness = -5.0, 5.0, 0.0, 900.0
        joint = add_revolute_joint(
            stage,
            f"/World/endoscope/joint_{idx:02d}",
            segment_paths[idx],
            segment_paths[idx + 1],
            l0 / 2.0,
            -l1 / 2.0,
            lower,
            upper,
            drive_target=target,
            stiffness=stiffness,
        )
        joints.append(joint)

    return segment_prims, segment_paths, segment_specs, joints


def active_bend_target_degrees(progress):
    if progress < 0.18:
        return 0.0
    if progress < 0.42:
        return -22.0
    if progress < 0.72:
        return -46.0
    return -30.0


def drive_endoscope_base(app, segment_prims, segment_specs, joint_prims, steps, warmup_frames, capture_callback=None, capture_frames=1):
    import omni.timeline

    timeline = omni.timeline.get_timeline_interface()
    timeline.play()
    for _ in range(max(0, warmup_frames)):
        app.update()

    steps = max(1, steps)
    wanted = max(1, int(capture_frames))
    if wanted == 1:
        capture_steps = {steps - 1: 1}
    else:
        capture_steps = {
            int(round(i * (steps - 1) / (wanted - 1))): i + 1
            for i in range(wanted)
        }
    render_status = {}
    tail_start_x = START_POSITION[0] - 0.52 + segment_specs[0][1] / 2.0
    tail_drive_distance = 0.70
    tail_z = 0.070
    active_joint = joint_prims[2] if len(joint_prims) > 2 else None
    for frame in range(steps):
        progress = frame / max(steps - 1, 1)
        update_pose_xy(segment_prims[0], (tail_start_x + progress * tail_drive_distance, START_POSITION[1], tail_z), 0.0)
        if active_joint is not None:
            set_joint_drive_target(active_joint, active_bend_target_degrees(progress))
        for _ in range(3):
            app.update()
        if capture_callback is not None and frame in capture_steps:
            render_status[capture_steps[frame]] = capture_callback(capture_steps[frame])
    timeline.stop()
    return render_status


def clamp01(value):
    return max(0.0, min(1.0, float(value)))


def now_iso_z():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def norm_point_from_world(position):
    board_w, board_h = BOARD_SIZE
    x = (float(position[0]) + board_w / 2.0) / board_w
    y = (board_h / 2.0 - float(position[1])) / board_h
    return round(clamp01(x), 6), round(clamp01(y), 6)


def norm_bbox_from_world(position, size):
    cx, cy = norm_point_from_world(position)
    w = float(size[0]) / BOARD_SIZE[0]
    h = float(size[1]) / BOARD_SIZE[1]
    x = clamp01(cx - w / 2.0)
    y = clamp01(cy - h / 2.0)
    w = min(w, 1.0 - x)
    h = min(h, 1.0 - y)
    return {
        "x": round(x, 6),
        "y": round(y, 6),
        "w": round(w, 6),
        "h": round(h, 6),
    }


def make_box_label(spec, block_id=None):
    bbox = norm_bbox_from_world(spec.position, spec.size)
    label = {
        **bbox,
        "promptIndex": 0,
        "prompt": "block",
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "block",
        "sourceName": spec.name,
        "kind": spec.kind,
        "shape": spec.shape,
    }
    if block_id is not None:
        label["blockId"] = block_id
    return label


def make_tip_label():
    x, y = norm_point_from_world(START_POSITION)
    return {
        "x": x,
        "y": y,
        "w": 0,
        "h": 0,
        "isPoint": True,
        "promptIndex": 1,
        "prompt": "robot tip",
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "robot tip",
    }


def make_target_label(target):
    bbox = norm_bbox_from_world(target.position, target.size)
    return {
        **bbox,
        "promptIndex": 2,
        "prompt": "target",
        "subprompt": None,
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "target",
        "sourceName": target.name,
        "shape": target.shape,
    }


def compact_box(label):
    return {key: label[key] for key in ("x", "y", "w", "h")}


def make_real_dataset_format(output_root):
    # Match the lab dataset layout:
    # cam_ebv/*.jpg, cam_ev/*.jpg, json/vlca.json, json/yolo_auto_gen.json, data.csv.
    (output_root / "cam_ebv").mkdir(parents=True, exist_ok=True)
    (output_root / "cam_ev").mkdir(parents=True, exist_ok=True)
    json_dir = output_root / "json"
    json_dir.mkdir(parents=True, exist_ok=True)

    block_labels = [make_box_label(block, f"B{idx + 1}") for idx, block in enumerate(BLOCKS)]
    inactive_target_as_blocks = [
        make_box_label(target, f"T{idx + 1}")
        for idx, target in enumerate(TARGETS)
        if not target.active
    ]
    active_targets = [target for target in TARGETS if target.active]
    target_labels = [make_target_label(target) for target in active_targets]

    frame_names = [path.name for path in sorted((output_root / "cam_ebv").glob("*.jpg"))] or [DATASET_FRAME_NAME]
    vlca_labels = {
        frame_name: block_labels + inactive_target_as_blocks + [make_tip_label()] + target_labels
        for frame_name in frame_names
    }
    yolo_frame_labels = [
        compact_box(label) | {
            "promptIndex": 0,
            "prompt": "block",
            "confidence": 1.0,
            "auto_labeled": True,
            "displayName": "block",
            "sourceName": label["sourceName"],
        }
        for label in block_labels + inactive_target_as_blocks
    ]
    yolo_labels = {
        frame_name: yolo_frame_labels
        for frame_name in frame_names
    }
    vlca = {
        "version": "2.0",
        "format": "normalised",
        "exportDate": now_iso_z(),
        "coordSystem": "normalised_0_1_topleft",
        "prompts": list(VLCA_PROMPTS),
        "labels": vlca_labels,
    }
    yolo = {
        "version": "2.0",
        "format": "normalised",
        "exportDate": now_iso_z(),
        "coordSystem": "normalised_0_1_topleft",
        "prompts": list(YOLO_PROMPTS),
        "labels": yolo_labels,
    }
    (json_dir / "vlca.json").write_text(json.dumps(vlca, indent=2), encoding="utf-8")
    (json_dir / "yolo_auto_gen.json").write_text(json.dumps(yolo, indent=2), encoding="utf-8")

    tip_box = {
        "x": make_tip_label()["x"],
        "y": make_tip_label()["y"],
        "w": 0,
        "h": 0,
        "isPoint": True,
    }
    waypoint = active_targets[0].position if active_targets else START_POSITION
    csv_columns = [
        "frame_id",
        "t_mono",
        "joy_ud",
        "joy_lr",
        "m1_spd",
        "m2_spd",
        "m3_spd",
        "m4_spd",
        "m1_pos",
        "m2_pos",
        "m3_pos",
        "m4_pos",
        "pwm_duty",
        "em_valid",
        "em_x",
        "em_y",
        "em_z",
        "em_qw",
        "em_qx",
        "em_qy",
        "em_qz",
        "ebv_block_boxes_json",
        "ebv_tip_box_json",
        "ev_block_boxes_json",
        "guiding_block_id",
        "waypoint_x",
        "waypoint_y",
    ]
    base_row = {
        "joy_ud": 0,
        "joy_lr": 0,
        "m1_spd": 0,
        "m2_spd": 0,
        "m3_spd": 0,
        "m4_spd": 0,
        "m1_pos": 0,
        "m2_pos": 0,
        "m3_pos": 0,
        "m4_pos": 0,
        "pwm_duty": 0,
        "em_valid": 0,
        "em_x": "",
        "em_y": "",
        "em_z": "",
        "em_qw": "",
        "em_qx": "",
        "em_qy": "",
        "em_qz": "",
        "ebv_block_boxes_json": json.dumps([compact_box(label) for label in block_labels], separators=(",", ":")),
        "ebv_tip_box_json": json.dumps(tip_box, separators=(",", ":")),
        "ev_block_boxes_json": "[]",
        "guiding_block_id": ROUTE_ORDER[0] if ROUTE_ORDER else "",
        "waypoint_x": waypoint[0],
        "waypoint_y": waypoint[1],
    }
    with (output_root / "data.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=csv_columns)
        writer.writeheader()
        for idx, _frame_name in enumerate(frame_names, start=1):
            writer.writerow({"frame_id": idx, "t_mono": round((idx - 1) / 30.0, 6), **base_row})


def convert_first_rgb_to_jpg(source_dir, target_file):
    candidates = sorted(source_dir.rglob("*.png")) + sorted(source_dir.rglob("*.jpg")) + sorted(source_dir.rglob("*.jpeg"))
    if not candidates:
        return False
    target_file.parent.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image

        Image.open(candidates[0]).convert("RGB").save(target_file, quality=92)
    except Exception:
        shutil.copyfile(candidates[0], target_file)
    return True


def image_is_black(pixels):
    import numpy as np

    rgb = pixels[:, :, :3].astype(np.float32)
    return float(np.mean(rgb)) < 2.0 or float(np.std(rgb)) < 0.25


def render_camera_frame(camera_path, output_dir, final_jpg, retries=6):
    render_product = None
    annotator = None
    try:
        import omni.replicator.core as rep
        import numpy as np
        from PIL import Image

        output_dir.mkdir(parents=True, exist_ok=True)
        render_product = rep.create.render_product(camera_path, (1280, 840))
        annotator = rep.AnnotatorRegistry.get_annotator("rgb")
        annotator.attach([render_product])
        pixels = None
        last_shape = None
        for _ in range(max(1, retries)):
            rep.orchestrator.step()
            rep.orchestrator.wait_until_complete()
            candidate = np.asarray(annotator.get_data())
            last_shape = candidate.shape
            if candidate.ndim == 3 and candidate.shape[0] > 0 and candidate.shape[1] > 0 and not image_is_black(candidate):
                pixels = candidate
                break
        if pixels is None:
            raise RuntimeError(f"RGB annotator returned no non-black image; last_shape={last_shape}")
        Image.fromarray(pixels[:, :, :3].astype(np.uint8), mode="RGB").save(final_jpg, quality=92)
        return final_jpg.exists() and final_jpg.stat().st_size > 0
    except Exception as exc:
        (output_dir / "render_error.txt").write_text(f"{type(exc).__name__}: {exc}\n", encoding="utf-8")
        return False
    finally:
        if annotator is not None:
            try:
                annotator.detach([render_product])
            except Exception:
                pass
        if render_product is not None:
            try:
                import omni.replicator.core as rep

                rep.destroy.render_product(render_product)
            except Exception:
                pass


def render_dataset_frame_pair(output_root, frame_index):
    frame_name = f"{frame_index:04d}.jpg"
    ebv_ok = render_camera_frame("/World/Cameras/ebv", output_root / "cam_ebv", output_root / "cam_ebv" / frame_name)
    ev_ok = render_camera_frame("/World/Cameras/ev", output_root / "cam_ev", output_root / "cam_ev" / frame_name)
    return {"cam_ebv": ebv_ok, "cam_ev": ev_ok}


def add_cameras(stage):
    from pxr import Gf, UsdGeom

    ebv = UsdGeom.Camera.Define(stage, "/World/Cameras/ebv")
    set_transform(ebv.GetPrim(), (0.0, 0.0, 1.8), rotate_z_deg=0.0)
    ebv.CreateFocalLengthAttr(18.0)
    ebv.CreateClippingRangeAttr(Gf.Vec2f(0.01, 10.0))

    ev = UsdGeom.Camera.Define(stage, "/World/Cameras/ev")
    set_transform(ev.GetPrim(), (START_POSITION[0] + 0.52, START_POSITION[1], 0.11))
    ev.CreateFocalLengthAttr(12.0)
    ev.CreateClippingRangeAttr(Gf.Vec2f(0.01, 5.0))


def make_output_files(output_root, episode_dir, scene_usd, render_status=None):
    for sub in ("frames/ebv", "frames/ev", "render_frames", "tip_frames", "debug_frames"):
        (episode_dir / sub).mkdir(parents=True, exist_ok=True)
    ebv_frames = sorted((output_root / "cam_ebv").glob("*.jpg"))
    ev_frames = sorted((output_root / "cam_ev").glob("*.jpg"))
    for idx, source in enumerate(ebv_frames):
        shutil.copyfile(source, episode_dir / f"frames/ebv/{idx:06d}.jpg")
        shutil.copyfile(source, episode_dir / f"render_frames/{idx:06d}.jpg")
    for idx, source in enumerate(ev_frames):
        shutil.copyfile(source, episode_dir / f"frames/ev/{idx:06d}.jpg")
        shutil.copyfile(source, episode_dir / f"tip_frames/{idx:06d}.jpg")
    if not ebv_frames or not ev_frames:
        raise RuntimeError("No camera frames were rendered into cam_ebv/cam_ev")
    with (episode_dir / "trajectory.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["frame", "tip_x", "tip_y", "tip_z", "target", "phase"])
        writer.writeheader()
        writer.writerow({"frame": 0, "tip_x": START_POSITION[0], "tip_y": START_POSITION[1], "tip_z": 0.065, "target": "target_star", "phase": "scene_created"})
    with (episode_dir / "control_commands.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["frame", "command", "value"])
        writer.writeheader()
        writer.writerow({"frame": 0, "command": "tail_push_physx_joint_drive", "value": 1})
    annotations = {
        "format": "vlca_sim_annotations_v1",
        "source": "isaac_sim",
        "frames": [
            {
                "frame": frame_idx,
                "ebv": f"frames/ebv/{frame_idx:06d}.jpg",
                "ev": f"frames/ev/{frame_idx:06d}.jpg",
                "active_target": "target_star",
                "objects": [
                    {"name": block.name, "type": "block", "kind": block.kind, "shape": block.shape}
                    for block in BLOCKS
                ]
                + [
                    {
                        "name": target.name,
                        "type": "target" if target.active else "block",
                        "shape": target.shape,
                        "active": target.active,
                    }
                    for target in TARGETS
                ],
            }
            for frame_idx in range(min(len(ebv_frames), len(ev_frames)))
        ],
    }
    metadata = {
        "simulator": "Isaac Sim",
        "level": LEVEL,
        "episode": episode_dir.name,
        "route_order": list(ROUTE_ORDER),
        "scene_usd": scene_usd.name,
        "output_format": "genesis_compatible_episode_v1",
        "real_dataset_format_root": str(output_root),
        "render_status": render_status or {},
        "note": "Scene uses Isaac Sim PhysX rigid bodies, revolute joints, joint drives, and static colliders. Only the tail pusher is kinematically inserted; the following sections respond through PhysX joints and contact.",
    }
    (episode_dir / "annotations.json").write_text(json.dumps(annotations, indent=2), encoding="utf-8")
    (episode_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    make_real_dataset_format(output_root)


def prepare_output_root(output_dir):
    output_root = Path(output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    probe = output_root / "run_started.txt"
    probe.write_text("Isaac Sim run started.\n", encoding="utf-8")
    return output_root


def build_scene(args):
    fail_if_not_isaac_python()
    output_root = prepare_output_root(args.output_dir)
    print(f"[isaac-vlca] output root: {output_root}", flush=True)
    progress_file = output_root / "run_progress.txt"

    def checkpoint(message):
        print(f"[isaac-vlca] {message}", flush=True)
        with progress_file.open("a", encoding="utf-8") as stream:
            stream.write(f"{message}\n")

    from isaacsim import SimulationApp

    checkpoint("starting SimulationApp")
    app = None
    try:
        app = SimulationApp({"headless": args.headless})
        checkpoint("SimulationApp ready")
        import omni.usd
        from pxr import PhysxSchema, UsdGeom, UsdPhysics

        checkpoint("creating USD stage")
        ctx = omni.usd.get_context()
        ctx.new_stage()
        app.update()
        stage = ctx.get_stage()
        if stage is None:
            raise RuntimeError("Isaac Sim returned no USD stage after new_stage()")
        UsdGeom.SetStageMetersPerUnit(stage, 1.0)
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)

        checkpoint("creating PhysX scene")
        physics_scene = UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")
        physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scene.GetPrim())
        physx_scene.CreateEnableCCDAttr(True)
        add_lights(stage)

        checkpoint("creating board, clamps, blocks and targets")
        add_static_box(stage, "/World/board", (0.0, 0.0), BOARD_SIZE, 0.035, (0.74, 0.76, 0.70, 1.0))
        add_static_box(stage, "/World/start_clamp_upper", (-0.76, 0.055), (0.12, 0.025), 0.055, (0.12, 0.12, 0.14, 1.0))
        add_static_box(stage, "/World/start_clamp_lower", (-0.76, -0.055), (0.12, 0.025), 0.055, (0.12, 0.12, 0.14, 1.0))

        for block in BLOCKS:
            path = f"/World/blocks/{block.name}"
            if block.kind == "insertable":
                add_insertable_block(stage, path, block)
            elif block.shape == "circle":
                add_static_cylinder(stage, path, block.position, block.radius, block.height, (0.90, 0.18, 0.34, 1.0))
            else:
                add_static_box(stage, path, block.position, block.size, block.height, (0.05, 0.24, 0.52, 1.0))

        for target in TARGETS:
            angle = math.pi if target.active else 0.0
            add_pentagon_target(stage, f"/World/targets/{target.name}", target, dot_side_angle=angle)

        checkpoint("creating PhysX endoscope articulation")
        endoscope_prims, _, endoscope_specs, joint_prims = add_endoscope_articulation(stage)
        checkpoint("creating cameras")
        add_cameras(stage)
        checkpoint("starting headless PhysX stepping")
        render_status = {}
        if args.no_render:
            drive_endoscope_base(app, endoscope_prims, endoscope_specs, joint_prims, args.steps, args.warmup_frames)
        else:
            render_status = drive_endoscope_base(
                app,
                endoscope_prims,
                endoscope_specs,
                joint_prims,
                args.steps,
                args.warmup_frames,
                capture_callback=lambda frame_index: render_dataset_frame_pair(output_root, frame_index),
                capture_frames=args.capture_frames,
            )

        checkpoint("exporting USD and dataset outputs")
        episode_dir = output_root / f"episode_{args.episode_index:06d}"
        episode_dir.mkdir(parents=True, exist_ok=True)
        scene_usd = episode_dir / "scene.usd"
        ok = stage.GetRootLayer().Export(str(scene_usd))
        if not ok:
            raise RuntimeError(f"USD export failed: {scene_usd}")
        if not args.no_render and not all(all(status.values()) for status in render_status.values()):
            raise RuntimeError(f"Camera rendering failed: {render_status}")
        make_output_files(output_root, episode_dir, scene_usd, render_status=render_status)
        (output_root / "run_finished.txt").write_text(f"Saved {scene_usd}\n", encoding="utf-8")
        print(f"[isaac-vlca] scene saved to: {scene_usd}", flush=True)
        print(f"[isaac-vlca] Genesis-compatible output folder: {episode_dir}", flush=True)
        checkpoint("run completed")
    except BaseException:
        (output_root / "fatal_error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        checkpoint("run failed; see fatal_error.txt")
        raise
    finally:
        if app is not None:
            app.close()


def main():
    build_scene(parse_args())


if __name__ == "__main__":
    main()
