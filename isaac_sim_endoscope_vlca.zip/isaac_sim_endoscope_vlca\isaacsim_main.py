import argparse
import csv
import json
import math
import shutil
import traceback
from datetime import datetime, timezone
from pathlib import Path

from layout_config import BLOCKS, BOARD_SIZE, LEVEL, ROUTE_ORDER, ROUTE_WAYPOINT_OVERRIDES, START_POSITION, TARGETS

DATASET_FRAME_NAME = "0001.jpg"
CODE_VERSION = "isaac_physx_l35_clamped_lower_route"
TASK_INSTRUCTION = "Advance through the L-layout and steer the endoscope tip to the target port."
VLCA_PROMPTS = (
    {"name": "block", "color": "#8b5cf6"},
    {"name": "robot tip", "color": "#f59e0b"},
    {"name": "target", "color": "#f59e0b", "subprompts": []},
)
YOLO_PROMPTS = (
    {"name": "block", "color": "#8b5cf6"},
)

BOARD_THICKNESS = 0.035
ENDOSCOPE_RADIUS = 0.018
ENDOSCOPE_Z = BOARD_THICKNESS + ENDOSCOPE_RADIUS + 0.007
MIN_OBSTACLE_HEIGHT = 0.120
HIDDEN_PHYSICS_SEGMENTS = {"active_bend_01", "active_bend_02", "active_bend_03"}


def block_by_name(name):
    for block in BLOCKS:
        if block.name == name:
            return block
    return None


def insertion_exit_x():
    block = block_by_name("guide_left_insertable")
    if block is None:
        return START_POSITION[0] + 0.34
    return block.position[0] + block.size[0] / 2.0 + ENDOSCOPE_RADIUS * 2.0


def route_stage(tip_x):
    if tip_x < insertion_exit_x():
        return "guide_left_insertable"
    for name in ROUTE_ORDER:
        waypoint = ROUTE_WAYPOINT_OVERRIDES.get(name)
        if waypoint and tip_x < waypoint[0]:
            return name
    return ROUTE_ORDER[-1] if ROUTE_ORDER else ""


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--output-dir", default="outputs/endoscope_single_latest")
    parser.add_argument("--episode-index", type=int, default=0)
    parser.add_argument("--warmup-frames", type=int, default=30)
    parser.add_argument("--steps", type=int, default=360)
    parser.add_argument("--capture-frames", type=int, default=120)
    parser.add_argument("--no-render", action="store_true")
    return parser.parse_args()


def fail_if_not_isaac_python():
    try:
        import isaacsim  # noqa: F401
    except Exception as exc:
        raise RuntimeError(
            "This script must be run with Isaac Sim python.sh, not normal Python."
        ) from exc


def rgba_to_rgb(color):
    return (float(color[0]), float(color[1]), float(color[2]))


def add_color(prim, color):
    from pxr import Gf, UsdGeom

    UsdGeom.Gprim(prim).CreateDisplayColorAttr([Gf.Vec3f(*rgba_to_rgb(color))])


def apply_collision(prim, contact_offset=0.012, rest_offset=0.0):
    from pxr import UsdPhysics

    UsdPhysics.CollisionAPI.Apply(prim)
    try:
        from pxr import PhysxSchema

        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(prim)
        physx_collision.CreateContactOffsetAttr(float(contact_offset))
        physx_collision.CreateRestOffsetAttr(float(rest_offset))
    except Exception:
        pass


def set_api_attr(api, name, value):
    creator = getattr(api, f"Create{name}Attr", None)
    if creator is None:
        return False
    try:
        creator(value)
        return True
    except Exception:
        return False


def tune_physx_rigid_body(prim):
    try:
        from pxr import PhysxSchema

        api = PhysxSchema.PhysxRigidBodyAPI.Apply(prim)
        set_api_attr(api, "EnableCCD", True)
        set_api_attr(api, "DisableGravity", True)
        set_api_attr(api, "SleepThreshold", 0.0)
        set_api_attr(api, "StabilizationThreshold", 0.0)
        set_api_attr(api, "SolverPositionIterationCount", 64)
        set_api_attr(api, "SolverVelocityIterationCount", 16)
        set_api_attr(api, "MaxDepenetrationVelocity", 3.0)
        set_api_attr(api, "RetainAccelerations", True)
    except Exception:
        pass


def wake_rigid_body(prim):
    try:
        import omni.physx

        path = prim.GetPath().pathString if hasattr(prim, "GetPath") else str(prim)
        interface = omni.physx.get_physx_interface()
        for name in ("wake_up", "wakeUp", "wake_up_rigid_body", "wakeUpRigidBody"):
            func = getattr(interface, name, None)
            if func is None:
                continue
            try:
                func(path)
                return True
            except TypeError:
                try:
                    func(prim)
                    return True
                except Exception:
                    pass
            except Exception:
                pass
    except Exception:
        pass
    return False


def wake_endoscope_chain(segment_prims):
    woke_any = False
    for prim in segment_prims:
        woke_any = wake_rigid_body(prim) or woke_any
    return woke_any


def tune_joint_constraint(joint_prim):
    try:
        from pxr import UsdPhysics

        joint = UsdPhysics.Joint(joint_prim)
        joint.CreateCollisionEnabledAttr(False)
        joint.CreateBreakForceAttr(1.0e9)
        joint.CreateBreakTorqueAttr(1.0e9)
    except Exception:
        pass


def get_world_translation(prim):
    from pxr import Usd, UsdGeom

    matrix = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    t = matrix.ExtractTranslation()
    return (float(t[0]), float(t[1]), float(t[2]))


def get_world_point(prim, local_xyz):
    from pxr import Gf, Usd, UsdGeom

    matrix = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    point = matrix.Transform(Gf.Vec3d(float(local_xyz[0]), float(local_xyz[1]), float(local_xyz[2])))
    return (float(point[0]), float(point[1]), float(point[2]))


def true_front_tip_position(segment_prims, segment_specs):
    front_length = float(segment_specs[-1][1])
    return get_world_point(segment_prims[-1], (front_length / 2.0, 0.0, 0.0))


def point_distance(a, b):
    return math.sqrt(sum((float(a[i]) - float(b[i])) ** 2 for i in range(3)))


def segment_endpoint_state(segment_prims, segment_specs):
    endpoints = []
    for idx, (prim, spec) in enumerate(zip(segment_prims, segment_specs)):
        name, length = spec[0], float(spec[1])
        rear = get_world_point(prim, (-length / 2.0, 0.0, 0.0))
        front = get_world_point(prim, (length / 2.0, 0.0, 0.0))
        endpoints.append({
            "index": idx,
            "name": name,
            "rear": [float(v) for v in rear],
            "front": [float(v) for v in front],
        })
    gaps = []
    for idx in range(len(endpoints) - 1):
        gap = point_distance(endpoints[idx]["front"], endpoints[idx + 1]["rear"])
        gaps.append({
            "joint": f"{endpoints[idx]['name']}->{endpoints[idx + 1]['name']}",
            "distance_m": float(gap),
        })
    return {
        "endpoints": endpoints,
        "joint_gaps": gaps,
        "max_joint_gap_m": max((gap["distance_m"] for gap in gaps), default=0.0),
    }


def collect_segment_world_matrices(segment_prims):
    from pxr import Usd, UsdGeom

    time = Usd.TimeCode.Default()
    matrices = []
    for prim in segment_prims:
        matrix = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(time)
        matrices.append([[float(matrix[row][col]) for col in range(4)] for row in range(4)])
    return matrices


def apply_segment_world_matrices(segment_prims, matrices):
    from pxr import Gf, Sdf, UsdGeom

    for prim, rows in zip(segment_prims, matrices):
        # This is only used after the PhysX motion pass has finished. Disable
        # dynamic rigid-body ownership before authoring recorded poses for
        # rendering, otherwise PhysX/Fabric can keep displaying the initial pose.
        attr = prim.GetAttribute("physics:rigidBodyEnabled")
        if not attr:
            attr = prim.CreateAttribute("physics:rigidBodyEnabled", Sdf.ValueTypeNames.Bool)
        attr.Set(False)
        matrix = Gf.Matrix4d(1.0)
        for row_idx, row in enumerate(rows):
            matrix.SetRow(row_idx, Gf.Vec4d(float(row[0]), float(row[1]), float(row[2]), float(row[3])))
        xform = UsdGeom.Xformable(prim)
        xform.ClearXformOpOrder()
        xform.AddTransformOp().Set(matrix)


def add_or_update_world_visual_capsule(stage, path, start, end, radius, color, overlap=0.010):
    from pxr import UsdGeom

    sx, sy, sz = (float(start[0]), float(start[1]), float(start[2]))
    ex, ey, ez = (float(end[0]), float(end[1]), float(end[2]))
    dx, dy, dz = ex - sx, ey - sy, ez - sz
    dist_xy = math.hypot(dx, dy)
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1.0e-5:
        return None
    capsule = UsdGeom.Capsule.Define(stage, path)
    prim = capsule.GetPrim()
    capsule.CreateRadiusAttr(float(radius))
    capsule.CreateHeightAttr(float(dist + overlap * 2.0))
    capsule.CreateAxisAttr("X")
    yaw = math.degrees(math.atan2(dy, dx)) if dist_xy > 1.0e-6 else 0.0
    center = ((sx + ex) / 2.0, (sy + ey) / 2.0, (sz + ez) / 2.0)
    set_transform(prim, center, rotate_z_deg=yaw)
    add_color(prim, color)
    return prim


def update_continuous_endoscope_skin(stage, segment_prims, segment_specs):
    from pxr import UsdGeom

    UsdGeom.Xform.Define(stage, "/World/endoscope_visual_skin")
    endpoint_state = segment_endpoint_state(segment_prims, segment_specs)
    endpoints = endpoint_state["endpoints"]
    for idx, endpoint in enumerate(endpoints):
        if endpoint["name"] not in HIDDEN_PHYSICS_SEGMENTS:
            continue
        add_or_update_world_visual_capsule(
            stage,
            f"/World/endoscope_visual_skin/body_{idx:02d}",
            endpoint["rear"],
            endpoint["front"],
            ENDOSCOPE_RADIUS * 0.92,
            segment_specs[idx][2],
            overlap=0.0,
        )
    for idx in range(len(endpoints) - 1):
        left_hidden = endpoints[idx]["name"] in HIDDEN_PHYSICS_SEGMENTS
        right_hidden = endpoints[idx + 1]["name"] in HIDDEN_PHYSICS_SEGMENTS
        if not (left_hidden or right_hidden):
            continue
        a = endpoints[idx]["front"]
        b = endpoints[idx + 1]["rear"]
        color0 = segment_specs[idx][2]
        color1 = segment_specs[idx + 1][2]
        # Only cover seams that touch the hidden active-bending links. Covering
        # every fixed joint creates the visible knots/clutter at the straight
        # passive tube, even though PhysX itself is still connected correctly.
        color = color0 if left_hidden else color1
        add_or_update_world_visual_capsule(
            stage,
            f"/World/endoscope_visual_skin/connector_{idx:02d}",
            a,
            b,
            ENDOSCOPE_RADIUS * 0.88,
            color,
            overlap=ENDOSCOPE_RADIUS * 0.04,
        )
    return endpoint_state


def set_transform(prim, xyz, scale=None, rotate_z_deg=None):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    if rotate_z_deg is not None:
        xform.AddRotateZOp().Set(float(rotate_z_deg))
    if scale is not None:
        xform.AddScaleOp().Set(Gf.Vec3f(float(scale[0]), float(scale[1]), float(scale[2])))


def set_camera_transform(prim, xyz, rotate_xyz_deg):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    xform.AddRotateXYZOp().Set(
        Gf.Vec3f(float(rotate_xyz_deg[0]), float(rotate_xyz_deg[1]), float(rotate_xyz_deg[2]))
    )


def add_lights(stage):
    from pxr import Gf, UsdLux

    dome = UsdLux.DomeLight.Define(stage, "/World/Lights/dome")
    dome.CreateIntensityAttr(180.0)
    dome.CreateColorAttr(Gf.Vec3f(1.0, 1.0, 1.0))

    key = UsdLux.DistantLight.Define(stage, "/World/Lights/key")
    key.CreateIntensityAttr(520.0)
    key.CreateAngleAttr(0.35)
    set_transform(key.GetPrim(), (0.0, 0.0, 1.0), rotate_z_deg=0.0)


def update_translate(prim, xyz):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    ops = xform.GetOrderedXformOps()
    translate = None
    for op in ops:
        if op.GetOpType() == UsdGeom.XformOp.TypeTranslate:
            translate = op
            break
    if translate is None:
        translate = xform.AddTranslateOp()
    translate.Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))


def update_pose_xy(prim, xyz, yaw_rad):
    from pxr import Gf, UsdGeom

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()
    xform.AddTranslateOp().Set(Gf.Vec3d(float(xyz[0]), float(xyz[1]), float(xyz[2])))
    xform.AddRotateZOp().Set(math.degrees(float(yaw_rad)))


def add_static_box(stage, path, position, size, height, color):
    from pxr import UsdGeom

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, (position[0], position[1], height / 2.0), (size[0], size[1], height))
    add_color(prim, color)
    apply_collision(prim, contact_offset=0.018)
    return prim


def add_visual_box(stage, path, position, size, height, color):
    from pxr import UsdGeom

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, (position[0], position[1], height / 2.0), (size[0], size[1], height))
    add_color(prim, color)
    return prim


def add_static_sphere(stage, path, position, radius, color):
    from pxr import UsdGeom

    sphere = UsdGeom.Sphere.Define(stage, path)
    prim = sphere.GetPrim()
    sphere.CreateRadiusAttr(float(radius))
    set_transform(prim, position)
    add_color(prim, color)
    return prim


def add_static_cylinder(stage, path, position, radius, height, color):
    from pxr import UsdGeom

    cyl = UsdGeom.Cylinder.Define(stage, path)
    prim = cyl.GetPrim()
    cyl.CreateRadiusAttr(float(radius))
    cyl.CreateHeightAttr(float(height))
    cyl.CreateAxisAttr("Z")
    set_transform(prim, (position[0], position[1], height / 2.0))
    add_color(prim, color)
    apply_collision(prim, contact_offset=0.020)
    return prim


def add_insertable_block(stage, path, block):
    # Covered tunnel. The endoscope enters from the left, so the pass-through
    # channel runs along X. The cover hides the slot in the top-view render.
    x, y = block.position
    sx, sy = block.size
    color = (0.05, 0.24, 0.52, 1.0)
    block_h = max(block.height, MIN_OBSTACLE_HEIGHT)
    channel = max(0.090, ENDOSCOPE_RADIUS * 2.8)
    channel_center_y = START_POSITION[1]
    y_min = y - sy / 2.0
    y_max = y + sy / 2.0
    channel_min = max(y_min, channel_center_y - channel / 2.0)
    channel_max = min(y_max, channel_center_y + channel / 2.0)
    cover_h = 0.026
    wall_z = max(block_h - cover_h, BOARD_THICKNESS)
    lower_h_y = max(channel_min - y_min, 0.0)
    upper_h_y = max(y_max - channel_max, 0.0)
    if upper_h_y > 0.005:
        add_static_box(stage, f"{path}/upper_wall", (x, channel_max + upper_h_y / 2.0), (sx, upper_h_y), wall_z, color)
    if lower_h_y > 0.005:
        add_static_box(stage, f"{path}/lower_wall", (x, y_min + lower_h_y / 2.0), (sx, lower_h_y), wall_z, color)
    cover = add_visual_box(stage, f"{path}/top_cover", (x, y), (sx, sy), cover_h, color)
    set_transform(cover, (x, y, wall_z + cover_h / 2.0), (sx, sy, cover_h))
    visual_lid = add_visual_box(stage, f"{path}/visual_lid", (x, y), (sx, sy), 0.006, (0.03, 0.18, 0.42, 1.0))
    set_transform(visual_lid, (x, y, block_h + 0.004), (sx, sy, 0.006))
    return {"channel_width": channel, "channel_axis": "x", "channel_center_y": channel_center_y, "covered": True}


def add_pentagon_target(stage, path, target, dot_side_angle=math.pi):
    from pxr import Gf, UsdGeom, UsdPhysics, Vt

    radius = target.size[0] / 2.0
    height = target.height
    verts = []
    for z in (0.0, height):
        for i in range(5):
            a = math.pi / 2.0 + i * 2.0 * math.pi / 5.0
            verts.append((target.position[0] + radius * math.cos(a), target.position[1] + radius * math.sin(a), z))
    faces = [
        (0, 1, 2, 3, 4),
        (9, 8, 7, 6, 5),
        (0, 5, 6, 1),
        (1, 6, 7, 2),
        (2, 7, 8, 3),
        (3, 8, 9, 4),
        (4, 9, 5, 0),
    ]
    mesh = UsdGeom.Mesh.Define(stage, path)
    prim = mesh.GetPrim()
    mesh.CreatePointsAttr(Vt.Vec3fArray([Gf.Vec3f(*p) for p in verts]))
    mesh.CreateFaceVertexCountsAttr([len(f) for f in faces])
    mesh.CreateFaceVertexIndicesAttr([idx for face in faces for idx in face])
    add_color(prim, (0.72, 0.10, 0.82, 1.0))
    apply_collision(prim)

    dot_pos = (
        target.position[0] + radius * 0.95 * math.cos(dot_side_angle),
        target.position[1] + radius * 0.95 * math.sin(dot_side_angle),
    )
    add_static_cylinder(stage, f"{path}_entry_port_marker", dot_pos, 0.018, height + 0.006, (0.02, 0.02, 0.02, 1.0))
    return prim


def add_capsule_segment(stage, path, center, length, radius, color, kinematic=False, mass_value=0.02):
    from pxr import UsdGeom, UsdPhysics

    cyl = UsdGeom.Capsule.Define(stage, path)
    prim = cyl.GetPrim()
    cyl.CreateRadiusAttr(float(radius))
    cyl.CreateHeightAttr(float(length))
    cyl.CreateAxisAttr("X")
    set_transform(prim, center)
    add_color(prim, color)
    apply_collision(prim, contact_offset=0.006)
    rigid = UsdPhysics.RigidBodyAPI.Apply(prim)
    if kinematic:
        rigid.CreateKinematicEnabledAttr(True)
    tune_physx_rigid_body(prim)
    mass = UsdPhysics.MassAPI.Apply(prim)
    mass.CreateMassAttr(float(mass_value))
    return prim


def add_visual_capsule(stage, path, local_center, length, radius, color):
    from pxr import UsdGeom

    capsule = UsdGeom.Capsule.Define(stage, path)
    prim = capsule.GetPrim()
    capsule.CreateRadiusAttr(float(radius))
    capsule.CreateHeightAttr(float(length))
    capsule.CreateAxisAttr("X")
    set_transform(prim, local_center)
    add_color(prim, color)
    return prim


def add_visual_joint_fill(stage, path, local_center, radius, color):
    from pxr import UsdGeom

    sphere = UsdGeom.Sphere.Define(stage, path)
    prim = sphere.GetPrim()
    sphere.CreateRadiusAttr(float(radius))
    set_transform(prim, local_center)
    add_color(prim, color)
    return prim


def add_visual_joint_sleeve(stage, path, local_center, length, radius, color):
    # Pure visual overlap at a joint. Do not apply collision or rigid body APIs.
    return add_visual_capsule(stage, path, local_center, length, radius, color)


def add_kinematic_anchor(stage, path, position):
    from pxr import Gf, Sdf, UsdGeom, UsdPhysics

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, position, (0.01, 0.01, 0.01))
    UsdPhysics.CollisionAPI.Apply(prim)
    rigid = UsdPhysics.RigidBodyAPI.Apply(prim)
    rigid.CreateKinematicEnabledAttr(True)
    UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(1.0)
    prim.CreateAttribute("visibility", Sdf.ValueTypeNames.Token).Set("invisible")
    return prim


def add_dynamic_anchor(stage, path, position, mass_value=0.08):
    from pxr import Sdf, UsdGeom, UsdPhysics

    cube = UsdGeom.Cube.Define(stage, path)
    prim = cube.GetPrim()
    cube.CreateSizeAttr(1.0)
    set_transform(prim, position, (0.012, 0.012, 0.012))
    UsdPhysics.CollisionAPI.Apply(prim)
    UsdPhysics.RigidBodyAPI.Apply(prim)
    UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(float(mass_value))
    tune_physx_rigid_body(prim)
    prim.CreateAttribute("visibility", Sdf.ValueTypeNames.Token).Set("invisible")
    return prim


def add_revolute_joint(stage, path, body0, body1, local_x0, local_x1, lower, upper, drive_target=0.0, stiffness=0.0, max_force=80.0):
    from pxr import Gf, Sdf, UsdPhysics

    joint = UsdPhysics.RevoluteJoint.Define(stage, path)
    prim = joint.GetPrim()
    joint.CreateBody0Rel().SetTargets([Sdf.Path(body0)])
    joint.CreateBody1Rel().SetTargets([Sdf.Path(body1)])
    joint.CreateAxisAttr("Z")
    joint.CreateLocalPos0Attr(Gf.Vec3f(float(local_x0), 0.0, 0.0))
    joint.CreateLocalPos1Attr(Gf.Vec3f(float(local_x1), 0.0, 0.0))
    joint.CreateLowerLimitAttr(float(lower))
    joint.CreateUpperLimitAttr(float(upper))
    if stiffness > 0.0:
        drive = UsdPhysics.DriveAPI.Apply(prim, "angular")
        drive.CreateTypeAttr("force")
        drive.CreateTargetPositionAttr(float(drive_target))
        drive.CreateTargetVelocityAttr(0.0)
        drive.CreateStiffnessAttr(float(stiffness))
        drive.CreateDampingAttr(max(1200.0, float(stiffness) * 0.06))
        drive.CreateMaxForceAttr(float(max_force))
    tune_joint_constraint(prim)
    return prim


def set_joint_drive_target(joint_prim, target_degrees):
    from pxr import UsdPhysics

    drive = UsdPhysics.DriveAPI.Apply(joint_prim, "angular")
    attr = drive.GetTargetPositionAttr()
    if not attr:
        attr = drive.CreateTargetPositionAttr(float(target_degrees))
    attr.Set(float(target_degrees))


def add_fixed_joint(stage, path, body0, body1, local_x0, local_x1):
    from pxr import Gf, Sdf, UsdPhysics

    joint = UsdPhysics.FixedJoint.Define(stage, path)
    joint.CreateBody0Rel().SetTargets([Sdf.Path(body0)])
    joint.CreateBody1Rel().SetTargets([Sdf.Path(body1)])
    joint.CreateLocalPos0Attr(Gf.Vec3f(float(local_x0), 0.0, 0.0))
    joint.CreateLocalPos1Attr(Gf.Vec3f(float(local_x1), 0.0, 0.0))
    prim = joint.GetPrim()
    tune_joint_constraint(prim)
    return prim


def add_prismatic_drive_joint(stage, path, body0, body1, local_x0, local_x1, lower, upper, stiffness=14000.0, damping=1800.0, max_force=9000.0, axis="X"):
    from pxr import Gf, Sdf, UsdPhysics

    joint = UsdPhysics.PrismaticJoint.Define(stage, path)
    prim = joint.GetPrim()
    joint.CreateBody0Rel().SetTargets([Sdf.Path(body0)])
    joint.CreateBody1Rel().SetTargets([Sdf.Path(body1)])
    joint.CreateAxisAttr(str(axis))
    joint.CreateLocalPos0Attr(Gf.Vec3f(float(local_x0), 0.0, 0.0))
    joint.CreateLocalPos1Attr(Gf.Vec3f(float(local_x1), 0.0, 0.0))
    joint.CreateLowerLimitAttr(float(lower))
    joint.CreateUpperLimitAttr(float(upper))
    drive = UsdPhysics.DriveAPI.Apply(prim, "linear")
    drive.CreateTypeAttr("force")
    drive.CreateTargetPositionAttr(0.0)
    drive.CreateTargetVelocityAttr(0.0)
    drive.CreateStiffnessAttr(float(stiffness))
    drive.CreateDampingAttr(float(damping))
    drive.CreateMaxForceAttr(float(max_force))
    tune_joint_constraint(prim)
    return prim


def set_linear_drive_target(joint_prim, target_meters):
    from pxr import UsdPhysics

    drive = UsdPhysics.DriveAPI.Apply(joint_prim, "linear")
    attr = drive.GetTargetPositionAttr()
    if not attr:
        attr = drive.CreateTargetPositionAttr(float(target_meters))
    attr.Set(float(target_meters))


def disable_chain_self_collision(stage, segment_paths):
    from pxr import Sdf, UsdPhysics

    paths = [Sdf.Path(path) for path in segment_paths]
    for i, path_a in enumerate(paths):
        prim_a = stage.GetPrimAtPath(path_a)
        if not prim_a:
            continue
        filtered = UsdPhysics.FilteredPairsAPI.Apply(prim_a)
        rel = filtered.CreateFilteredPairsRel()
        for path_b in paths[i + 1 :]:
            rel.AddTarget(path_b)


def add_endoscope_articulation(stage):
    from pxr import Sdf, UsdGeom, UsdPhysics

    root = UsdGeom.Xform.Define(stage, "/World/endoscope").GetPrim()
    # Use plain PhysX rigid bodies and joints, not an ArticulationRoot. This
    # chain is anchored to the world by a prismatic insertion joint, which is
    # more reliable as maximal-coordinate PhysX joints than as an articulation
    # rooted on a non-rigid parent Xform.
    segment_paths = []
    segment_prims = []
    # Tuple fields are (name, capsule_length_m, display_color_rgba, mass_kg).
    # The PhysX collision radius is not stored here; every segment uses
    # ENDOSCOPE_RADIUS below. Keep this explicit so the mass values are not
    # mistaken for oversized collision radii when reviewing diffs.
    segment_specs = [
        ("tail_pusher", 0.58, (0.025, 0.027, 0.025, 1.0), 0.26),
        ("passive_hard_tube", 0.34, (0.025, 0.027, 0.025, 1.0), 0.22),
        ("rear_metal_locked", 0.065, (0.78, 0.80, 0.82, 1.0), 0.055),
        ("active_bend_01", 0.038, (0.025, 0.027, 0.025, 1.0), 0.040),
        ("active_bend_02", 0.038, (0.025, 0.027, 0.025, 1.0), 0.040),
        ("active_bend_03", 0.038, (0.025, 0.027, 0.025, 1.0), 0.040),
        ("front_metal_tip", 0.075, (0.84, 0.86, 0.88, 1.0), 0.060),
    ]
    # Place the visible tip at the entrance initially, then push from the tail.
    # This must match drive_endoscope_base(); otherwise frame 1 teleports the
    # tube and PhysX has to recover from an impossible configuration.
    total_len = sum(spec[1] for spec in segment_specs)
    x = START_POSITION[0] - total_len
    z = ENDOSCOPE_Z
    for idx, (name, length, color, mass_kg) in enumerate(segment_specs):
        path = f"/World/endoscope/seg_{idx:02d}"
        prim = add_capsule_segment(
            stage,
            path,
            (x + length / 2.0, START_POSITION[1], z),
            length,
            ENDOSCOPE_RADIUS,
            color,
            kinematic=False,
            mass_value=mass_kg,
        )
        prim.CreateAttribute("vlca:segmentName", Sdf.ValueTypeNames.String).Set(name)
        if name in HIDDEN_PHYSICS_SEGMENTS:
            UsdGeom.Imageable(prim).CreateVisibilityAttr().Set("invisible")
        segment_paths.append(path)
        segment_prims.append(prim)
        x += length

    update_continuous_endoscope_skin(stage, segment_prims, segment_specs)

    disable_chain_self_collision(stage, segment_paths)

    fixed_joints = []
    # The passive tube and rear metal are locked together. The short black
    # active section is split into three driven joints so steering is a smooth
    # curve instead of one sharp elbow between two hard tubes.
    for idx in (0, 1, 5):
        l0 = segment_specs[idx][1]
        l1 = segment_specs[idx + 1][1]
        fixed_joints.append(
            add_fixed_joint(
                stage,
                f"/World/endoscope/fixed_joint_{idx:02d}",
                segment_paths[idx],
                segment_paths[idx + 1],
                l0 / 2.0,
                -l1 / 2.0,
            )
        )

    active_joints = []
    for idx in (2, 3, 4):
        l0 = segment_specs[idx][1]
        l1 = segment_specs[idx + 1][1]
        active_joints.append(add_revolute_joint(
            stage,
            f"/World/endoscope/joint_{idx:02d}",
            segment_paths[idx],
            segment_paths[idx + 1],
            l0 / 2.0,
            -l1 / 2.0,
            -34.0,
            34.0,
            drive_target=0.0,
            stiffness=24000.0,
            max_force=1800.0,
        ))

    anchor_position = (START_POSITION[0] - total_len + segment_specs[0][1] / 2.0, START_POSITION[1], z)
    anchor_prim = add_kinematic_anchor(stage, "/World/endoscope/insertion_anchor", anchor_position)
    carriage_prim = add_dynamic_anchor(stage, "/World/endoscope/lateral_carriage", anchor_position, mass_value=0.09)
    disable_chain_self_collision(stage, segment_paths + [carriage_prim.GetPath().pathString])
    lateral_joint = add_prismatic_drive_joint(
        stage,
        "/World/endoscope/lateral_compliance",
        anchor_prim.GetPath().pathString,
        carriage_prim.GetPath().pathString,
        0.0,
        0.0,
        -0.028,
        0.028,
        stiffness=5200.0,
        damping=1550.0,
        max_force=1200.0,
        axis="Y",
    )
    insertion_joint = add_prismatic_drive_joint(
        stage,
        "/World/endoscope/insertion_drive",
        carriage_prim.GetPath().pathString,
        segment_paths[0],
        0.0,
        0.0,
        0.0,
        1.22,
        stiffness=12500.0,
        damping=1700.0,
        max_force=8200.0,
        axis="X",
    )

    joints = {
        "fixed": fixed_joints,
        "active": active_joints,
        "insertion": insertion_joint,
        "lateral": lateral_joint,
        "carriage": carriage_prim,
    }
    return segment_prims, segment_paths, segment_specs, joints


def active_bend_target_degrees(progress, tip_x=None, tip_y=None):
    # The command follows the real tip pose. Keep the tube straight while it is
    # held by the entrance clamp and insertable block, then begin the controlled
    # lower-side turn before touching the pink circle.
    def down_bend(magnitude):
        # Negative Z-drive is the lower-route direction for this chain setup.
        return -float(magnitude)

    def smoothstep(t):
        t = max(0.0, min(1.0, float(t)))
        return t * t * (3.0 - 2.0 * t)

    if tip_x is None:
        if progress < 0.34:
            return 0.0
        if progress < 0.62:
            return down_bend(24.0 * smoothstep((progress - 0.34) / 0.28))
        if progress < 0.82:
            return down_bend(30.0)
        return down_bend(18.0)

    gate_x = insertion_exit_x()
    if tip_x < gate_x + 0.030:
        return 0.0

    circle = block_by_name("guide_pink_circle")
    circle_x = circle.position[0] if circle is not None else gate_x + 0.18
    circle_y = circle.position[1] if circle is not None else -0.03
    circle_radius = circle.radius if circle is not None else 0.075
    lower_edge_y = ROUTE_WAYPOINT_OVERRIDES.get("guide_pink_circle", (circle_x, circle_y - circle_radius))[1]
    # Start after the tip has cleared the insertable channel, and finish the
    # first bend before the lower tangent of the circle. This matches the real
    # handling: do not touch the circle head-on, and do not hook upward.
    ramp_start = gate_x + 0.055
    ramp_end = circle_x - circle_radius * 1.25
    if ramp_end <= ramp_start:
        ramp_end = ramp_start + 0.10

    if tip_x < ramp_start:
        bend = 0.0
    elif tip_x < ramp_end:
        t = (tip_x - ramp_start) / (ramp_end - ramp_start)
        bend = down_bend(26.0 * smoothstep(t))
    elif tip_x < circle_x + circle_radius * 1.20:
        bend = down_bend(31.0)
        if tip_y is not None and tip_y < lower_edge_y - 0.035:
            bend = down_bend(18.0)
    elif tip_x < 0.18:
        bend = down_bend(24.0)
    else:
        bend = down_bend(14.0)

    if tip_y is not None and tip_x > ramp_start:
        # If the tip is still above the requested lower-edge route, steer down
        # harder. If it has gone too low, relax instead of snapping the head.
        if tip_y > lower_edge_y + 0.030:
            bend = min(bend, down_bend(36.0))
        elif tip_y < lower_edge_y - 0.040:
            bend = max(bend, down_bend(10.0))
    return bend


def drive_endoscope_base(app, segment_prims, segment_specs, joint_prims, steps, warmup_frames, capture_callback=None, capture_frames=1):
    import omni.timeline

    gate_exit_x = insertion_exit_x()
    print(
        f"[isaac-vlca] code_version={CODE_VERSION} insertion_exit_x={gate_exit_x:.3f} "
        f"endoscope_collision_radius={ENDOSCOPE_RADIUS:.3f} segment_spec_field4=mass_kg",
        flush=True,
    )

    def sample_state(frame_index, progress, insertion_target, bend_target):
        tail = get_world_translation(segment_prims[0])
        tip_center = get_world_translation(segment_prims[-1])
        tip = true_front_tip_position(segment_prims, segment_specs)
        endpoint_state = segment_endpoint_state(segment_prims, segment_specs)
        return {
            "frame": int(frame_index),
            "progress": float(progress),
            "tail_x": tail[0],
            "tail_y": tail[1],
            "tail_z": tail[2],
            "tip_x": tip[0],
            "tip_y": tip[1],
            "tip_z": tip[2],
            "tip_center_x": tip_center[0],
            "tip_center_y": tip_center[1],
            "tip_center_z": tip_center[2],
            "insertion_exit_x": gate_exit_x,
            "insertion_target": float(insertion_target),
            "bend_target_deg": float(bend_target),
            "segment_endpoints": endpoint_state["endpoints"],
            "joint_gaps": endpoint_state["joint_gaps"],
            "max_joint_gap_m": endpoint_state["max_joint_gap_m"],
            "segment_world_matrices": collect_segment_world_matrices(segment_prims),
        }

    def format_state(label, state):
        return (
            f"[isaac-vlca] {label} "
            f"{state['frame']}: tail=({state['tail_x']:.3f},{state['tail_y']:.3f},{state['tail_z']:.3f}) "
            f"tip=({state['tip_x']:.3f},{state['tip_y']:.3f},{state['tip_z']:.3f}) "
            f"tip_center=({state['tip_center_x']:.3f},{state['tip_center_y']:.3f},{state['tip_center_z']:.3f}) "
            f"insert={state['insertion_target']:.3f} bend={state['bend_target_deg']:.1f} "
            f"max_gap={state['max_joint_gap_m']:.4f} gate_x={gate_exit_x:.3f}"
        )

    timeline = omni.timeline.get_timeline_interface()
    timeline.play()
    for _ in range(max(0, warmup_frames)):
        app.update()

    steps = max(1, steps)
    wanted = max(1, int(capture_frames))
    if wanted == 1:
        capture_steps = {steps - 1: 1}
    else:
        capture_steps = {
            int(round(i * (steps - 1) / (wanted - 1))): i + 1
            for i in range(wanted)
        }
    render_status = {}
    frame_states = []
    tail_drive_distance = 1.22
    active_joints = joint_prims.get("active", []) if isinstance(joint_prims, dict) else []
    insertion_joint = joint_prims.get("insertion") if isinstance(joint_prims, dict) else None
    lateral_joint = joint_prims.get("lateral") if isinstance(joint_prims, dict) else None
    carriage_prim = joint_prims.get("carriage") if isinstance(joint_prims, dict) else None
    active_joint_count = max(1, len(active_joints))
    for frame in range(steps):
        progress = frame / max(steps - 1, 1)
        insertion_target = progress * tail_drive_distance
        if insertion_joint is not None:
            set_linear_drive_target(insertion_joint, insertion_target)
        if lateral_joint is not None:
            set_linear_drive_target(lateral_joint, 0.0)
        tip_pos = true_front_tip_position(segment_prims, segment_specs)
        bend = active_bend_target_degrees(progress, tip_pos[0], tip_pos[1])
        for active_joint in active_joints:
            set_joint_drive_target(active_joint, bend / active_joint_count)
        if frame < 120 or frame % 5 == 0:
            wake_endoscope_chain(segment_prims)
            if carriage_prim is not None:
                wake_rigid_body(carriage_prim)
        for _ in range(4):
            app.update()
        if capture_callback is not None and frame in capture_steps:
            capture_index = capture_steps[frame]
            state = sample_state(capture_index, progress, insertion_target, bend)
            frame_states.append(state)
            print(format_state("capture_pose", state), flush=True)
            # Do not render inside the PhysX stepping loop. Replicator can stall
            # or desynchronize the timeline; we record real PhysX poses here and
            # replay them for image capture after the motion simulation is done.
            render_status[capture_index] = {"cam_ebv": False, "cam_ev": False}
        elif capture_callback is None and frame % max(1, steps // 6) == 0:
            state = sample_state(frame, progress, insertion_target, bend)
            frame_states.append(state)
            print(
                "[isaac-vlca] sim "
                f"{frame}: tail=({state['tail_x']:.3f},{state['tail_y']:.3f},{state['tail_z']:.3f}) "
                f"tip=({state['tip_x']:.3f},{state['tip_y']:.3f},{state['tip_z']:.3f}) "
                f"tip_center=({state['tip_center_x']:.3f},{state['tip_center_y']:.3f},{state['tip_center_z']:.3f}) "
                f"insert={insertion_target:.3f} bend={bend:.1f} "
                f"max_gap={state['max_joint_gap_m']:.4f} gate_x={gate_exit_x:.3f}",
                flush=True,
            )
    timeline.stop()
    if capture_callback is None and not frame_states:
        tip_pos = true_front_tip_position(segment_prims, segment_specs)
        frame_states.append(sample_state(0, 1.0, tail_drive_distance, active_bend_target_degrees(1.0, tip_pos[0], tip_pos[1])))
    return render_status, frame_states


def clamp01(value):
    return max(0.0, min(1.0, float(value)))


def now_iso_z():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def norm_point_from_world(position):
    board_w, board_h = BOARD_SIZE
    x = (float(position[0]) + board_w / 2.0) / board_w
    y = (board_h / 2.0 - float(position[1])) / board_h
    return round(clamp01(x), 6), round(clamp01(y), 6)


def norm_bbox_from_world(position, size):
    cx, cy = norm_point_from_world(position)
    w = float(size[0]) / BOARD_SIZE[0]
    h = float(size[1]) / BOARD_SIZE[1]
    x = clamp01(cx - w / 2.0)
    y = clamp01(cy - h / 2.0)
    w = min(w, 1.0 - x)
    h = min(h, 1.0 - y)
    return {
        "x": round(x, 6),
        "y": round(y, 6),
        "w": round(w, 6),
        "h": round(h, 6),
    }


def make_box_label(spec, block_id=None):
    bbox = norm_bbox_from_world(spec.position, spec.size)
    label = {
        **bbox,
        "promptIndex": 0,
        "prompt": "block",
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "block",
        "sourceName": spec.name,
        "kind": spec.kind,
        "shape": spec.shape,
    }
    if block_id is not None:
        label["blockId"] = block_id
    return label


def make_tip_label(position=None):
    x, y = norm_point_from_world(position or START_POSITION)
    return {
        "x": x,
        "y": y,
        "w": 0,
        "h": 0,
        "isPoint": True,
        "promptIndex": 1,
        "prompt": "robot tip",
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "robot tip",
    }


def make_target_label(target):
    bbox = norm_bbox_from_world(target.position, target.size)
    return {
        **bbox,
        "promptIndex": 2,
        "prompt": "target",
        "subprompt": None,
        "confidence": 1.0,
        "auto_labeled": True,
        "displayName": "target",
        "sourceName": target.name,
        "shape": target.shape,
    }


def compact_box(label):
    return {key: label[key] for key in ("x", "y", "w", "h")}


def make_real_dataset_format(output_root, frame_states=None):
    # Match the lab dataset layout:
    # cam_ebv/*.jpg, cam_ev/*.jpg, json/vlca.json, json/yolo_auto_gen.json, data.csv.
    (output_root / "cam_ebv").mkdir(parents=True, exist_ok=True)
    (output_root / "cam_ev").mkdir(parents=True, exist_ok=True)
    json_dir = output_root / "json"
    json_dir.mkdir(parents=True, exist_ok=True)

    block_labels = [make_box_label(block, f"B{idx + 1}") for idx, block in enumerate(BLOCKS)]
    inactive_target_as_blocks = [
        make_box_label(target, f"T{idx + 1}")
        for idx, target in enumerate(TARGETS)
        if not target.active
    ]
    active_targets = [target for target in TARGETS if target.active]
    target_labels = [make_target_label(target) for target in active_targets]

    frame_names = [path.name for path in sorted((output_root / "cam_ebv").glob("*.jpg"))] or [DATASET_FRAME_NAME]
    frame_states = list(frame_states or [])
    state_by_name = {
        frame_name: frame_states[min(idx, len(frame_states) - 1)]
        for idx, frame_name in enumerate(frame_names)
        if frame_states
    }
    vlca_labels = {
        frame_name: block_labels
        + inactive_target_as_blocks
        + [make_tip_label((state_by_name[frame_name]["tip_x"], state_by_name[frame_name]["tip_y"])) if frame_name in state_by_name else make_tip_label()]
        + target_labels
        for frame_name in frame_names
    }
    yolo_frame_labels = [
        compact_box(label) | {
            "promptIndex": 0,
            "prompt": "block",
            "confidence": 1.0,
            "auto_labeled": True,
            "displayName": "block",
            "sourceName": label["sourceName"],
        }
        for label in block_labels + inactive_target_as_blocks
    ]
    yolo_labels = {
        frame_name: yolo_frame_labels
        for frame_name in frame_names
    }
    vlca = {
        "version": "2.0",
        "format": "normalised",
        "exportDate": now_iso_z(),
        "coordSystem": "normalised_0_1_topleft",
        "prompts": list(VLCA_PROMPTS),
        "labels": vlca_labels,
    }
    yolo = {
        "version": "2.0",
        "format": "normalised",
        "exportDate": now_iso_z(),
        "coordSystem": "normalised_0_1_topleft",
        "prompts": list(YOLO_PROMPTS),
        "labels": yolo_labels,
    }
    (json_dir / "vlca.json").write_text(json.dumps(vlca, indent=2), encoding="utf-8")
    (json_dir / "yolo_auto_gen.json").write_text(json.dumps(yolo, indent=2), encoding="utf-8")

    waypoint = active_targets[0].position if active_targets else START_POSITION
    csv_columns = [
        "frame_id",
        "t_mono",
        "joy_ud",
        "joy_lr",
        "m1_spd",
        "m2_spd",
        "m3_spd",
        "m4_spd",
        "m1_pos",
        "m2_pos",
        "m3_pos",
        "m4_pos",
        "pwm_duty",
        "em_valid",
        "em_x",
        "em_y",
        "em_z",
        "em_qw",
        "em_qx",
        "em_qy",
        "em_qz",
        "ebv_block_boxes_json",
        "ebv_tip_box_json",
        "ev_block_boxes_json",
        "guiding_block_id",
        "waypoint_x",
        "waypoint_y",
        "instruction",
        "route_stage",
        "insertion_target",
        "bend_target_deg",
        "tip_x",
        "tip_y",
        "tail_x",
        "tail_y",
    ]
    base_row = {
        "joy_ud": 0,
        "joy_lr": 0,
        "m1_spd": 0,
        "m2_spd": 0,
        "m3_spd": 0,
        "m4_spd": 0,
        "m1_pos": 0,
        "m2_pos": 0,
        "m3_pos": 0,
        "m4_pos": 0,
        "pwm_duty": 0,
        "em_valid": 0,
        "em_x": "",
        "em_y": "",
        "em_z": "",
        "em_qw": "",
        "em_qx": "",
        "em_qy": "",
        "em_qz": "",
        "ebv_block_boxes_json": json.dumps([compact_box(label) for label in block_labels], separators=(",", ":")),
        "ev_block_boxes_json": "[]",
        "guiding_block_id": ROUTE_ORDER[0] if ROUTE_ORDER else "",
        "waypoint_x": waypoint[0],
        "waypoint_y": waypoint[1],
    }
    with (output_root / "data.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=csv_columns)
        writer.writeheader()
        for idx, _frame_name in enumerate(frame_names, start=1):
            state = state_by_name.get(_frame_name, {})
            tip_label = vlca_labels[_frame_name][len(block_labels + inactive_target_as_blocks)]
            tip_box = {
                "x": tip_label["x"],
                "y": tip_label["y"],
                "w": 0,
                "h": 0,
                "isPoint": True,
            }
            writer.writerow({
                "frame_id": idx,
                "t_mono": round((idx - 1) / 30.0, 6),
                **base_row,
                "ebv_tip_box_json": json.dumps(tip_box, separators=(",", ":")),
                "instruction": TASK_INSTRUCTION,
                "route_stage": route_stage(state.get("tip_x", START_POSITION[0])),
                "insertion_target": state.get("insertion_target", ""),
                "bend_target_deg": state.get("bend_target_deg", ""),
                "tip_x": state.get("tip_x", ""),
                "tip_y": state.get("tip_y", ""),
                "tail_x": state.get("tail_x", ""),
                "tail_y": state.get("tail_y", ""),
            })


def convert_first_rgb_to_jpg(source_dir, target_file):
    candidates = sorted(source_dir.rglob("*.png")) + sorted(source_dir.rglob("*.jpg")) + sorted(source_dir.rglob("*.jpeg"))
    if not candidates:
        return False
    target_file.parent.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image

        Image.open(candidates[0]).convert("RGB").save(target_file, quality=92)
    except Exception:
        shutil.copyfile(candidates[0], target_file)
    return True


def image_is_black(pixels):
    import numpy as np

    rgb = pixels[:, :, :3].astype(np.float32)
    return float(np.mean(rgb)) < 2.0 or float(np.std(rgb)) < 0.25


def configure_fast_replicator_capture():
    try:
        import carb

        settings = carb.settings.get_settings()
        settings.set("/exts/omni.replicator.core/maxAssetLoadingTime", 1.0)
        settings.set("/omni/replicator/RTSubframes", 1)
    except Exception:
        pass


def render_camera_frame(camera_path, output_dir, final_jpg, retries=3):
    render_product = None
    annotator = None
    timeline = None
    was_playing = None
    try:
        import omni.timeline
        import omni.replicator.core as rep
        import numpy as np
        from PIL import Image

        configure_fast_replicator_capture()
        timeline = omni.timeline.get_timeline_interface()
        try:
            was_playing = bool(timeline.is_playing())
        except Exception:
            was_playing = None
        output_dir.mkdir(parents=True, exist_ok=True)
        render_product = rep.create.render_product(camera_path, (1280, 840))
        annotator = rep.AnnotatorRegistry.get_annotator("rgb")
        annotator.attach([render_product])
        pixels = None
        last_shape = None
        for _ in range(max(1, retries)):
            rep.orchestrator.step()
            candidate = np.asarray(annotator.get_data())
            last_shape = candidate.shape
            if candidate.ndim == 3 and candidate.shape[0] > 0 and candidate.shape[1] > 0 and not image_is_black(candidate):
                pixels = candidate
                break
        if pixels is None:
            raise RuntimeError(f"RGB annotator returned no non-black image; last_shape={last_shape}")
        Image.fromarray(pixels[:, :, :3].astype(np.uint8), mode="RGB").save(final_jpg, quality=92)
        return final_jpg.exists() and final_jpg.stat().st_size > 0
    except Exception as exc:
        (output_dir / "render_error.txt").write_text(f"{type(exc).__name__}: {exc}\n", encoding="utf-8")
        return False
    finally:
        if annotator is not None:
            try:
                annotator.detach([render_product])
            except Exception:
                pass
        if render_product is not None:
            try:
                import omni.replicator.core as rep

                rep.destroy.render_product(render_product)
            except Exception:
                pass
        if timeline is not None and was_playing:
            try:
                timeline.play()
            except Exception:
                pass


def render_dataset_frame_pair(output_root, frame_index):
    frame_name = f"{frame_index:04d}.jpg"
    ebv_ok = render_camera_frame("/World/Cameras/ebv", output_root / "cam_ebv", output_root / "cam_ebv" / frame_name)
    ev_ok = render_camera_frame("/World/Cameras/ev", output_root / "cam_ev", output_root / "cam_ev" / frame_name)
    return {"cam_ebv": ebv_ok, "cam_ev": ev_ok}


def render_recorded_frame_pairs(app, output_root, segment_prims, segment_specs, frame_states):
    render_status = {}
    replay_debug = []
    for idx, state in enumerate(frame_states, start=1):
        matrices = state.get("segment_world_matrices")
        before = get_world_translation(segment_prims[-1])
        if matrices:
            apply_segment_world_matrices(segment_prims, matrices)
        if segment_specs:
            update_continuous_endoscope_skin(segment_prims[0].GetStage(), segment_prims, segment_specs)
        for _ in range(2):
            app.update()
        after = get_world_translation(segment_prims[-1])
        replay_endpoints = (
            segment_endpoint_state(segment_prims, segment_specs)
            if segment_specs
            else {"joint_gaps": [], "max_joint_gap_m": None}
        )
        replay_debug.append({
            "frame": idx,
            "recorded_tip": [state.get("tip_x"), state.get("tip_y"), state.get("tip_z")],
            "render_replay_tip_before": list(before),
            "render_replay_tip_after": list(after),
            "recorded_max_joint_gap_m": state.get("max_joint_gap_m"),
            "replay_max_joint_gap_m": replay_endpoints.get("max_joint_gap_m"),
            "recorded_joint_gaps": state.get("joint_gaps", []),
            "replay_joint_gaps": replay_endpoints.get("joint_gaps", []),
        })
        print(
            "[isaac-vlca] render_replay "
            f"{idx}: recorded_tip=({state.get('tip_x'):.3f},{state.get('tip_y'):.3f},{state.get('tip_z'):.3f}) "
            f"after=({after[0]:.3f},{after[1]:.3f},{after[2]:.3f}) "
            f"recorded_gap={state.get('max_joint_gap_m', 0.0):.4f} "
            f"replay_gap={(replay_endpoints.get('max_joint_gap_m') or 0.0):.4f}",
            flush=True,
        )
        render_status[idx] = render_dataset_frame_pair(output_root, idx)
    (output_root / "render_pose_debug.json").write_text(json.dumps(replay_debug, indent=2), encoding="utf-8")
    return render_status


def public_frame_state(state):
    return {key: value for key, value in state.items() if key != "segment_world_matrices"}


def public_frame_states(frame_states):
    return [public_frame_state(state) for state in frame_states]


def add_cameras(stage):
    from pxr import Gf, UsdGeom

    ebv = UsdGeom.Camera.Define(stage, "/World/Cameras/ebv")
    set_camera_transform(ebv.GetPrim(), (0.0, 0.0, 1.8), (0.0, 0.0, 0.0))
    ebv.CreateFocalLengthAttr(18.0)
    ebv.CreateClippingRangeAttr(Gf.Vec2f(0.01, 10.0))

    ev = UsdGeom.Camera.Define(stage, "/World/Cameras/ev")
    set_camera_transform(ev.GetPrim(), (START_POSITION[0] + 0.30, START_POSITION[1], ENDOSCOPE_Z + 0.018), (0.0, -90.0, 0.0))
    ev.CreateFocalLengthAttr(10.0)
    ev.CreateClippingRangeAttr(Gf.Vec2f(0.01, 5.0))


def make_output_files(output_root, episode_dir, scene_usd, render_status=None, frame_states=None):
    for sub in ("frames/ebv", "frames/ev", "render_frames", "tip_frames", "debug_frames"):
        (episode_dir / sub).mkdir(parents=True, exist_ok=True)
    ebv_frames = sorted((output_root / "cam_ebv").glob("*.jpg"))
    ev_frames = sorted((output_root / "cam_ev").glob("*.jpg"))
    frame_states = list(frame_states or [])
    if frame_states and len(frame_states) < len(ebv_frames):
        frame_states.extend([frame_states[-1]] * (len(ebv_frames) - len(frame_states)))
    for idx, source in enumerate(ebv_frames):
        shutil.copyfile(source, episode_dir / f"frames/ebv/{idx:06d}.jpg")
        shutil.copyfile(source, episode_dir / f"render_frames/{idx:06d}.jpg")
    for idx, source in enumerate(ev_frames):
        shutil.copyfile(source, episode_dir / f"frames/ev/{idx:06d}.jpg")
        shutil.copyfile(source, episode_dir / f"tip_frames/{idx:06d}.jpg")
    if not ebv_frames or not ev_frames:
        raise RuntimeError("No camera frames were rendered into cam_ebv/cam_ev")
    with (episode_dir / "trajectory.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "frame",
                "tip_x",
                "tip_y",
                "tip_z",
                "tip_center_x",
                "tip_center_y",
                "tip_center_z",
                "tail_x",
                "tail_y",
                "tail_z",
                "insertion_target",
                "bend_target_deg",
                "instruction",
                "route_stage",
                "target",
                "phase",
            ],
        )
        writer.writeheader()
        if frame_states:
            for idx, state in enumerate(frame_states[: len(ebv_frames)]):
                writer.writerow({
                    "frame": idx,
                    "tip_x": state["tip_x"],
                    "tip_y": state["tip_y"],
                    "tip_z": state["tip_z"],
                    "tip_center_x": state.get("tip_center_x", ""),
                    "tip_center_y": state.get("tip_center_y", ""),
                    "tip_center_z": state.get("tip_center_z", ""),
                    "tail_x": state["tail_x"],
                    "tail_y": state["tail_y"],
                    "tail_z": state["tail_z"],
                    "insertion_target": state["insertion_target"],
                    "bend_target_deg": state["bend_target_deg"],
                    "instruction": TASK_INSTRUCTION,
                    "route_stage": route_stage(state["tip_x"]),
                    "target": "target_star",
                    "phase": "physx_capture",
                })
        else:
            writer.writerow({
                "frame": 0,
                "tip_x": START_POSITION[0],
                "tip_y": START_POSITION[1],
                "tip_z": ENDOSCOPE_Z,
                "tip_center_x": "",
                "tip_center_y": "",
                "tip_center_z": "",
                "tail_x": "",
                "tail_y": "",
                "tail_z": "",
                "insertion_target": "",
                "bend_target_deg": "",
                "instruction": TASK_INSTRUCTION,
                "route_stage": ROUTE_ORDER[0] if ROUTE_ORDER else "",
                "target": "target_star",
                "phase": "no_pose_capture",
            })
    with (episode_dir / "control_commands.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["frame", "insertion_target", "bend_target_deg", "instruction", "route_stage"])
        writer.writeheader()
        for idx, state in enumerate(frame_states[: len(ebv_frames)]):
            writer.writerow({
                "frame": idx,
                "insertion_target": state["insertion_target"],
                "bend_target_deg": state["bend_target_deg"],
                "instruction": TASK_INSTRUCTION,
                "route_stage": route_stage(state["tip_x"]),
            })
    annotations = {
        "format": "vlca_sim_annotations_v1",
        "source": "isaac_sim",
        "frames": [
            {
                "frame": frame_idx,
                "ebv": f"frames/ebv/{frame_idx:06d}.jpg",
                "ev": f"frames/ev/{frame_idx:06d}.jpg",
                "active_target": "target_star",
                "tip_world": {
                    "x": frame_states[frame_idx]["tip_x"],
                    "y": frame_states[frame_idx]["tip_y"],
                    "z": frame_states[frame_idx]["tip_z"],
                } if frame_idx < len(frame_states) else None,
                "tip": make_tip_label(
                    (frame_states[frame_idx]["tip_x"], frame_states[frame_idx]["tip_y"])
                ) if frame_idx < len(frame_states) else make_tip_label(),
                "objects": [
                    {"name": block.name, "type": "block", "kind": block.kind, "shape": block.shape}
                    for block in BLOCKS
                ]
                + [
                    {
                        "name": target.name,
                        "type": "target" if target.active else "block",
                        "shape": target.shape,
                        "active": target.active,
                    }
                    for target in TARGETS
                ],
            }
            for frame_idx in range(min(len(ebv_frames), len(ev_frames)))
        ],
    }
    metadata = {
        "simulator": "Isaac Sim",
        "code_version": CODE_VERSION,
        "level": LEVEL,
        "episode": episode_dir.name,
        "route_order": list(ROUTE_ORDER),
        "route_waypoints": ROUTE_WAYPOINT_OVERRIDES,
        "instruction": TASK_INSTRUCTION,
        "scene_usd": scene_usd.name,
        "output_format": "genesis_compatible_episode_v1",
        "real_dataset_format_root": str(output_root),
        "render_status": render_status or {},
        "pose_capture_count": len(frame_states),
        "endoscope_collision_radius_m": ENDOSCOPE_RADIUS,
        "endoscope_visual_connector_radius_m": ENDOSCOPE_RADIUS * 1.02,
        "endoscope_segment_spec_fields": ["name", "capsule_length_m", "display_color_rgba", "mass_kg"],
        "note": "Scene uses Isaac Sim PhysX rigid bodies, fixed joints, revolute joints, a prismatic insertion drive, and static colliders. The rear tube is locked stiff; only the short front section is actively steerable.",
    }
    (episode_dir / "annotations.json").write_text(json.dumps(annotations, indent=2), encoding="utf-8")
    (episode_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    make_real_dataset_format(output_root, frame_states=frame_states)


def write_smoke_summary(output_root, frame_states, rendered):
    # ponytail: reuse the pose log; a second smoke-test framework adds no value.
    def distance(a, b, prefix):
        return math.sqrt(sum((b[f"{prefix}_{axis}"] - a[f"{prefix}_{axis}"]) ** 2 for axis in "xyz"))

    finite = all(
        math.isfinite(float(state[key]))
        for state in frame_states
        for key in ("tail_x", "tail_y", "tail_z", "tip_x", "tip_y", "tip_z")
    )
    tail_motion = distance(frame_states[0], frame_states[-1], "tail") if len(frame_states) > 1 else 0.0
    tip_motion = distance(frame_states[0], frame_states[-1], "tip") if len(frame_states) > 1 else 0.0
    max_tip_step = max((distance(a, b, "tip") for a, b in zip(frame_states, frame_states[1:])), default=0.0)
    passed = len(frame_states) >= 2 and finite and tail_motion > 0.05 and tip_motion > 0.05 and max_tip_step < 0.50
    summary = {
        "passed": passed,
        "rendered": rendered,
        "samples": len(frame_states),
        "finite_poses": finite,
        "tail_displacement_m": tail_motion,
        "tip_displacement_m": tip_motion,
        "max_sampled_tip_step_m": max_tip_step,
        "criteria": "samples>=2, finite poses, tip/tail displacement>0.05m, sampled tip step<0.50m",
    }
    (output_root / "smoke_test_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"[isaac-vlca] smoke test: {'PASSED' if passed else 'FAILED'} {summary}", flush=True)
    if not passed:
        raise RuntimeError(f"Smoke test failed: {summary}")


def prepare_output_root(output_dir):
    output_root = Path(output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    probe = output_root / "run_started.txt"
    probe.write_text("Isaac Sim run started.\n", encoding="utf-8")
    return output_root


def build_scene(args):
    fail_if_not_isaac_python()
    output_root = prepare_output_root(args.output_dir)
    print(f"[isaac-vlca] output root: {output_root}", flush=True)
    progress_file = output_root / "run_progress.txt"

    def checkpoint(message):
        print(f"[isaac-vlca] {message}", flush=True)
        with progress_file.open("a", encoding="utf-8") as stream:
            stream.write(f"{message}\n")

    from isaacsim import SimulationApp

    checkpoint("starting SimulationApp")
    app = None
    try:
        app = SimulationApp({"headless": args.headless})
        checkpoint("SimulationApp ready")
        import omni.usd
        from pxr import PhysxSchema, UsdGeom, UsdPhysics

        checkpoint("creating USD stage")
        ctx = omni.usd.get_context()
        ctx.new_stage()
        app.update()
        stage = ctx.get_stage()
        if stage is None:
            raise RuntimeError("Isaac Sim returned no USD stage after new_stage()")
        UsdGeom.SetStageMetersPerUnit(stage, 1.0)
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)

        checkpoint("creating PhysX scene")
        physics_scene = UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")
        physics_scene.CreateGravityMagnitudeAttr(0.0)
        physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scene.GetPrim())
        physx_scene.CreateEnableCCDAttr(True)
        set_api_attr(physx_scene, "EnableStabilization", True)
        set_api_attr(physx_scene, "SolverType", "TGS")
        set_api_attr(physx_scene, "TimeStepsPerSecond", 120)
        set_api_attr(physx_scene, "MinPositionIterationCount", 16)
        set_api_attr(physx_scene, "MaxPositionIterationCount", 64)
        set_api_attr(physx_scene, "MinVelocityIterationCount", 4)
        set_api_attr(physx_scene, "MaxVelocityIterationCount", 16)
        add_lights(stage)

        checkpoint("creating board, clamps, blocks and targets")
        add_static_box(stage, "/World/board", (0.0, 0.0), BOARD_SIZE, BOARD_THICKNESS, (0.74, 0.76, 0.70, 1.0))
        add_static_box(stage, "/World/start_clamp_upper", (-0.76, 0.036), (0.15, 0.026), 0.075, (0.12, 0.12, 0.14, 1.0))
        add_static_box(stage, "/World/start_clamp_lower", (-0.76, -0.036), (0.15, 0.026), 0.075, (0.12, 0.12, 0.14, 1.0))

        for block in BLOCKS:
            path = f"/World/blocks/{block.name}"
            height = max(block.height, MIN_OBSTACLE_HEIGHT)
            if block.kind == "insertable":
                add_insertable_block(stage, path, block)
            elif block.shape == "circle":
                add_static_cylinder(stage, path, block.position, block.radius, height, (0.90, 0.18, 0.34, 1.0))
            else:
                add_static_box(stage, path, block.position, block.size, height, (0.05, 0.24, 0.52, 1.0))

        for target in TARGETS:
            angle = math.pi if target.active else 0.0
            add_pentagon_target(stage, f"/World/targets/{target.name}", target, dot_side_angle=angle)

        checkpoint("creating PhysX endoscope rigid-joint chain")
        endoscope_prims, _, endoscope_specs, joint_prims = add_endoscope_articulation(stage)
        checkpoint("creating cameras")
        add_cameras(stage)
        checkpoint("starting headless PhysX stepping")
        render_status = {}
        frame_states = []
        if args.no_render:
            render_status, frame_states = drive_endoscope_base(
                app,
                endoscope_prims,
                endoscope_specs,
                joint_prims,
                args.steps,
                args.warmup_frames,
            )
        else:
            render_status, frame_states = drive_endoscope_base(
                app,
                endoscope_prims,
                endoscope_specs,
                joint_prims,
                args.steps,
                args.warmup_frames,
                capture_callback=lambda frame_index: True,
                capture_frames=args.capture_frames,
            )
            checkpoint("rendering recorded PhysX poses")
            render_status = render_recorded_frame_pairs(app, output_root, endoscope_prims, endoscope_specs, frame_states)

        checkpoint("exporting USD and dataset outputs")
        episode_dir = output_root / f"episode_{args.episode_index:06d}"
        episode_dir.mkdir(parents=True, exist_ok=True)
        scene_usd = episode_dir / "scene.usd"
        ok = stage.GetRootLayer().Export(str(scene_usd))
        if not ok:
            raise RuntimeError(f"USD export failed: {scene_usd}")
        if args.no_render:
            (episode_dir / "pose_debug.json").write_text(json.dumps(public_frame_states(frame_states), indent=2), encoding="utf-8")
        else:
            if not all(all(status.values()) for status in render_status.values()):
                raise RuntimeError(f"Camera rendering failed: {render_status}")
            make_output_files(output_root, episode_dir, scene_usd, render_status=render_status, frame_states=frame_states)
        write_smoke_summary(output_root, frame_states, rendered=not args.no_render)
        (output_root / "run_finished.txt").write_text(f"Saved {scene_usd}\n", encoding="utf-8")
        print(f"[isaac-vlca] scene saved to: {scene_usd}", flush=True)
        print(f"[isaac-vlca] Genesis-compatible output folder: {episode_dir}", flush=True)
        checkpoint("run completed")
    except BaseException:
        (output_root / "fatal_error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        checkpoint("run failed; see fatal_error.txt")
        raise
    finally:
        if app is not None:
            app.close()


def main():
    build_scene(parse_args())


if __name__ == "__main__":
    main()
