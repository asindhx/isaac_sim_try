from dataclasses import dataclass


@dataclass(frozen=True)
class BlockSpec:
    name: str
    kind: str
    shape: str
    position: tuple[float, float]
    size: tuple[float, float]
    height: float = 0.07
    radius: float = 0.08
    active: bool = False


BOARD_SIZE = (1.55, 1.10)
LEVEL = "L3.5"

START_POSITION = (-0.72, 0.0)

BLOCKS = (
    BlockSpec(
        name="guide_left_insertable",
        kind="insertable",
        shape="slot_box",
        position=(-0.47, 0.03),
        size=(0.075, 0.22),
        height=0.075,
    ),
    BlockSpec(
        name="guide_pink_circle",
        kind="solid",
        shape="circle",
        position=(-0.23, -0.03),
        size=(0.15, 0.15),
        radius=0.075,
        height=0.075,
    ),
    BlockSpec(
        name="guide_middle_solid",
        kind="solid",
        shape="rectangle",
        position=(0.02, -0.18),
        size=(0.22, 0.075),
        height=0.075,
    ),
    BlockSpec(
        name="guide_right_solid",
        kind="solid",
        shape="rectangle",
        position=(0.30, 0.02),
        size=(0.08, 0.23),
        height=0.075,
    ),
    BlockSpec(
        name="distractor_bottom_solid",
        kind="distractor",
        shape="rectangle",
        position=(-0.60, -0.36),
        size=(0.20, 0.06),
        height=0.07,
    ),
    BlockSpec(
        name="distractor_top_solid",
        kind="distractor",
        shape="rectangle",
        position=(0.36, 0.40),
        size=(0.18, 0.06),
        height=0.07,
    ),
    BlockSpec(
        name="distractor_right_solid",
        kind="distractor",
        shape="rectangle",
        position=(0.60, 0.12),
        size=(0.07, 0.18),
        height=0.07,
    ),
)

TARGETS = (
    BlockSpec(
        name="target_star",
        kind="target",
        shape="pentagon",
        position=(0.38, -0.22),
        size=(0.14, 0.14),
        height=0.055,
        active=True,
    ),
)

ROUTE_ORDER = (
    "guide_left_insertable",
    "guide_pink_circle",
    "guide_middle_solid",
    "guide_right_solid",
    "target_star",
)

ROUTE_WAYPOINT_OVERRIDES = {
    "guide_pink_circle": (-0.23, -0.105),
    "guide_middle_solid": (0.02, -0.13),
    "guide_right_solid": (0.26, 0.02),
    "target_star": (0.3135, -0.22),
}
