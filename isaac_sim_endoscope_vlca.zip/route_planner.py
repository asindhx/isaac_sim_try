from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

import config


@dataclass(frozen=True)
class RouteTarget:
    name: str
    kind: str
    shape: str
    block_position: tuple[float, float]
    target_position: tuple[float, float]
    reach_mode: str


def solid_block_radius(block: config.GuideBlock) -> float:
    if block.shape == "circle":
        return block.size
    size_x, size_y = config.guide_block_size_xy(block)
    return math.sqrt(size_x * size_x + size_y * size_y) * 0.5


def polyline_length(points: list[tuple[float, float]]) -> float:
    return sum(float(np.linalg.norm(np.array(b) - np.array(a))) for a, b in zip(points[:-1], points[1:]))


def point_on_solid_boundary(previous: np.ndarray, block: config.GuideBlock, clearance: float) -> np.ndarray:
    center = np.array(block.position, dtype=np.float32)
    radius = solid_block_radius(block) + max(section.radius for section in config.ENDOSCOPE.sections) + clearance
    direction = center - previous
    norm = float(np.linalg.norm(direction))
    if norm < 1e-6:
        direction = np.array([1.0, 0.0], dtype=np.float32)
        norm = 1.0
    route_direction = np.array([1.0, 0.0], dtype=np.float32)
    normal = np.array([-route_direction[1], route_direction[0]], dtype=np.float32)
    side = 1.0 if center[1] >= previous[1] else -1.0
    return center + normal * side * radius


def insertable_entry_exit_points(previous: np.ndarray, block: config.GuideBlock, clearance: float) -> list[np.ndarray]:
    center = np.array(block.position, dtype=np.float32)
    size_x, size_y = config.guide_block_size_xy(block)
    endoscope_radius = max(section.radius for section in config.ENDOSCOPE.sections)

    # The insertion face is a long side of the rectangular block. The tube
    # approaches the nearest long side, passes through the hidden block volume,
    # and exits the opposite long side.
    if size_x >= size_y:
        half = size_y * 0.5 + endoscope_radius + clearance
        lower = center + np.array([0.0, -half], dtype=np.float32)
        upper = center + np.array([0.0, half], dtype=np.float32)
        entry, exit_point = (lower, upper) if np.linalg.norm(previous - lower) <= np.linalg.norm(previous - upper) else (upper, lower)
        return [entry, center, exit_point]
    half = size_x * 0.5 + endoscope_radius + clearance
    left = center + np.array([-half, 0.0], dtype=np.float32)
    right = center + np.array([half, 0.0], dtype=np.float32)
    entry, exit_point = (left, right) if np.linalg.norm(previous - left) <= np.linalg.norm(previous - right) else (right, left)
    return [entry, center, exit_point]


def make_route_nodes(clearance: float = 0.10) -> tuple[list[tuple[float, float]], list[RouteTarget]]:
    route_targets: list[RouteTarget] = []
    current = np.array(config.START_POSITION, dtype=np.float32)
    points = [tuple(float(x) for x in current)]
    for block in config.used_guide_blocks():
        if block.kind == "solid":
            point = point_on_solid_boundary(current, block, clearance)
            points.append((float(point[0]), float(point[1])))
            route_targets.append(
                RouteTarget(
                    block.name,
                    block.kind,
                    block.shape,
                    block.position,
                    (float(point[0]), float(point[1])),
                    "graze_boundary",
                )
            )
            current = point
        elif block.kind == "insertable":
            insert_points = insertable_entry_exit_points(current, block, clearance=0.0)
            for point in insert_points:
                points.append((float(point[0]), float(point[1])))
            exit_point = insert_points[-1]
            route_targets.append(
                RouteTarget(
                    block.name,
                    block.kind,
                    block.shape,
                    block.position,
                    (float(exit_point[0]), float(exit_point[1])),
                    "pass_through_exit",
                )
            )
            current = insert_points[-1]
        else:
            raise ValueError(f"Unsupported guide kind: {block.kind}")
    active = config.active_target()
    point = np.array(active.position, dtype=np.float32)
    points.append((float(point[0]), float(point[1])))
    route_targets.append(RouteTarget(active.name, "target", active.shape, active.position, active.position, "reach_center"))
    current = point
    return points, route_targets


def rounded_path(points: list[tuple[float, float]], samples_per_corner: int = 8, corner_cut: float = 0.22) -> list[tuple[float, float]]:
    if len(points) <= 2:
        return points
    result = [points[0]]
    for prev_p, corner_p, next_p in zip(points[:-2], points[1:-1], points[2:]):
        prev_v = np.array(prev_p, dtype=np.float32)
        corner = np.array(corner_p, dtype=np.float32)
        next_v = np.array(next_p, dtype=np.float32)
        in_vec = prev_v - corner
        out_vec = next_v - corner
        in_len = float(np.linalg.norm(in_vec))
        out_len = float(np.linalg.norm(out_vec))
        if in_len < 1e-6 or out_len < 1e-6:
            result.append(corner_p)
            continue
        cut = min(corner_cut, in_len * 0.45, out_len * 0.45)
        p0 = corner + in_vec / in_len * cut
        p2 = corner + out_vec / out_len * cut
        for i in range(samples_per_corner + 1):
            t = i / max(samples_per_corner, 1)
            p = (1 - t) * (1 - t) * p0 + 2 * (1 - t) * t * corner + t * t * p2
            result.append((float(p[0]), float(p[1])))
    result.append(points[-1])
    return result


def position_at_distance(points: list[tuple[float, float]], distance: float, route_targets: list[RouteTarget]) -> tuple[np.ndarray, str]:
    if not points:
        return np.array(config.START_POSITION, dtype=np.float32), ""
    remaining = float(distance)
    for idx, (a, b) in enumerate(zip(points[:-1], points[1:])):
        pa = np.array(a, dtype=np.float32)
        pb = np.array(b, dtype=np.float32)
        seg = pb - pa
        seg_len = float(np.linalg.norm(seg))
        if seg_len < 1e-6:
            continue
        if remaining <= seg_len:
            target_name = route_targets[min(idx, len(route_targets) - 1)].name if route_targets else ""
            return pa + seg / seg_len * remaining, target_name
        remaining -= seg_len
    return np.array(points[-1], dtype=np.float32), route_targets[-1].name if route_targets else ""


def route_target_to_dict(target: RouteTarget) -> dict:
    return {
        "name": target.name,
        "kind": target.kind,
        "shape": target.shape,
        "block_position": [float(target.block_position[0]), float(target.block_position[1])],
        "target_position": [float(target.target_position[0]), float(target.target_position[1])],
        "reach_mode": target.reach_mode,
    }
