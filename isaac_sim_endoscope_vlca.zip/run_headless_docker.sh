#!/usr/bin/env bash
set -euo pipefail

IMAGE="${ISAAC_SIM_IMAGE:-nvcr.io/nvidia/isaac-sim:5.1.0}"
OUTPUT_DIR="${OUTPUT_DIR:-/tmp/endoscope_isaac_outputs}"

mkdir -p "${OUTPUT_DIR}"

docker run --rm -it \
  --gpus all \
  --network host \
  --entrypoint /bin/bash \
  -e ACCEPT_EULA=Y \
  -v "${PWD}":/workspace/isaac_sim_endoscope_vlca \
  -v "${OUTPUT_DIR}":/outputs \
  "${IMAGE}" \
  -lc "cd /isaac-sim && ./python.sh /workspace/isaac_sim_endoscope_vlca/isaac_main.py --record --record-3d --capture-mode replicator --video --output-dir /outputs/endoscope_isaac_vlca"
