#!/usr/bin/env bash
set -u

cd /workspace/isaac_sim_endoscope_vlca || exit 1

rm -rf outputs/batch_l0_l1_training
mkdir -p outputs

echo "[run_l0_l1_batch] running all L0/L1 setups from layouts/l0_l1_training_batch.json"
/isaac-sim/python.sh isaacsim_main.py \
  --headless \
  --batch-json layouts/l0_l1_training_batch.json \
  --output-dir outputs/batch_l0_l1_training \
  --steps "${STEPS:-420}" \
  --capture-frames "${CAPTURE_FRAMES:-120}"
status=$?

chmod -R a+rwX outputs || true

echo "[run_l0_l1_batch] finished with status ${status}"
echo "[run_l0_l1_batch] summary: outputs/batch_l0_l1_training/batch_summary.json"
exit "$status"
