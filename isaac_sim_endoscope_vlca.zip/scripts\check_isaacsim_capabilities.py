import json
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "isaac_capability_check"


def check(name, fn):
    try:
        value = fn()
        print(f"[PASS] {name}: {value}")
        return True, value
    except Exception as exc:
        print(f"[FAIL] {name}: {type(exc).__name__}: {exc}")
        return False, str(exc)


def main():
    results = {}

    ok, value = check("python_version", lambda: sys.version.split()[0])
    results["python_version"] = {"ok": ok, "value": value}

    def import_isaac():
        import isaacsim  # noqa: F401
        return "isaacsim import ok"

    ok, value = check("import_isaacsim", import_isaac)
    results["import_isaacsim"] = {"ok": ok, "value": value}

    def start_app():
        from isaacsim import SimulationApp

        app = SimulationApp({"headless": True})
        return app

    app = None
    try:
        ok, app_or_error = check("start_headless_simulation_app", start_app)
        results["start_headless_simulation_app"] = {"ok": ok, "value": str(app_or_error)}
        if not ok:
            raise RuntimeError("SimulationApp failed")
        app = app_or_error

        def import_usd_physx():
            import omni.usd  # noqa: F401
            from pxr import Gf, PhysxSchema, Usd, UsdGeom, UsdPhysics  # noqa: F401

            return "omni.usd + pxr USD/PhysX modules import ok"

        ok, value = check("import_usd_physx_modules", import_usd_physx)
        results["import_usd_physx_modules"] = {"ok": ok, "value": value}

        def create_stage_and_physics():
            import omni.usd
            from pxr import PhysxSchema, UsdGeom, UsdPhysics

            ctx = omni.usd.get_context()
            ctx.new_stage()
            stage = ctx.get_stage()
            UsdGeom.SetStageMetersPerUnit(stage, 1.0)
            scene = UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")
            PhysxSchema.PhysxSceneAPI.Apply(scene.GetPrim())
            return "stage + physics scene ok"

        ok, value = check("create_stage_and_physics_scene", create_stage_and_physics)
        results["create_stage_and_physics_scene"] = {"ok": ok, "value": value}

        def create_static_collider():
            import omni.usd
            from pxr import Gf, UsdGeom, UsdPhysics

            stage = omni.usd.get_context().get_stage()
            cube = UsdGeom.Cube.Define(stage, "/World/test_static_block")
            cube.CreateSizeAttr(1.0)
            xform = UsdGeom.Xformable(cube.GetPrim())
            xform.AddTranslateOp().Set(Gf.Vec3d(0, 0, 0.05))
            xform.AddScaleOp().Set(Gf.Vec3f(0.1, 0.1, 0.1))
            UsdPhysics.CollisionAPI.Apply(cube.GetPrim())
            return "static collider ok"

        ok, value = check("create_static_collider", create_static_collider)
        results["create_static_collider"] = {"ok": ok, "value": value}

        def create_rigid_body_and_joint():
            import omni.usd
            from pxr import Gf, Sdf, UsdGeom, UsdPhysics

            stage = omni.usd.get_context().get_stage()
            paths = []
            for i, x in enumerate((0.0, 0.12)):
                cap = UsdGeom.Capsule.Define(stage, f"/World/test_endoscope_seg_{i}")
                cap.CreateAxisAttr("X")
                cap.CreateHeightAttr(0.10)
                cap.CreateRadiusAttr(0.015)
                prim = cap.GetPrim()
                xform = UsdGeom.Xformable(prim)
                xform.AddTranslateOp().Set(Gf.Vec3d(x, 0, 0.1))
                UsdPhysics.CollisionAPI.Apply(prim)
                UsdPhysics.RigidBodyAPI.Apply(prim)
                paths.append(f"/World/test_endoscope_seg_{i}")
            joint = UsdPhysics.RevoluteJoint.Define(stage, "/World/test_revolute_joint")
            joint.CreateBody0Rel().SetTargets([Sdf.Path(paths[0])])
            joint.CreateBody1Rel().SetTargets([Sdf.Path(paths[1])])
            joint.CreateAxisAttr("Z")
            joint.CreateLowerLimitAttr(-90.0)
            joint.CreateUpperLimitAttr(90.0)
            return "rigid bodies + revolute joint ok"

        ok, value = check("create_rigid_body_and_joint", create_rigid_body_and_joint)
        results["create_rigid_body_and_joint"] = {"ok": ok, "value": value}

        def prismatic_drive_moves_body():
            import omni.timeline
            import omni.usd
            from pxr import Gf, Sdf, Usd, UsdGeom, UsdPhysics

            ctx = omni.usd.get_context()
            ctx.new_stage()
            stage = ctx.get_stage()
            UsdGeom.SetStageMetersPerUnit(stage, 1.0)
            UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")

            anchor = UsdGeom.Cube.Define(stage, "/World/drive_anchor")
            anchor.CreateSizeAttr(1.0)
            ax = UsdGeom.Xformable(anchor.GetPrim())
            ax.AddTranslateOp().Set(Gf.Vec3d(0.0, 0.0, 0.1))
            ax.AddScaleOp().Set(Gf.Vec3f(0.01, 0.01, 0.01))
            UsdPhysics.CollisionAPI.Apply(anchor.GetPrim())
            ar = UsdPhysics.RigidBodyAPI.Apply(anchor.GetPrim())
            ar.CreateKinematicEnabledAttr(True)

            body = UsdGeom.Capsule.Define(stage, "/World/drive_body")
            body.CreateAxisAttr("X")
            body.CreateHeightAttr(0.10)
            body.CreateRadiusAttr(0.015)
            bx = UsdGeom.Xformable(body.GetPrim())
            bx.AddTranslateOp().Set(Gf.Vec3d(0.0, 0.0, 0.1))
            UsdPhysics.CollisionAPI.Apply(body.GetPrim())
            UsdPhysics.RigidBodyAPI.Apply(body.GetPrim())
            UsdPhysics.MassAPI.Apply(body.GetPrim()).CreateMassAttr(0.03)

            joint = UsdPhysics.PrismaticJoint.Define(stage, "/World/test_prismatic_drive")
            joint.CreateBody0Rel().SetTargets([Sdf.Path("/World/drive_anchor")])
            joint.CreateBody1Rel().SetTargets([Sdf.Path("/World/drive_body")])
            joint.CreateAxisAttr("X")
            joint.CreateLocalPos0Attr(Gf.Vec3f(0.0, 0.0, 0.0))
            joint.CreateLocalPos1Attr(Gf.Vec3f(0.0, 0.0, 0.0))
            joint.CreateLowerLimitAttr(0.0)
            joint.CreateUpperLimitAttr(0.30)
            drive = UsdPhysics.DriveAPI.Apply(joint.GetPrim(), "linear")
            drive.CreateTypeAttr("force")
            drive.CreateTargetPositionAttr(0.20)
            drive.CreateStiffnessAttr(5000.0)
            drive.CreateDampingAttr(500.0)
            drive.CreateMaxForceAttr(1000.0)

            def world_x(prim):
                matrix = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
                return float(matrix.ExtractTranslation()[0])

            start_x = world_x(body.GetPrim())
            timeline = omni.timeline.get_timeline_interface()
            timeline.play()
            for _ in range(90):
                app.update()
            timeline.stop()
            end_x = world_x(body.GetPrim())
            moved = end_x - start_x
            if moved < 0.02:
                raise RuntimeError(f"prismatic body did not move enough: start={start_x:.4f}, end={end_x:.4f}")
            return f"body moved {moved:.4f} m"

        ok, value = check("prismatic_drive_moves_body", prismatic_drive_moves_body)
        results["prismatic_drive_moves_body"] = {"ok": ok, "value": value}

        def step_timeline():
            import omni.timeline

            timeline = omni.timeline.get_timeline_interface()
            timeline.play()
            for _ in range(5):
                app.update()
            timeline.stop()
            return "timeline stepped 5 frames"

        ok, value = check("step_timeline", step_timeline)
        results["step_timeline"] = {"ok": ok, "value": value}

        def create_camera():
            import omni.usd
            from pxr import Gf, UsdGeom

            stage = omni.usd.get_context().get_stage()
            cam = UsdGeom.Camera.Define(stage, "/World/test_camera")
            xform = UsdGeom.Xformable(cam.GetPrim())
            xform.AddTranslateOp().Set(Gf.Vec3d(0, 0, 1.0))
            cam.CreateFocalLengthAttr(18.0)
            return "camera prim ok"

        ok, value = check("create_camera_prim", create_camera)
        results["create_camera_prim"] = {"ok": ok, "value": value}

        def save_usd():
            import omni.usd

            out = OUTPUT_DIR
            out.mkdir(parents=True, exist_ok=True)
            usd_path = out / "capability_check.usd"
            stage = omni.usd.get_context().get_stage()
            stage.GetRootLayer().Export(str(usd_path))
            return str(usd_path)

        ok, value = check("save_usd", save_usd)
        results["save_usd"] = {"ok": ok, "value": value}

    finally:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        (OUTPUT_DIR / "results.json").write_text(
            json.dumps(results, indent=2),
            encoding="utf-8",
        )
        if app is not None and hasattr(app, "close"):
            app.close()

    required = [
        "import_isaacsim",
        "start_headless_simulation_app",
        "import_usd_physx_modules",
        "create_stage_and_physics_scene",
        "create_static_collider",
        "create_rigid_body_and_joint",
        "prismatic_drive_moves_body",
        "step_timeline",
        "create_camera_prim",
        "save_usd",
    ]
    failed = [name for name in required if not results.get(name, {}).get("ok")]
    if failed:
        print("ISAACSIM_CAPABILITY_CHECK_FAILED")
        print("failed:", ", ".join(failed))
        raise SystemExit(1)
    print("ISAACSIM_CAPABILITY_CHECK_PASSED")


if __name__ == "__main__":
    main()
