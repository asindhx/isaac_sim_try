from __future__ import annotations

import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def command_result(command: list[str], timeout: int = 8) -> dict:
    path = shutil.which(command[0])
    if not path:
        return {"available": False, "command": command, "error": f"{command[0]} not found"}
    try:
        completed = subprocess.run(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
        return {
            "available": True,
            "command": command,
            "returncode": completed.returncode,
            "stdout": completed.stdout.strip()[-2000:],
            "stderr": completed.stderr.strip()[-2000:],
        }
    except Exception as exc:
        return {"available": True, "command": command, "error": f"{type(exc).__name__}: {exc}"}


def import_check(module_name: str) -> dict:
    try:
        spec = importlib.util.find_spec(module_name)
    except Exception as exc:
        return {"module": module_name, "found": False, "imported": False, "error": f"{type(exc).__name__}: {exc}"}
    result = {"module": module_name, "found": spec is not None, "origin": getattr(spec, "origin", None)}
    if spec is None:
        return result
    try:
        module = importlib.import_module(module_name)
        result["imported"] = True
        result["version"] = getattr(module, "__version__", "")
    except Exception as exc:
        result["imported"] = False
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def file_check(path: Path) -> dict:
    return {"path": str(path), "exists": path.exists(), "is_file": path.is_file(), "size": path.stat().st_size if path.exists() else 0}


def write_check(path: Path) -> dict:
    path.mkdir(parents=True, exist_ok=True)
    try:
        with tempfile.NamedTemporaryFile("w", dir=path, delete=False, encoding="utf-8") as f:
            f.write("ok\n")
            temp_path = Path(f.name)
        temp_path.unlink()
        return {"path": str(path), "writable": True}
    except Exception as exc:
        return {"path": str(path), "writable": False, "error": f"{type(exc).__name__}: {exc}"}


def video_check(out_dir: Path) -> dict:
    try:
        from PIL import Image
        import imageio.v2 as imageio

        out_dir.mkdir(parents=True, exist_ok=True)
        frames = []
        for idx in range(4):
            frame = out_dir / f"envcheck_{idx:02d}.png"
            Image.new("RGB", (160, 96), (40 + idx * 35, 80, 130)).save(frame)
            frames.append(frame)
        mp4 = out_dir / "envcheck_video.mp4"
        with imageio.get_writer(mp4, fps=4, macro_block_size=1) as writer:
            for frame in frames:
                writer.append_data(imageio.imread(frame))
        return {"ok": mp4.exists() and mp4.stat().st_size > 0, "path": str(mp4), "size": mp4.stat().st_size if mp4.exists() else 0}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def isaac_import_checks() -> dict:
    checks = {}
    candidates = {
        "simulation_app_old": "omni.isaac.kit",
        "simulation_app_new": "isaacsim",
        "world_old": "omni.isaac.core",
        "world_new": "isaacsim.core.api",
        "camera_old": "omni.isaac.sensor",
        "camera_new": "isaacsim.sensors.camera",
        "replicator": "omni.replicator.core",
        "viewport": "omni.kit.viewport.utility",
        "pxr": "pxr",
    }
    for key, module_name in candidates.items():
        checks[key] = import_check(module_name)
    return checks


def main() -> int:
    output_dir = Path(os.environ.get("OUTPUT_DIR", ROOT / "outputs" / "envcheck"))
    report = {
        "python": {
            "executable": sys.executable,
            "version": sys.version,
            "platform": platform.platform(),
            "cwd": str(Path.cwd()),
            "project_root": str(ROOT),
        },
        "project_files": {
            name: file_check(ROOT / name)
            for name in ("isaac_main.py", "isaac_scene.py", "route_planner.py", "endoscope_model.py", "exporters.py", "config.py", "requirements.txt")
        },
        "write_permissions": {
            "project_outputs": write_check(ROOT / "outputs"),
            "requested_output_dir": write_check(output_dir),
        },
        "python_modules": {
            name: import_check(name)
            for name in ("numpy", "PIL", "imageio", "imageio_ffmpeg")
        },
        "video_encoding": video_check(output_dir),
        "commands": {
            "nvidia_smi": command_result(["nvidia-smi"]),
            "docker_version": command_result(["docker", "version"]),
            "docker_info": command_result(["docker", "info"]),
        },
        "isaac_modules": isaac_import_checks(),
    }

    issues = []
    for name, info in report["project_files"].items():
        if not info["exists"]:
            issues.append(f"missing_project_file:{name}")
    for name, info in report["python_modules"].items():
        if not info.get("imported"):
            issues.append(f"missing_python_module:{name}")
    if not report["write_permissions"]["project_outputs"].get("writable"):
        issues.append("project_outputs_not_writable")
    if not report["write_permissions"]["requested_output_dir"].get("writable"):
        issues.append("requested_output_dir_not_writable")
    if not report["video_encoding"].get("ok"):
        issues.append("mp4_encoding_failed")
    if not (report["isaac_modules"]["simulation_app_old"].get("imported") or report["isaac_modules"]["simulation_app_new"].get("imported")):
        issues.append("isaac_simulation_app_not_importable")
    if not (report["isaac_modules"]["world_old"].get("imported") or report["isaac_modules"]["world_new"].get("imported")):
        issues.append("isaac_world_api_not_importable")
    if not (report["isaac_modules"]["camera_old"].get("imported") or report["isaac_modules"]["camera_new"].get("imported")):
        issues.append("isaac_camera_api_not_importable")

    report["issues"] = issues
    report["ok"] = not issues
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "lab_env_report.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print(f"LAB_ENV_REPORT={report_path}")
    if issues:
        print("LAB_ENV_CHECK_FAILED")
        return 1
    print("LAB_ENV_CHECK_PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
