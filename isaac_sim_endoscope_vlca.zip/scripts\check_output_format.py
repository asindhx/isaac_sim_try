import json
import csv
from pathlib import Path


def require(condition, message):
    if not condition:
        print("OUTPUT_FORMAT_CHECK_FAILED")
        print(message)
        raise SystemExit(1)


def main():
    root = Path("outputs/endoscope_single_latest")
    episode = Path("outputs/endoscope_single_latest/episode_000000")
    episode_required = [
        "frames/ebv",
        "frames/ebv/000000.jpg",
        "frames/ev",
        "frames/ev/000000.jpg",
        "render_frames",
        "render_frames/000000.jpg",
        "tip_frames",
        "tip_frames/000000.jpg",
        "debug_frames",
        "trajectory.csv",
        "control_commands.csv",
        "annotations.json",
        "metadata.json",
        "scene.usd",
    ]
    dataset_required = [
        "cam_ebv",
        "cam_ebv/0001.jpg",
        "cam_ev",
        "cam_ev/0001.jpg",
        "json/vlca.json",
        "json/yolo_auto_gen.json",
        "data.csv",
        "smoke_test_summary.json",
    ]
    missing = [item for item in episode_required if not (episode / item).exists()]
    missing += [item for item in dataset_required if not (root / item).exists()]
    if missing:
        print("OUTPUT_FORMAT_CHECK_FAILED")
        print("missing:", ", ".join(missing))
        raise SystemExit(1)
    annotations = json.loads((episode / "annotations.json").read_text(encoding="utf-8"))
    metadata = json.loads((episode / "metadata.json").read_text(encoding="utf-8"))
    vlca = json.loads((root / "json" / "vlca.json").read_text(encoding="utf-8"))
    yolo = json.loads((root / "json" / "yolo_auto_gen.json").read_text(encoding="utf-8"))
    smoke = json.loads((root / "smoke_test_summary.json").read_text(encoding="utf-8"))
    require(annotations.get("format") == "vlca_sim_annotations_v1", "bad annotations format")
    require(metadata.get("output_format") == "genesis_compatible_episode_v1", "bad metadata output_format")
    require(vlca.get("version") == "2.0", "bad vlca version")
    require(vlca.get("coordSystem") == "normalised_0_1_topleft", "bad vlca coordSystem")
    require("0001.jpg" in vlca.get("labels", {}), "missing vlca frame 0001.jpg")
    require(any(label.get("prompt") == "robot tip" for label in vlca["labels"]["0001.jpg"]), "missing robot tip label")
    require(any(label.get("prompt") == "target" for label in vlca["labels"]["0001.jpg"]), "missing active target label")
    require(yolo.get("version") == "2.0", "bad yolo version")
    require("0001.jpg" in yolo.get("labels", {}), "missing yolo frame 0001.jpg")
    require(all(label.get("prompt") == "block" for label in yolo["labels"]["0001.jpg"]), "yolo labels should only contain blocks")
    require(smoke.get("passed") is True, f"smoke test failed: {smoke}")
    route_quality = smoke.get("route_quality")
    if isinstance(route_quality, dict):
        require(route_quality.get("passed") is True, f"route quality failed: {route_quality}")
    with (episode / "trajectory.csv").open(encoding="utf-8") as f:
        trajectory_rows = list(csv.DictReader(f))
    with (episode / "control_commands.csv").open(encoding="utf-8") as f:
        control_rows = list(csv.DictReader(f))
    require(len(trajectory_rows) == len(control_rows) > 0, "trajectory/control row count mismatch")
    require(all(row.get("instruction") and row.get("route_stage") for row in control_rows), "missing instruction or route_stage")
    require(len({row.get("route_stage") for row in control_rows}) >= 2, "route_stage never changes")
    print("OUTPUT_FORMAT_CHECK_PASSED")


if __name__ == "__main__":
    main()
