import json
from pathlib import Path


def main():
    root = Path("outputs/endoscope_single_latest")
    episode = Path("outputs/endoscope_single_latest/episode_000000")
    episode_required = [
        "frames/ebv",
        "frames/ebv/000000.jpg",
        "frames/ev",
        "frames/ev/000000.jpg",
        "render_frames",
        "render_frames/000000.jpg",
        "tip_frames",
        "tip_frames/000000.jpg",
        "debug_frames",
        "trajectory.csv",
        "control_commands.csv",
        "annotations.json",
        "metadata.json",
        "scene.usd",
    ]
    dataset_required = [
        "cam_ebv",
        "cam_ebv/0001.jpg",
        "cam_ev",
        "cam_ev/0001.jpg",
        "json/vlca.json",
        "json/yolo_auto_gen.json",
        "data.csv",
    ]
    missing = [item for item in episode_required if not (episode / item).exists()]
    missing += [item for item in dataset_required if not (root / item).exists()]
    if missing:
        print("OUTPUT_FORMAT_CHECK_FAILED")
        print("missing:", ", ".join(missing))
        raise SystemExit(1)
    annotations = json.loads((episode / "annotations.json").read_text(encoding="utf-8"))
    metadata = json.loads((episode / "metadata.json").read_text(encoding="utf-8"))
    vlca = json.loads((root / "json" / "vlca.json").read_text(encoding="utf-8"))
    yolo = json.loads((root / "json" / "yolo_auto_gen.json").read_text(encoding="utf-8"))
    assert annotations.get("format") == "vlca_sim_annotations_v1"
    assert metadata.get("output_format") == "genesis_compatible_episode_v1"
    assert vlca.get("version") == "2.0"
    assert vlca.get("coordSystem") == "normalised_0_1_topleft"
    assert "0001.jpg" in vlca.get("labels", {})
    assert any(label.get("prompt") == "robot tip" for label in vlca["labels"]["0001.jpg"])
    assert any(label.get("prompt") == "target" for label in vlca["labels"]["0001.jpg"])
    assert yolo.get("version") == "2.0"
    assert "0001.jpg" in yolo.get("labels", {})
    assert all(label.get("prompt") == "block" for label in yolo["labels"]["0001.jpg"])
    print("OUTPUT_FORMAT_CHECK_PASSED")


if __name__ == "__main__":
    main()
