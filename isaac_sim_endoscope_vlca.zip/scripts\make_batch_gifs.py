import argparse
from pathlib import Path

from PIL import Image


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", default="outputs/batch_l0_l1_training")
    parser.add_argument("--output-dir", default="outputs/batch_l0_l1_training_gifs")
    parser.add_argument("--view", choices=("ebv", "ev"), default="ebv")
    parser.add_argument("--max-frames", type=int, default=160)
    parser.add_argument("--width", type=int, default=720)
    parser.add_argument("--duration-ms", type=int, default=55)
    return parser.parse_args()


def find_frames(setup_dir, view):
    candidates = [
        setup_dir / "episode_000000" / "frames" / view,
        setup_dir / f"cam_{view}",
        setup_dir / "episode_000000" / ("render_frames" if view == "ebv" else "tip_frames"),
    ]
    for folder in candidates:
        if folder.exists():
            frames = sorted(list(folder.glob("*.jpg")) + list(folder.glob("*.png")))
            if frames:
                return frames
    return []


def make_gif(frames, out_path, max_frames, width, duration_ms):
    step = max(1, len(frames) // max_frames)
    selected = frames[::step][:max_frames]
    images = []
    for frame in selected:
        image = Image.open(frame).convert("RGB")
        if width > 0 and image.width != width:
            height = max(1, round(image.height * (width / image.width)))
            image = image.resize((width, height))
        images.append(image)
    if not images:
        return False
    out_path.parent.mkdir(parents=True, exist_ok=True)
    images[0].save(
        out_path,
        save_all=True,
        append_images=images[1:],
        duration=duration_ms,
        loop=0,
        optimize=True,
    )
    return True


def main():
    args = parse_args()
    root = Path(__file__).resolve().parents[1]
    input_dir = (root / args.input_dir).resolve()
    output_dir = (root / args.output_dir).resolve()
    made = 0
    for setup_dir in sorted(p for p in input_dir.iterdir() if p.is_dir() and not p.name.startswith("_")):
        frames = find_frames(setup_dir, args.view)
        if not frames:
            print(f"[gif] skip {setup_dir.name}: no {args.view} frames")
            continue
        out_path = output_dir / f"{setup_dir.name}_{args.view}.gif"
        if make_gif(frames, out_path, args.max_frames, args.width, args.duration_ms):
            made += 1
            print(f"[gif] saved {out_path}")
    print(f"[gif] total={made}")


if __name__ == "__main__":
    main()
