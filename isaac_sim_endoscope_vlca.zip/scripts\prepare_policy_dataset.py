#!/usr/bin/env python3
"""Build a small imitation-learning dataset from one Isaac/Genesis-style episode.

The output is JSONL so it stays easy to inspect and can be consumed by either a
quick baseline or a future image model.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path


def read_csv_by_frame(path: Path) -> dict[int, dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open(newline="", encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))
    return {int(row["frame"]): row for row in rows if row.get("frame", "").strip()}


def to_float(value: str | None, field: str, frame: int) -> float:
    try:
        if value is None or value == "":
            raise ValueError("missing")
        result = float(value)
        if not math.isfinite(result):
            raise ValueError("non-finite")
        return result
    except ValueError as exc:
        raise RuntimeError(f"Invalid numeric value for {field} at frame {frame}: {value!r}") from exc


def existing_image(root: Path, relative_candidates: list[str]) -> str:
    for rel in relative_candidates:
        if (root / rel).exists():
            return rel.replace("\\", "/")
    raise FileNotFoundError(
        "None of the expected image files exist: "
        + ", ".join(str(root / rel) for rel in relative_candidates)
    )


def frame_image_candidates(episode_name: str, view: str, frame: int) -> list[str]:
    real_view = "cam_ebv" if view == "ebv" else "cam_ev"
    episode_view = "frames/ebv" if view == "ebv" else "frames/ev"
    return [
        f"{real_view}/{frame + 1:04d}.jpg",
        f"{real_view}/{frame + 1:04d}.png",
        f"{episode_name}/{episode_view}/{frame:06d}.jpg",
        f"{episode_name}/{episode_view}/{frame:06d}.png",
    ]


def build_dataset(output_root: Path, out_path: Path, episode_name: str) -> dict[str, object]:
    episode_dir = output_root / episode_name
    trajectory = read_csv_by_frame(episode_dir / "trajectory.csv")
    controls = read_csv_by_frame(episode_dir / "control_commands.csv")
    frames = sorted(set(trajectory) & set(controls))
    if len(frames) < 2:
        raise RuntimeError(f"Need at least two aligned frames, got {len(frames)}")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with out_path.open("w", encoding="utf-8") as stream:
        for current_frame, next_frame in zip(frames, frames[1:]):
            cur_traj = trajectory[current_frame]
            cur_ctrl = controls[current_frame]
            next_ctrl = controls[next_frame]
            cur_insertion = to_float(cur_ctrl.get("insertion_target"), "insertion_target", current_frame)
            cur_bend = to_float(cur_ctrl.get("bend_target_deg"), "bend_target_deg", current_frame)
            cur_lateral = to_float(cur_ctrl.get("lateral_target"), "lateral_target", current_frame)
            next_insertion = to_float(next_ctrl.get("insertion_target"), "insertion_target", next_frame)
            next_bend = to_float(next_ctrl.get("bend_target_deg"), "bend_target_deg", next_frame)
            next_lateral = to_float(next_ctrl.get("lateral_target"), "lateral_target", next_frame)
            sample = {
                "episode": episode_name,
                "frame": current_frame,
                "next_frame": next_frame,
                "image_ebv": existing_image(output_root, frame_image_candidates(episode_name, "ebv", current_frame)),
                "image_ev": existing_image(output_root, frame_image_candidates(episode_name, "ev", current_frame)),
                "state": {
                    "tip_x": to_float(cur_traj.get("tip_x"), "tip_x", current_frame),
                    "tip_y": to_float(cur_traj.get("tip_y"), "tip_y", current_frame),
                    "tip_z": to_float(cur_traj.get("tip_z"), "tip_z", current_frame),
                    "tail_x": to_float(cur_traj.get("tail_x"), "tail_x", current_frame),
                    "tail_y": to_float(cur_traj.get("tail_y"), "tail_y", current_frame),
                    "insertion_target": cur_insertion,
                    "bend_target_deg": cur_bend,
                    "lateral_target": cur_lateral,
                    "route_stage": cur_ctrl.get("route_stage", ""),
                },
                "action": {
                    "next_insertion_target": next_insertion,
                    "next_bend_target_deg": next_bend,
                    "next_lateral_target": next_lateral,
                    "delta_insertion": next_insertion - cur_insertion,
                    "delta_bend_deg": next_bend - cur_bend,
                    "delta_lateral": next_lateral - cur_lateral,
                },
            }
            stream.write(json.dumps(sample, ensure_ascii=False) + "\n")
            count += 1
    return {"samples": count, "output": str(out_path)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", default="outputs/endoscope_single_latest")
    parser.add_argument("--episode", default="episode_000000")
    parser.add_argument("--out", default="outputs/policy_dataset/single_episode_policy.jsonl")
    args = parser.parse_args()

    summary = build_dataset(Path(args.output_root), Path(args.out), args.episode)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
