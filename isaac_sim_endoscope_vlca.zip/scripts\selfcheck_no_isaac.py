from __future__ import annotations

import csv
import json
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "selfcheck_no_isaac"


def main() -> int:
    if OUT.exists():
        shutil.rmtree(OUT)
    cmd = [
        sys.executable,
        "isaac_main.py",
        "--dry-run-no-isaac",
        "--record",
        "--video",
        "--max-steps",
        "180",
        "--output-dir",
        str(OUT),
    ]
    subprocess.run(cmd, cwd=ROOT, check=True)

    episode = OUT / "episode_000000"
    metadata = json.loads((episode / "metadata.json").read_text(encoding="utf-8"))
    rows = list(csv.DictReader((episode / "trajectory.csv").open(newline="", encoding="utf-8")))
    if not rows:
        raise AssertionError("trajectory.csv is empty")
    reached = [name for name in rows[-1]["reached_route_targets"].split("|") if name]
    expected = [target["name"] for target in metadata["route_targets"]]
    if reached != expected:
        raise AssertionError(f"route target order mismatch: expected {expected}, got {reached}")
    if not metadata.get("route_finished"):
        raise AssertionError("metadata route_finished is false")
    if not metadata.get("success"):
        raise AssertionError("metadata success is false")
    if float(rows[-1]["distance_to_target"]) > float(metadata["target_finish_radius"]):
        raise AssertionError("final tip did not reach target_finish_radius")
    for rel in ("annotations.json", "json/vlca.json", "json/yolo_auto_gen.json", "aligned.csv"):
        if not (episode / rel).exists():
            raise AssertionError(f"missing output: {rel}")
    video_manifest_path = episode / "video_manifest.json"
    if not video_manifest_path.exists():
        raise AssertionError("missing output: video_manifest.json")
    video_manifest = json.loads(video_manifest_path.read_text(encoding="utf-8"))
    top_video = video_manifest.get("top_down", {})
    if int(top_video.get("frame_count", 0)) < 20:
        raise AssertionError(f"top-down video has too few frames: {top_video}")
    mp4_path = Path(top_video.get("path", ""))
    fallback_path = Path(top_video.get("fallback_path", "")) if top_video.get("fallback_path") else None
    if not (
        (mp4_path.exists() and mp4_path.stat().st_size > 0)
        or (fallback_path and fallback_path.exists() and fallback_path.stat().st_size > 0)
    ):
        raise AssertionError(f"top-down video export missing: {top_video}")

    report = {
        "code": "SELF_CHECK_NO_ISAAC_PASSED",
        "steps": len(rows),
        "level": metadata.get("level"),
        "success": metadata.get("success"),
        "route_finished": metadata.get("route_finished"),
        "final_distance": float(rows[-1]["distance_to_target"]),
        "target_finish_radius": metadata.get("target_finish_radius"),
        "top_down_video": top_video,
        "reached": reached,
    }
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
