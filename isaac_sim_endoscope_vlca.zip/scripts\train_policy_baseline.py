#!/usr/bin/env python3
"""Train a tiny imitation-learning baseline from the prepared JSONL dataset.

This is intentionally simple: it predicts the next control targets from the
current tip/tail pose and current control state. It is a smoke-test baseline for
the data pipeline, not the final image policy.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


LABELS = ["next_insertion_target", "next_bend_target_deg", "next_lateral_target"]
BASE_FEATURES = [
    "tip_x",
    "tip_y",
    "tip_z",
    "tail_x",
    "tail_y",
    "insertion_target",
    "bend_target_deg",
    "lateral_target",
]


def load_samples(path: Path) -> list[dict[str, object]]:
    if not path.exists():
        raise FileNotFoundError(path)
    samples: list[dict[str, object]] = []
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            line = line.strip()
            if line:
                samples.append(json.loads(line))
    if len(samples) < 2:
        raise RuntimeError(f"Need at least two samples, got {len(samples)}")
    return samples


def numeric(value: object, field: str) -> float:
    try:
        if value is None or value == "":
            raise ValueError("missing")
        result = float(value)
        if not math.isfinite(result):
            raise ValueError("non-finite")
        return result
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"Invalid numeric value for {field}: {value!r}") from exc


def collect_route_stages(samples: list[dict[str, object]]) -> list[str]:
    stages = sorted({
        str(sample.get("state", {}).get("route_stage", ""))
        for sample in samples
        if isinstance(sample.get("state"), dict)
    })
    return [stage for stage in stages if stage]


def sample_state(sample: dict[str, object]) -> dict[str, object]:
    state = sample.get("state", {})
    return state if isinstance(state, dict) else {}


def build_feature_vector(sample: dict[str, object], route_stages: list[str], index: int, total: int) -> list[float]:
    state = sample_state(sample)
    features = [1.0]
    features.extend(numeric(state.get(name), f"state.{name}") for name in BASE_FEATURES)
    features.append(index / max(1, total - 1))
    current_stage = str(state.get("route_stage", ""))
    features.extend(1.0 if current_stage == stage else 0.0 for stage in route_stages)
    return features


def build_label_vector(sample: dict[str, object]) -> list[float]:
    action = sample.get("action", {})
    if not isinstance(action, dict):
        action = {}
    return [numeric(action.get(name), f"action.{name}") for name in LABELS]


def mean_absolute_error(predictions: list[list[float]], labels: list[list[float]]) -> dict[str, float]:
    errors: dict[str, float] = {}
    for col, name in enumerate(LABELS):
        total = sum(abs(pred[col] - label[col]) for pred, label in zip(predictions, labels))
        errors[name] = total / max(1, len(labels))
    errors["mean"] = sum(errors.values()) / max(1, len(errors))
    return errors


def train_ridge(features: list[list[float]], labels: list[list[float]], ridge: float) -> dict[str, object] | None:
    try:
        import numpy as np
    except Exception:
        return None

    x = np.asarray(features, dtype=float)
    y = np.asarray(labels, dtype=float)
    penalty = np.eye(x.shape[1], dtype=float) * ridge
    penalty[0, 0] = 0.0
    weights = np.linalg.solve(x.T @ x + penalty, x.T @ y)
    predictions = x @ weights
    return {
        "model_type": "ridge_regression",
        "weights": weights.tolist(),
        "train_mae": mean_absolute_error(predictions.tolist(), labels),
    }


def train_stage_mean(samples: list[dict[str, object]], labels: list[list[float]]) -> dict[str, object]:
    buckets: dict[str, list[list[float]]] = {}
    for sample, label in zip(samples, labels):
        state = sample_state(sample)
        stage = str(state.get("route_stage", ""))
        buckets.setdefault(stage, []).append(label)

    def average(rows: list[list[float]]) -> list[float]:
        return [sum(row[col] for row in rows) / len(rows) for col in range(len(LABELS))]

    global_mean = average(labels)
    stage_means = {stage: average(rows) for stage, rows in buckets.items()}
    predictions = [stage_means.get(str(sample_state(sample).get("route_stage", "")), global_mean) for sample in samples]
    return {
        "model_type": "stage_mean_fallback",
        "global_mean": global_mean,
        "stage_means": stage_means,
        "train_mae": mean_absolute_error(predictions, labels),
    }


def label_quality(labels: list[list[float]]) -> dict[str, object]:
    ranges = {}
    for col, name in enumerate(LABELS):
        values = [row[col] for row in labels]
        ranges[name] = max(values) - min(values)
    all_static = all(value < 1.0e-9 for value in ranges.values())
    if all_static:
        raise RuntimeError(f"All policy labels are constant; baseline would be meaningless: {ranges}")
    return {
        "label_ranges": ranges,
        "warnings": [] if len(labels) >= 8 else ["small_dataset_validation_skipped"],
    }


def global_mean_baseline(labels: list[list[float]]) -> dict[str, object]:
    mean = [sum(row[col] for row in labels) / len(labels) for col in range(len(LABELS))]
    predictions = [mean for _ in labels]
    return {
        "model_type": "global_mean_reference",
        "train_mae": mean_absolute_error(predictions, labels),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="outputs/policy_dataset/single_episode_policy.jsonl")
    parser.add_argument("--out", default="outputs/policy_dataset/baseline_policy.json")
    parser.add_argument("--ridge", type=float, default=1.0e-4)
    args = parser.parse_args()

    samples = load_samples(Path(args.dataset))
    route_stages = collect_route_stages(samples)
    features = [build_feature_vector(sample, route_stages, idx, len(samples)) for idx, sample in enumerate(samples)]
    labels = [build_label_vector(sample) for sample in samples]
    quality = label_quality(labels)

    model = train_ridge(features, labels, args.ridge)
    if model is None:
        model = train_stage_mean(samples, labels)

    output = {
        "dataset": str(Path(args.dataset)),
        "samples": len(samples),
        "label_names": LABELS,
        "feature_names": ["bias", *BASE_FEATURES, "progress_norm", *[f"stage:{stage}" for stage in route_stages]],
        "route_stages": route_stages,
        "quality": quality,
        "reference_baseline": global_mean_baseline(labels),
        **model,
    }
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(out_path), "samples": len(samples), "train_mae": output["train_mae"]}, indent=2))


if __name__ == "__main__":
    main()
